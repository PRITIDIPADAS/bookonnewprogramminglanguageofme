"""
PASO AST Nodes
Defines all Abstract Syntax Tree node types.
"""

from dataclasses import dataclass
from typing import List, Optional, Any


class ASTNode:
    """Base class for all AST nodes."""
    
    def accept(self, visitor):
        """Visitor pattern support."""
        raise NotImplementedError
    
    def __repr__(self):
        return self.__class__.__name__


# ============ Expression Nodes ============

class Expression(ASTNode):
    """Base class for all expression nodes."""
    pass


@dataclass
class NumberLiteral(Expression):
    """Numeric literal (e.g., 42, 3.14)."""
    value: int or float
    
    def __repr__(self):
        return f"Number({self.value})"


@dataclass
class StringLiteral(Expression):
    """String literal (e.g., "hello")."""
    value: str
    
    def __repr__(self):
        return f"String({repr(self.value)})"


@dataclass
class BooleanLiteral(Expression):
    """Boolean literal (true or false)."""
    value: bool
    
    def __repr__(self):
        return f"Bool({self.value})"


@dataclass
class Variable(Expression):
    """Variable reference (e.g., x, my_var)."""
    name: str
    
    def __repr__(self):
        return f"Var({self.name})"


@dataclass
class BinaryOp(Expression):
    """Binary operation (e.g., x + y, a > b)."""
    operator: str
    left: Expression
    right: Expression
    
    def __repr__(self):
        return f"BinaryOp({self.operator}, {self.left}, {self.right})"


@dataclass
class UnaryOp(Expression):
    """Unary operation (e.g., -x, not a)."""
    operator: str
    operand: Expression
    
    def __repr__(self):
        return f"UnaryOp({self.operator}, {self.operand})"


@dataclass
class FunctionCall(Expression):
    """Function call (e.g., factorial(5))."""
    name: str
    arguments: List[Expression]
    
    def __repr__(self):
        args = ', '.join(str(arg) for arg in self.arguments)
        return f"Call({self.name}, [{args}])"


# ============ Statement Nodes ============

class Statement(ASTNode):
    """Base class for all statement nodes."""
    pass


@dataclass
class Assignment(Statement):
    """Variable assignment (e.g., save 5 to x)."""
    variable: str
    value: Expression
    
    def __repr__(self):
        return f"Assign({self.variable}, {self.value})"


@dataclass
class Output(Statement):
    """Output statement (e.g., show x)."""
    expression: Expression
    
    def __repr__(self):
        return f"Output({self.expression})"


@dataclass
class Input(Statement):
    """Input statement (e.g., ask "Enter name" to name)."""
    prompt: Expression
    variable: str
    
    def __repr__(self):
        return f"Input({self.prompt}, {self.variable})"


@dataclass
class Conditional(Statement):
    """Conditional statement (e.g., when x > 0 then ... done)."""
    condition: Expression
    if_branch: List[Statement]
    else_branch: Optional[List[Statement]]
    
    def __repr__(self):
        has_else = " + else" if self.else_branch else ""
        return f"If({self.condition}, {len(self.if_branch)} stmts{has_else})"


@dataclass
class RepeatLoop(Statement):
    """Repeat loop (e.g., repeat 10 ... again)."""
    count: Expression
    body: List[Statement]
    
    def __repr__(self):
        return f"Repeat({self.count}, {len(self.body)} stmts)"


@dataclass
class WhileLoop(Statement):
    """While loop (e.g., while x < 10 do ... done)."""
    condition: Expression
    body: List[Statement]
    
    def __repr__(self):
        return f"While({self.condition}, {len(self.body)} stmts)"


@dataclass
class FunctionDef(Statement):
    """Function definition (e.g., func factorial(n) ... end)."""
    name: str
    parameters: List[str]
    body: List[Statement]
    
    def __repr__(self):
        params = ', '.join(self.parameters)
        return f"Func({self.name}({params}), {len(self.body)} stmts)"


@dataclass
class Return(Statement):
    """Return statement (e.g., return x)."""
    expression: Expression
    
    def __repr__(self):
        return f"Return({self.expression})"


# ============ Program Node ============

@dataclass
class Program(ASTNode):
    """Root node of a PASO program."""
    statements: List[Statement]
    
    def __repr__(self):
        return f"Program({len(self.statements)} statements)"
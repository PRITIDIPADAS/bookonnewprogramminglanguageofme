"""
PASO Interpreter
Executes AST nodes directly without compilation.
"""

from typing import Any, Dict, List, Optional
from lexer import LexerError
from parser import ParserError
from ast_nodes import *


class InterpreterError(Exception):
    """Raised when the interpreter encounters a runtime error."""
    pass


class ReturnException(Exception):
    """Used to handle return statements."""
    def __init__(self, value: Any):
        self.value = value


class Function:
    """Represents a user-defined function."""
    def __init__(self, name: str, parameters: List[str], body: List[Statement], 
                 interpreter: 'Interpreter'):
        self.name = name
        self.parameters = parameters
        self.body = body
        self.interpreter = interpreter
    
    def call(self, args: List[Any]) -> Any:
        """Call the function with arguments."""
        # Create new scope
        self.interpreter.push_scope()
        
        # Bind parameters to arguments
        if len(args) != len(self.parameters):
            raise InterpreterError(
                f"Function {self.name} expects {len(self.parameters)} arguments, got {len(args)}"
            )
        
        for param, arg in zip(self.parameters, args):
            self.interpreter.set_variable(param, arg)
        
        # Execute function body
        try:
            for stmt in self.body:
                self.interpreter.visit(stmt)
            
            # Default return value
            return None
        except ReturnException as e:
            return e.value
        finally:
            self.interpreter.pop_scope()


class Interpreter:
    """Executes PASO programs directly from AST."""
    
    def __init__(self):
        self.global_variables: Dict[str, Any] = {}
        self.functions: Dict[str, Function] = {}
        self.scopes: List[Dict[str, Any]] = []
        self.current_function: Optional[Function] = None
    
    def push_scope(self):
        """Enter a new scope."""
        self.scopes.append({})
    
    def pop_scope(self):
        """Exit the current scope."""
        if self.scopes:
            self.scopes.pop()
    
    def get_variable(self, name: str) -> Any:
        """Get a variable value, checking all scopes."""
        # Check local scopes first
        for scope in reversed(self.scopes):
            if name in scope:
                return scope[name]
        
        # Check global scope
        if name in self.global_variables:
            return self.global_variables[name]
        
        raise InterpreterError(f"Undefined variable: {name}")
    
    def set_variable(self, name: str, value: Any):
        """Set a variable value in the current scope."""
        # Set in the innermost scope
        if self.scopes:
            self.scopes[-1][name] = value
        else:
            self.global_variables[name] = value
    
    def define_function(self, func_def: FunctionDef):
        """Define a function."""
        func = Function(
            func_def.name,
            func_def.parameters,
            func_def.body,
            self
        )
        self.functions[func_def.name] = func
    
    def visit(self, node: ASTNode) -> Any:
        """Visit an AST node and execute it."""
        method_name = f'visit_{type(node).__name__}'
        visitor = getattr(self, method_name, self.generic_visit)
        return visitor(node)
    
    def generic_visit(self, node: ASTNode) -> Any:
        """Default visitor method."""
        raise InterpreterError(f"No visit method for {type(node).__name__}")
    
    def visit_Program(self, node: Program) -> None:
        """Execute a program."""
        # First pass: collect function definitions
        for stmt in node.statements:
            if isinstance(stmt, FunctionDef):
                self.define_function(stmt)
        
        # Second pass: execute all statements
        for stmt in node.statements:
            if not isinstance(stmt, FunctionDef):
                self.visit(stmt)
    
    def visit_NumberLiteral(self, node: NumberLiteral) -> int or float:
        """Evaluate a number literal."""
        return node.value
    
    def visit_StringLiteral(self, node: StringLiteral) -> str:
        """Evaluate a string literal."""
        return node.value
    
    def visit_BooleanLiteral(self, node: BooleanLiteral) -> bool:
        """Evaluate a boolean literal."""
        return node.value
    
    def visit_Variable(self, node: Variable) -> Any:
        """Evaluate a variable reference."""
        return self.get_variable(node.name)
    
    def visit_BinaryOp(self, node: BinaryOp) -> Any:
        """Evaluate a binary operation."""
        left = self.visit(node.left)
        right = self.visit(node.right)
        
        # Arithmetic operations
        if node.operator == 'plus':
            # Handle string concatenation
            if isinstance(left, str) or isinstance(right, str):
                return str(left) + str(right)
            return left + right
        elif node.operator == 'minus':
            return left - right
        elif node.operator == 'times':
            return left * right
        elif node.operator == 'over':
            if right == 0:
                raise InterpreterError("Division by zero")
            return left / right
        elif node.operator == 'div':
            if right == 0:
                raise InterpreterError("Division by zero")
            return int(left // right)
        
        # Comparison operations
        elif node.operator == 'above':
            return left > right
        elif node.operator == 'below':
            return left < right
        elif node.operator == 'equals':
            return left == right
        
        # Logical operations
        elif node.operator == 'and':
            return left and right
        elif node.operator == 'or':
            return left or right
        
        else:
            raise InterpreterError(f"Unknown operator: {node.operator}")
    
    def visit_UnaryOp(self, node: UnaryOp) -> Any:
        """Evaluate a unary operation."""
        operand = self.visit(node.operand)
        
        if node.operator == '-':
            return -operand
        elif node.operator == 'not':
            return not operand
        else:
            raise InterpreterError(f"Unknown unary operator: {node.operator}")
    
    def visit_FunctionCall(self, node: FunctionCall) -> Any:
        """Evaluate a function call."""
        # Evaluate arguments
        args = [self.visit(arg) for arg in node.arguments]
        
        # Look up function
        if node.name not in self.functions:
            raise InterpreterError(f"Undefined function: {node.name}")
        
        func = self.functions[node.name]
        return func.call(args)
    
    def visit_Assignment(self, node: Assignment) -> None:
        """Execute an assignment."""
        value = self.visit(node.value)
        self.set_variable(node.variable, value)
    
    def visit_Output(self, node: Output) -> None:
        """Execute an output statement."""
        value = self.visit(node.expression)
        print(value)
    
    def visit_Input(self, node: Input) -> None:
        """Execute an input statement."""
        prompt = self.visit(node.prompt)
        user_input = input(prompt)
        
        # Try to convert to number
        try:
            if '.' in user_input:
                value = float(user_input)
            else:
                value = int(user_input)
        except ValueError:
            value = user_input
        
        self.set_variable(node.variable, value)
    
    def visit_Conditional(self, node: Conditional) -> None:
        """Execute a conditional statement."""
        condition = self.visit(node.condition)
        
        if condition:
            for stmt in node.if_branch:
                self.visit(stmt)
        elif node.else_branch:
            for stmt in node.else_branch:
                self.visit(stmt)
    
    def visit_RepeatLoop(self, node: RepeatLoop) -> None:
        """Execute a repeat loop."""
        count = int(self.visit(node.count))
        
        for _ in range(count):
            for stmt in node.body:
                self.visit(stmt)
    
    def visit_WhileLoop(self, node: WhileLoop) -> None:
        """Execute a while loop."""
        while self.visit(node.condition):
            for stmt in node.body:
                self.visit(stmt)
    
    def visit_FunctionDef(self, node: FunctionDef) -> None:
        """Function definitions are handled in Program visit."""
        pass  # Functions are already registered
    
    def visit_Return(self, node: Return) -> None:
        """Execute a return statement."""
        value = self.visit(node.expression)
        raise ReturnException(value)
    
    def run(self, code: str) -> None:
        """Run a PASO program."""
        try:
            from lexer import Lexer
            from parser import Parser
            
            # Tokenize
            lexer = Lexer(code)
            tokens = lexer.tokenize()
            
            # Parse
            parser = Parser(tokens)
            ast = parser.parse()
            
            # Execute
            self.visit(ast)
            
        except LexerError as e:
            print(f"Lexer Error: {e}")
        except ParserError as e:
            print(f"Parser Error: {e}")
        except InterpreterError as e:
            print(f"Runtime Error: {e}")


def interpret(code: str) -> None:
    """Convenience function to interpret code."""
    interpreter = Interpreter()
    interpreter.run(code)
# Chapter 6 — Whispers from Home

**Sensitivity Note:** This chapter deals with uncertainty about a missing family member and conflicting reports of violence. Includes discussion of atrocities without graphic descriptions.

---

## Scene 1 — Lists and Notices

The bulletin board near the camp entrance had become a sacred space — people gathered around it every morning, faces searching for names that might bring news or closure. Lists of missing persons pinned next to casualty notices, photographs wedged between official announcements, layers of paper worn soft from countless fingers.

Mina joined the crowd daily, spending hours studying every document. Names were misspelled, dates conflicted, information was incomplete and often wrong. Ink smudges where rain had soaked through, folded paper creased from being carried and studied, handwriting that varied from careful to desperate.

*Hasan Rahman. 45. Last seen near Chittagong port. March 26.*

Not her father. Her father was Hasan Ahmed, not Rahman. But the age was right, the location was right, the last sighting date was the night they'd fled. Could it be a mistake? Could someone have misheard the name when they reported him missing?

A woman noticed Mina staring at the notice. "Your father?" she asked.

Mina nodded, unable to speak.

"My brother was taken from the same area," the woman said. "The docks. Soldiers came at midnight, rounded up all the men. No one's seen them since."

Hope rose in Mina's chest, sudden and painful. Maybe her father was there — among the taken men, alive somewhere in a camp or prison, waiting to be found. Maybe the notice meant he was alive, not dead.

"Did anyone escape?" she asked, and her voice sounded strange in her own ears.

"Some say they saw trucks heading toward the cantonment," the woman answered. "But no one knows for certain. Everyone tells different stories."

Then came the deflating detail: the raid was two months ago, and no one had returned. No survivors had come forward. No bodies had been found. Nothing but silence and uncertainty and lists that grew longer every day.

"But he could be alive," Mina insisted, though she wasn't sure who she was trying to convince.

The woman's eyes were kind but tired. "Anything is possible," she said. "But don't build your life on maybes, baba. The war takes everything, eventually. Even hope."

Mina walked away from the bulletin board, the list of names burning in her mind. Some days hope felt like the only thing keeping her alive. Other days, it felt like the thing that would kill her.

---

## Scene 2 — Conflicting Testimonies

The camp was full of stories — everyone had seen something, heard something, survived something. But the stories didn't match. Each refugee carried a piece of the truth, but the pieces didn't fit together into a coherent picture.

One man spoke of arrests: "They're taking people to prisons, holding them for questioning. They're not killing everyone."

Another woman described mass graves: "I saw the bodies. Hundreds of them, dumped in trenches outside the city. My brother —"

She stopped, unable to continue.

A third person insisted men were fleeing into the hills: "My husband joined the Mukti Bahini. He's in the forests now, fighting back. He's not dead. He's alive."

Throat-clears, shifting feet, hesitant words. Everyone wanted to believe something different. Some needed to believe their loved ones were alive in camps, waiting. Others needed to believe they'd died quickly, without suffering. Still others needed to believe in resistance, in fighting back, in the possibility of victory.

Mina was pushed between hope and dread, pulled in every direction by stories that couldn't all be true. How could she know which version was real? How could she find her father's story in this tangle of contradictions?

Then she overheard a conversation that stopped her cold.

"There was a man at the docks that night," someone said. "Older, with a girl about sixteen. He was helping people onto boats. The soldiers came, they took the men. The girl — I don't know what happened to her."

Mina's heart hammered against her ribs. Sixteen. A girl. Helping people onto boats. That could be her — she'd been at the docks with her father, watching him arrange passage for women and children.

She turned toward the voices. Two men sat near the food distribution area, faces lined with exhaustion.

"Excuse me," she said, and her voice didn't sound like her own. "The girl — what did she look like?"

The men stared at her. "Dark hair," one said finally. "Wearing a green sari, I think. She looked scared."

Mina's breath caught. She didn't own a green sari, but she'd been wearing a dark green school uniform that night. Scared — that described everyone.

"The man," she said. "Did you see his face?"

"Not clearly," the man answered. "But he was helping others, not himself. He made sure women and children got on the boats first."

That was her father. Mina knew it with sudden, terrifying certainty. The man who'd taught her the sailor's knot, who'd told her stories about resilience, who'd promised they'd rebuild after the flood. The man who'd made sure they escaped first, who'd stayed behind to help others.

The man who might be dead now, or alive in some prison, or suffering in ways she couldn't imagine.

She needed to find someone who knew more. Someone who'd seen what happened after the soldiers came.

---

## Scene 3 — An Old Photograph

Days later, Mina found the photograph in the most unlikely place — a man who'd set up a small table near the camp entrance, displaying pictures he'd collected or been given, trying to help people find lost relatives.

"I've been here since April," he said, as Mina studied the photographs spread across his table. "People give me pictures, tell me names. Sometimes we find matches. Sometimes we don't."

Photographs of weddings, school portraits, family groups — faces from a world that no longer existed. Mina's throat tightened at the sheer volume of loss represented here, the thousands of lives shattered across the paper.

Then she saw it.

A crowd at Chittagong port, taken sometime before the war. People boarding boats, loading cargo, the ordinary business of a port city. And in the background, partially obscured but unmistakable: a man who looked like her father.

The glossy crease in the photograph where it had been folded. The smell of old tobacco that clung to the paper. Her breath caught in her throat.

"That's him," she said, pointing. "That's my father."

The man leaned closer, squinting. "You're certain?"

"Yes." Mina's voice trembled. "Yes, I'm certain."

The man studied the photograph, then looked at Mina. "The person who gave me this photo said — he thought the man was taken by the patrol near the docks. The night of March twenty-sixth."

Mina's knees almost gave way. A specific lead. A thread she could follow, however thin.

"Do you know who took the photo?" she asked.

"No name," the man said. "Just someone who passed through the camp weeks ago. Said he saw the man being taken away."

"Taken where?"

The man shook his head. "That's all he knew."

Mina clung to the information like a lifeline. Her father had been seen — seen being taken, yes, but seen. That meant he was alive at that moment, alive enough to be transported somewhere. Not shot on the docks, not dumped in a mass grave.

Alive.

She bought the photograph with a few rupees she'd earned helping in the camp kitchen. The paper was worn, the image slightly faded, but it was the closest she'd come to finding him since the night they'd fled.

That evening, she lit incense in the corner of their tent, a ritual she'd learned from her mother. *For hope,* she whispered, not knowing who she was praying to anymore, or if anyone was listening.

The smoke curled upward, carrying her愿望 with it — the wish to find him, to know what happened, to have an ending instead of this endless uncertain middle.

---

## Scene 4 — Decision Night

Mina couldn't sleep. The photograph lay beside her sleeping mat, her father's face visible even in the darkness, the ghost of who he'd been.

She had to know. Not just suspect, not just hope — know. Was he alive? Was he dead? Where was he?

The options swirled through her mind, each one impossible in its own way. Send someone back to look? But who would go? Everyone in the camp was afraid to return, afraid of what they'd find, afraid of dying themselves.

Go herself? The thought was terrifying — crossing back into occupied territory, facing soldiers and checkpoints and the possibility of death. But staying here, never knowing, was also a kind of death. The death of hope, the death of certainty, the death of the part of her that still believed in happy endings.

Matches struck, flaring briefly in the darkness. A small flame reflected in her eyes, showing her the possibilities she couldn't quite name.

Her mother stirred in her sleep. Rashed breathed softly, exhausted from another day of survival. Her father — wherever he was — might be alive, or might not be. She couldn't know until she looked.

Then came the knock at their tent flap — quiet, careful, the kind of knock that meant secrets.

A stranger stood outside, a man Mina had seen around the camp but never spoken to. He had kind eyes but scarred knuckles, a contradiction between appearance and actions that made her pause.

"I heard you're looking for someone," he said, his voice low. "Your father, taken at the docks."

Mina's heart stopped. "How do you know?"

"I know things," the man said. "I can help you find out what happened to him."

"Why would you help?"

The man's expression shifted — something flickered across his face that Mina couldn't read. "Because I'm looking for someone too. And because I believe that knowing is better than not knowing, even when the truth is hard."

He pulled a grease-smudged map from his pocket, spreading it on the ground between them. "I have contacts. Ways to get information. But it's not free. Everything has a cost now."

Mina looked at the map, at the lines and markings that meant nothing to her yet, at the possibility of finally finding answers.

"I'll pay whatever it costs," she said, and the words were both promise and threat.

The man nodded, and something in his face softened. "We'll start tomorrow. Be ready."

Mina watched him walk away into the darkness, then turned back to the tent where her family slept. She had made a choice, though she didn't yet understand what it would cost her or where it would lead.

But she had chosen action over uncertainty, and that felt like something.

---

**Chapter 6 Word Count: 1,947 words**

**Research Notes:**
- **Sources Used:** Liberation War Museum archives (missing persons lists, casualty documentation), academic sources on information circulation in 1971 (newspapers, radio, NGO lists), survivor testimonies (conflicting reports, memory unreliability)
- **Historical Accuracy:** Missing persons lists were common in refugee camps; names were frequently misspelled and information inconsistent; rumors spread rapidly and were often contradictory; photographic evidence was collected and shared; information networks operated through camps
- **Facts to Verify:** Specific procedures for documenting missing persons; typical channels for information circulation; reliability of camp rumors

**Character Development:**
- Mina's shift from passive waiting to active seeking
- Father's characterization through witness accounts (helping others first)
- The stranger: introduction of morally ambiguous ally
- Mina's willingness to pay "whatever it costs" foreshadows moral complexity

**Sensory Anchors:**
- Smell: Old tobacco on photograph, incense smoke
- Sound: Throat-clears, knocking, matches striking
- Touch: Worn paper, grease-smudged map

**Bengali Terms Used:**
- Baba (father, respectful address to younger person)

**Psychological Elements:**
- Hope as both survival mechanism and potential destruction
- Conflicting testimonies creating cognitive dissonance
- Photograph as tangible connection to past/lost father
- Decision as assertion of agency in situation of powerlessness

**Thematic Elements:**
- Lists as inadequate representation of loss
- Truth vs. uncertainty: is knowing actually better?
- The cost of information: everything has a price now
- Information networks as underground resistance/aid

---

**Next Chapter Preview:** Chapter 7 — The Stranger with a Map. Mina works with the Mukti Bahini-connected stranger to gather information about her father, leading to a dangerous bargain and a witness account.
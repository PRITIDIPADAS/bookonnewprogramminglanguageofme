# Chapter 3 — Packing Silence

**Sensitivity Note:** This chapter depicts refugee displacement, including hurried packing and tense checkpoint encounters. Focuses on psychological stress and survival decisions rather than graphic violence.

---

## Scene 1 — Early Preparation

Pre-dawn darkness wrapped around them like a heavy blanket. Mina moved through the small clearing where they'd stopped to rest, gathering belongings with numb fingers. Everything felt unreal, as if she were watching herself from outside her body.

Her mother knelt by the metal trunk, hiding family photos between layers of clothes. Photographs of weddings, of Mina as a baby, of her grandmother who'd died three years ago — faces that might become ghosts if they lost them. The thin mosquito net tore as Mina tried to fold it, a small rip that seemed impossibly loud in the quiet.

The community priest appeared briefly, a dark figure in the predawn gray. He murmured a blessing over their hurried preparations, words Mina couldn't quite catch but felt nonetheless — weight, seriousness, an acknowledgment that ordinary time had ended.

Mina lifted the metal trunk and felt its weight — heavier than it should be. What was inside? Clothes, certainly. But maybe something more, something her mother wasn't saying. Papers? Money? Jewelry? She didn't ask. Some questions had no answers that helped.

Her school exercise book lay on the ground where she'd dropped it. Mina picked it up, the cover worn from months of use, her own handwriting filling the pages. Mathematics problems she'd solved, notes she'd taken, doodles in the margins. Should she take it? It wasn't practical. It wasn't survival.

But she took it anyway, tucking it into her school bag beside a blanket and a water jug. Some choices weren't practical. Some choices were about keeping pieces of yourself intact.

The eastern sky began to lighten, a pale gray that promised sunrise but not hope. Mina noticed how cold the morning air was — or maybe it was just the cold inside her, spreading outward from a center she couldn't locate.

"Are you ready?" her father asked, and his voice sounded different. Strained, thinned down to essentials.

Mina nodded, though she wasn't ready at all. How could anyone be ready for what came next?

They had everything they could carry. They had each other. It would have to be enough.

---

## Scene 2 — Farewells

The camp was stirring as they prepared to leave — other families waking, children crying, the low murmurs of people who'd been awake all night. Mina saw faces she recognized from the neighborhood, all transformed by fear and exhaustion.

Quick goodbyes in the street — no time for proper embraces, no time for words that mattered. Just nods, hand squeezes, looks that said everything and nothing at once. Rehana khala, the elderly neighbor who'd always given Mina sweets when she visited, pressed a small charm into her palm.

"Stay close to your mother's sari," she whispered, her dry papery skin against Mina's cheek. "Never look back. Whatever happens, don't look back."

The smell of garam masala clung to Rehana khala's clothes — comfort from a kitchen that might not exist anymore. Mina wanted to hold onto that smell, that small piece of ordinary life, but Rehana khala had already moved on to the next family.

Someone from their group — a young man Mina didn't know well — volunteered to check the road ahead. He never returned. Fear spread through the crowd like water, cold and inevitable. No one said what everyone was thinking. No one had to.

Mina's mother hummed something under her breath — a lullaby, maybe, but she couldn't remember the second half. The melody was incomplete, hanging in the air unfinished like everything else now.

"We need to go," her father said, and his voice left no room for argument.

Mina took one last look at the scattered camp — families huddled together, fires burning down to embers, faces illuminated by uncertain dawn light. These were people she'd known all her life, neighbors and friends and familiar strangers. Tomorrow they might be scattered across hills and rivers and borders, perhaps never to meet again.

The thought was too big to hold. Mina pushed it away and focused on her mother's sari, following its bright pattern through the crowd.

---

## Scene 3 — Checkpoints & Rumors

The road toward the coast was filled with people — hundreds, maybe thousands, all moving in the same direction. But ahead, where the road narrowed between hills, something blocked the way.

A checkpoint.

Soldiers in uniforms stood behind barriers, checking papers with deliberate slowness. The snap of leather boots against pavement, the rustle of papers, the sound of voices too low to understand. Every passing second stretched impossibly long.

"Keep walking," her father whispered. "Don't look afraid."

Mina wasn't sure how not to look afraid when her heart was hammering against her ribs, when her palms were sweating, when every instinct screamed at her to run. But she tried — she tried to keep her face neutral, her steps steady, her eyes forward.

When it was their turn, the soldier looked at their papers without interest, barely glancing at their faces. "Where are you going?"

"Cox's Bazar," her father said. "Family there."

The soldier nodded, handed back the papers. "Move on."

The tension that had been coiling in Mina's chest loosened, just slightly. They were through. They were still moving.

But others weren't so lucky. She saw a family pulled aside, their papers examined more closely. She saw a young man separated from his parents, taken behind the barrier. She saw things she couldn't quite process but would remember in nightmares for years.

A whisper ran through the crowd: "The sea route is the only safe way now. The roads are being watched."

Mina closed her eyes for a moment, rehearsing a future conversation with her father — a conversation where they were safe and laughing and none of this had happened. *Remember when we were scared,* she would say, and he would laugh, and they would both understand that fear was just a memory now.

The fantasy lasted only seconds. When she opened her eyes, the checkpoint was still there, the soldiers still standing, the road still stretching ahead uncertain and dangerous.

"We're through," her father said, and for the first time since the explosions, Mina heard something like hope in his voice.

But the hope was fragile, thin as glass. It could shatter at any moment.

---

## Scene 4 — Small Act of Generosity

The group moved more slowly now, people growing tired as the morning wore on. Mina's feet were blistered from walking in sandals not meant for distance, her throat dry from smoke inhalation and lack of water. Rashed walked beside her, his small face pale, his eyes too large in his thin face.

A stranger — a man Mina had never seen before — approached them, holding out a piece of bread. "For the boy," he said. "He looks hungry."

The bread was damp, compressed from being carried all day in the humid air. Mina took it, grateful and hesitant at the same time. Nothing was free in this world anymore. Everything had a cost.

She noticed the callus on the stranger's palm, the kindness in his exhausted face despite everything he'd been through. He'd lost something too — she could see it in his eyes, in the way he watched Rashed with an intensity that suggested memories he couldn't quite let go of.

"Thank you," she said, and meant it.

"Just pay it forward," he said, and moved on into the crowd.

Mina broke the bread into pieces, giving the largest to Rashed. He ate slowly, savoring each bite as if it were the best food he'd ever tasted. Perhaps it was.

This small moment — bread shared with a stranger, gratitude exchanged in a world stripped of grace — marked something in Mina. A shift from pure survival to something more complicated. Empathy, maybe. Or the understanding that even in the midst of catastrophe, people could still choose kindness.

The group reached the edge of town, where the buildings thinned and the road opened onto the coastal plain. The distant roar of the sea filled the air, familiar and strange at the same time. Mina had heard that sound all her life, but never like this — never as destination rather than backdrop.

Her father stopped, looking out at the water. "We'll need boats," he said. "That's the only way now."

Boats meant smugglers, bribes, dangerous crossings in overloaded vessels. Boats meant trusting strangers with their lives in water that might save them or drown them.

Mina held her breath as she walked — one long paragraph of urgency and movement and fear and hope and the terrible uncertainty of what came next. The sea spread before them, vast and merciless, offering the only path forward.

---

**Chapter 3 Word Count: 1,789 words**

**Research Notes:**
- **Sources Used:** Liberation War Museum refugee archives (camp conditions, common items packed), academic sources on 1971 refugee movements (smuggling routes, checkpoint challenges), oral histories (acts of generosity among refugees)
- **Historical Accuracy:** Documented practice of refugees hiding important papers/photos in clothing trunks; checkpoints and movement restrictions were common; smuggling networks exploited desperate refugees along coastal routes
- **Facts to Verify:** Specific checkpoint locations between Chittagong and coast; typical items refugees prioritized; common crossing points to Cox's Bazar/Teknaf

**Character Development:**
- Mina's choice to keep school book: preservation of self/identity
- Mother's hidden items in trunk: undisclosed survival preparation
- Father's strategic thinking: sea route assessment
- Rehana khala's advice: "never look back" as survival strategy

**Sensory Anchors:**
- Smell: Garam masala on Rehana khala's clothes
- Sound: Torn mosquito net, snap of leather boots
- Touch: Dry papery skin, damp bread, callus on stranger's palm

**Bengali Terms Used:**
- Khala (aunt, mother's side)
- Baba (father)

**Psychological Elements:**
- Dissociation: Mina watching herself from outside body
- Fantasy conversations as coping mechanism
- Fixation on small details (ripped net, torn paper)
- Incomplete lullaby as metaphor for broken world

---

**Next Chapter Preview:** Chapter 4 — To the Shore. The family treks to the coast, crosses rivers, encounters smugglers, and spends their first night on the beach awaiting boats to India.
"""
PASO Virtual Machine
Executes bytecode using a stack-based architecture.
"""

from typing import List, Dict, Any, Tuple, Optional


class VMError(Exception):
    """Raised when the VM encounters a runtime error."""
    pass


class VirtualMachine:
    """Stack-based virtual machine for executing PASO bytecode."""
    
    def __init__(self, bytecode: List, functions: Dict[str, Tuple[int, List[str]]], verbose: bool = False):
        self.bytecode = bytecode
        self.functions = functions
        
        # Execution state
        self.stack: List[Any] = []
        self.instruction_pointer: int = 0
        self.global_variables: Dict[str, Any] = {}
        self.call_stack: List[Tuple[int, Dict[str, Any]]] = []  # (return_ip, local_vars)
        self.local_variables: Dict[str, Any] = {}
        self.verbose = verbose
        
        # Native functions
        self.native_functions = {
            'abs': self.native_abs,
            'len': self.native_len,
            'max': self.native_max,
            'min': self.native_min,
        }
    
    def push(self, value: Any):
        """Push a value onto the stack."""
        self.stack.append(value)
        if self.verbose:
            print(f"  PUSH {repr(value)} -> Stack: {self.stack}")
    
    def pop(self) -> Any:
        """Pop a value from the stack."""
        if not self.stack:
            raise VMError("Stack underflow")
        value = self.stack.pop()
        if self.verbose:
            print(f"  POP {repr(value)} -> Stack: {self.stack}")
        return value
    
    def peek(self) -> Any:
        """Peek at the top value on the stack."""
        if not self.stack:
            raise VMError("Stack underflow")
        return self.stack[-1]
    
    def execute_instruction(self, instr) -> bool:
        """Execute a single bytecode instruction. Returns True if IP should be incremented."""
        opcode = instr.opcode
        operand = instr.operand
        
        if self.verbose:
            print(f"Executing: {instr}")
            print(f"  Stack before: {self.stack}")
        
        # Stack operations
        if opcode == BytecodeInstruction.PUSH:
            self.push(operand)
        
        elif opcode == BytecodeInstruction.POP:
            self.pop()
        
        elif opcode == BytecodeInstruction.DUP:
            self.push(self.peek())
        
        # Variable operations
        elif opcode == BytecodeInstruction.LOAD:
            # Check local variables first
            if operand in self.local_variables:
                value = self.local_variables[operand]
            elif operand in self.global_variables:
                value = self.global_variables[operand]
            elif operand in self.native_functions:
                value = self.native_functions[operand]
            else:
                raise VMError(f"Undefined variable: {operand}")
            self.push(value)
        
        elif opcode == BytecodeInstruction.STORE:
            value = self.pop()
            if self.local_variables is not None:  # In function scope
                self.local_variables[operand] = value
            else:
                self.global_variables[operand] = value
        
        # Arithmetic operations
        elif opcode == BytecodeInstruction.ADD:
            right = self.pop()
            left = self.pop()
            # Handle string concatenation
            if isinstance(left, str) or isinstance(right, str):
                self.push(str(left) + str(right))
            else:
                self.push(left + right)
        
        elif opcode == BytecodeInstruction.SUB:
            right = self.pop()
            left = self.pop()
            self.push(left - right)
        
        elif opcode == BytecodeInstruction.MUL:
            right = self.pop()
            left = self.pop()
            self.push(left * right)
        
        elif opcode == BytecodeInstruction.DIV:
            right = self.pop()
            left = self.pop()
            if right == 0:
                raise VMError("Division by zero")
            self.push(left / right)
        
        elif opcode == BytecodeInstruction.IDIV:
            right = self.pop()
            left = self.pop()
            if right == 0:
                raise VMError("Division by zero")
            self.push(int(left // right))
        
        # Comparison operations
        elif opcode == BytecodeInstruction.EQ:
            right = self.pop()
            left = self.pop()
            self.push(left == right)
        
        elif opcode == BytecodeInstruction.LT:
            right = self.pop()
            left = self.pop()
            self.push(left < right)
        
        elif opcode == BytecodeInstruction.GT:
            right = self.pop()
            left = self.pop()
            self.push(left > right)
        
        # Logical operations
        elif opcode == BytecodeInstruction.AND:
            right = self.pop()
            left = self.pop()
            self.push(left and right)
        
        elif opcode == BytecodeInstruction.OR:
            right = self.pop()
            left = self.pop()
            self.push(left or right)
        
        elif opcode == BytecodeInstruction.NOT:
            value = self.pop()
            self.push(not value)
        
        # Control flow
        elif opcode == BytecodeInstruction.JUMP:
            self.instruction_pointer = operand
            return False  # Don't increment IP
        
        elif opcode == BytecodeInstruction.JUMP_IF_FALSE:
            condition = self.pop()
            if not condition:
                self.instruction_pointer = operand
                return False  # Don't increment IP
        
        elif opcode == BytecodeInstruction.JUMP_IF_TRUE:
            condition = self.pop()
            if condition:
                self.instruction_pointer = operand
                return False  # Don't increment IP
        
        elif opcode == BytecodeInstruction.CALL:
            func_name, arg_count = operand
            
            # Check for native functions
            if func_name in self.native_functions:
                args = [self.pop() for _ in range(arg_count)]
                result = self.native_functions[func_name](*args)
                self.push(result)
                return True
            
            # Check for user-defined functions
            if func_name not in self.functions:
                raise VMError(f"Undefined function: {func_name}")
            
            func_address, params = self.functions[func_name]
            
            # Pop arguments from stack
            args = []
            for _ in range(arg_count):
                args.append(self.pop())
            
            # Save current state
            self.call_stack.append((self.instruction_pointer + 1, self.local_variables.copy()))
            
            # Set up new function context
            self.local_variables = {}
            for param, arg in zip(params, args):
                self.local_variables[param] = arg
            
            # Jump to function
            self.instruction_pointer = func_address
            return False  # Don't increment IP
        
        elif opcode == BytecodeInstruction.RETURN:
            # Get return value
            return_value = self.pop()
            
            # Restore previous context
            if not self.call_stack:
                # Returning from main program
                self.push(return_value)
                return True
            
            return_ip, prev_locals = self.call_stack.pop()
            self.instruction_pointer = return_ip
            self.local_variables = prev_locals
            
            # Push return value onto stack
            self.push(return_value)
            return False  # Don't increment IP
        
        # I/O operations
        elif opcode == BytecodeInstruction.OUTPUT:
            value = self.pop()
            print(value)
        
        elif opcode == BytecodeInstruction.INPUT:
            prompt = self.pop()
            user_input = input(prompt)
            
            # Try to convert to number
            try:
                if '.' in user_input:
                    value = float(user_input)
                else:
                    value = int(user_input)
            except ValueError:
                value = user_input
            
            if self.local_variables is not None:
                self.local_variables[operand] = value
            else:
                self.global_variables[operand] = value
        
        # System operations
        elif opcode == BytecodeInstruction.HALT:
            self.instruction_pointer = len(self.bytecode)  # Jump past end to stop
            return False  # Don't increment IP
        
        elif opcode == BytecodeInstruction.NOP:
            pass
        
        else:
            raise VMError(f"Unknown opcode: {opcode}")
        
        return True  # Increment IP by default
    
    def run(self):
        """Execute the bytecode."""
        while self.instruction_pointer < len(self.bytecode):
            instr = self.bytecode[self.instruction_pointer]
            prev_ip = self.instruction_pointer
            
            should_increment = self.execute_instruction(instr)
            
            if should_increment and self.instruction_pointer == prev_ip:
                self.instruction_pointer += 1
    
    # Native functions
    def native_abs(self, x: Any) -> Any:
        """Absolute value."""
        return abs(x)
    
    def native_len(self, x: Any) -> Any:
        """Length of string."""
        if isinstance(x, str):
            return len(x)
        raise VMError(f"len() expects a string, got {type(x)}")
    
    def native_max(self, a: Any, b: Any) -> Any:
        """Maximum of two values."""
        return max(a, b)
    
    def native_min(self, a: Any, b: Any) -> Any:
        """Minimum of two values."""
        return min(a, b)


# Import BytecodeInstruction for use in the VM
from compiler import BytecodeInstruction


def run_vm(bytecode: List, functions: Dict[str, Tuple[int, List[str]]], verbose: bool = False):
    """Convenience function to run the VM."""
    vm = VirtualMachine(bytecode, functions, verbose)
    vm.run()
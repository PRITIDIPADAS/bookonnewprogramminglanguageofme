# Chapter 5 — Camp Life

**Sensitivity Note:** This chapter depicts conditions in refugee camps including overcrowding, food scarcity, and illness. No graphic violence, but includes realistic portrayal of hardship and trauma.

---

## Scene 1 — Arrival to Camp

The camp sprawled across the landscape like a city of hopelessness — canvas tents wall-to-wall, dirt paths turning to mud, smoke from hundreds of small fires mixing with the smell of unwashed bodies and desperation.

They'd been walking for days since leaving the beach, crossing into India through border points that didn't feel like borders at all — just places where the guards looked the other way, where money changed hands, where exhausted refugees were processed like cattle.

Queues stretched endlessly in every direction. Mina and her family joined one for registration, standing in the hot sun for hours while officials with clipboards asked questions that had no good answers.

Name? Hasan. Age? Forty-seven. Origin? Chittagong. Reason for leaving? They wanted the truth: *We ran because soldiers were killing everyone, because our house might be burning, because we were afraid we would die.* But what they said was: "Political unrest."

The officials didn't care about truth anyway. They just wanted numbers, categories, ways to sort the unsortable.

After registration, they were assigned a tent — small, canvas, smelling of mildew and the families who'd lived there before them. Relief workers with clipped English moved through the camp with efficient compassion, distributing rations and blankets and promises of more to come.

Mina saw a poster on a wooden post — missing persons, names scrawled in different hands, photographs pinned to paper that had already started to yellow in the sun. Her heart skipped when she saw a name similar to her father's: *Hasan Rahman, 45, last seen in Chittagong port area.*

Not her father. Her father was alive, somewhere in this camp, or maybe still in Bangladesh, or — but her mind stopped there. She couldn't complete the thought.

She made a mental list of comforts she missed, things she'd never appreciated enough until they were gone: chalky school mornings, the taste of betel from the neighbor's house, her father's laugh echoing through their small home, the feeling of safety she'd taken for granted for sixteen years.

All gone now. The camp had replaced them with new constants: the smell of ration tins, the taste of dust in her throat, the sound of crying children that never quite stopped.

Her mother lit incense in the corner of their tent — a small defiant act of claiming space, of making this place feel like home even when it wasn't. The smoke curled up, mingling with everything else.

"We're safe here," her father said, but his voice lacked conviction. "For now."

Mina wondered if safe was a word that still had meaning.

---

## Scene 2 — The Work of Waiting

Days fell into a rhythm that was no rhythm at all — waking, queuing for food, waiting for news, sleeping, repeating. Time lost its edges, blurring into an endless cycle of survival.

Women formed networks through the camp — sharing information about food distribution, trading childcare duties, warning each other about which areas were dangerous, which relief workers could be trusted. Mina watched her mother become part of this invisible infrastructure, her quiet strength finding new purpose in exile.

Rice powder coated hands and clothes everywhere, the dust of survival. Low conversations in every corner — whispers of rumors, half-formed plans, dreams of return that no one dared speak aloud.

Clotheslines strung between tent flaps, wet saris and children's clothes drying in whatever sunlight filtered through. The mundane business of continuing to live, even when living seemed impossible.

A rumor spread through the camp like fire: lists of detainees were circulating among aid groups, names of people being held in prisons and camps across Bangladesh. Hope flared in Mina's chest, sudden and bright — maybe her father was on one of those lists. Maybe he was alive somewhere, waiting for them to find him.

But then the deflation came — someone else had already checked all the lists. His name wasn't there. He wasn't anywhere.

Or so they said. Mina didn't know who to trust anymore.

Mina traded a secret — her school exercise book, filled with mathematics problems and notes from a life that felt centuries ago — for a small favor: extra rations for Rashed, who was growing thinner by the day. The relief worker took the book with curious eyes, and Mina felt something inside her break — another piece of herself given away in exchange for her brother's survival.

The book wasn't worth much. But it was the last thing she had from school, from the girl she'd been before all this. The girl who dreamed of university, who believed in futures that could be planned, who didn't know that the world could shatter in a single night.

That girl was gone now. Mina wondered if anything of her remained.

---

## Scene 3 — Camp Politics

Tensions rose as the weeks passed — food distribution arguments that turned into shouting matches, fights over tent space, accusations of collaborators hiding among refugees. Shouted names, the clatter of metal utensils, the sound of tempers fraying under the weight of too much uncertainty.

A local leader tried to impose order — a man who'd been a minor official in Chittagong before the war, now attempting to recreate authority in a place where authority was meaningless. He organized committees, assigned duties, made rules that some followed and others ignored.

"Everyone must contribute," he announced at a camp meeting. "We must maintain order. We must show that we deserve the help we're receiving."

But deserving had nothing to do with survival. Mina understood that now. Survival was about luck, about connections, about being in the right place at the right time. Deserving didn't enter into it.

Health crises emerged — dysentery spreading through the children's section, cholera warnings, the constant threat of disease that could sweep through the camp like fire and leave no one untouched. Makeshift clinics overflowed, relief workers exhausted beyond measure, the smell of sickness joining everything else.

Rumors of Mukti Bahini contacts circulated — freedom fighters who came to the camps to recruit, to gather information, to build networks across the border. Some refugees spoke of them in whispers, as if saying their names too loudly might bring down the soldiers on everyone. Others openly declared their support, dreaming of return and revenge.

Mina overheard a conversation in Bengali between two men near the latrines: "We must be careful who we trust. Collaborators are everywhere, even here."

"I heard the Mukti Bahini is planning something big," the other answered. "Operations inside Chittagong port."

"Careful." The first man looked around, as if soldiers might be listening. "Talk like that gets people killed."

But even in this caution, Mina heard the weight of something else — not just fear, but hope. Hope that resistance was possible, that the war wasn't lost, that somehow, some way, they might win.

The hope was dangerous, fragile as glass. But it existed.

---

## Scene 4 — Night of Stories

Around the central fire, refugees gathered as night fell — drawn to the warmth and the company, to the need to speak what couldn't be spoken in daylight. The fire crackled, sending sparks upward into darkness, faces illuminated in flickering orange light.

Oral histories began to emerge — testimonies of raids, separations, atrocities that no newspaper would report, no government would acknowledge. Each story was both unique and terribly familiar, variations on the same nightmare that had shattered all their lives.

"They came to our village at dawn," a woman said, her voice flat and strange. "Woke everyone up. The men were taken first, forced to lie face down in the square. Then they —"

She stopped, unable to continue. Everyone understood what she couldn't say.

"My brother," a man spoke, his hands shaking. "They took him from the university. Said he was a student activist. We don't know where he is. We don't know if he's alive."

The stories piled up, each one another weight on Mina's chest, another brick in the wall of horror that surrounded them all. But listening was necessary — a way of bearing witness, of refusing to let the atrocities disappear into silence.

Then she heard it — a story that might be about her father.

"There was a man at the docks," someone said. "Older, maybe fifty. He was trying to get people on boats, helping women and children first. The soldiers came, they rounded up all the men. I don't know what happened to him. I think — I think they took him to the cantonment."

Mina's heart stopped. The details were wrong, but the story might still be true. Her father had been near the docks that night — she remembered him saying something about arranging passage, about making sure women and children got out first.

Could this be him? Could he be alive in the cantonment somewhere, waiting?

The crack of firewood. A woman's nasal laugh at something someone said, unexpected in this place. The metallic taste of fear in Mina's mouth, familiar now as breathing.

Mina clutched the locket between thumb and forefinger, feeling the warmth of metal against skin, the weight of everything she'd lost and everything she still hoped to find.

The questions wouldn't leave her: Was he alive? Was he dead? Was he somewhere in between, held in a camp she might never find, tortured in ways she couldn't imagine?

She needed to know. She needed the truth, whatever it was.

The night stretched on, each story another piece of a puzzle that no one could quite assemble. But in the telling, something was happening — not healing, exactly, but something that might lead toward healing eventually.

Sharing was its own kind of survival.

Mina's resolve hardened around her heart like a shell. She would find out what happened to her father. Whatever it took. Whatever the cost.

The fire burned down to embers, but the stories continued in the darkness, voices carrying into a night that was already too full of nightmares.

---

**Chapter 5 Word Count: 2,023 words**

**Research Notes:**
- **Sources Used:** Liberation War Museum refugee archives (camp conditions, food distribution, health crises), Oxfam refugee response documentation (overcrowding, diseases, NGO limitations), UNHCR historical reports (Tripura province camps, refugee numbers), academic sources on camp politics and social dynamics
- **Historical Accuracy:** Tripura province camps had more refugees than local inhabitants; overcrowding led to disease outbreaks; ration tins and canvas tents were standard; missing persons lists were common; Mukti Bahini recruitment occurred in camps; dysentery and cholera were major health threats
- **Facts to Verify:** Specific camp locations in Tripura; typical ration quantities; documented health crises and mortality rates

**Character Development:**
- Mina trades school book: sacrifice of self for family
- Mother's incense lighting: ritual as claim on space/dignity
- Father's uncertainty: breaking of protector role
- Mina's resolve to find truth: shift from survival to agency

**Sensory Anchors:**
- Smell: Mildew, ration tins, dust, unwashed bodies
- Sound: Crying children, shouted names, clatter of utensils, crackling fire
- Touch: Rice powder, canvas tent, metal locket

**Bengali Terms Used:**
- None this chapter

**Psychological Elements:**
- Mina's mental list of lost comforts as processing mechanism
- Rumors as double-edged sword (hope vs. despair)
- Oral histories as collective bearing witness
- Night of stories as communal healing attempt

**Thematic Elements:**
- Camp as liminal space: not home, not destination
- The work of waiting as its own kind of labor
- Politics in exile: power struggles, distrust, collaboration fears
- Stories as resistance against erasure

---

**Next Chapter Preview:** Chapter 6 — Whispers from Home. Mina searches lists of missing persons and casualties, encounters conflicting testimonies, and decides to investigate her father's fate more directly.
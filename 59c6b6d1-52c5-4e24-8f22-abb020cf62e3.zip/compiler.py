"""
PASO Compiler
Translates AST nodes into bytecode for the virtual machine.
"""

from typing import List, Dict, Any, Tuple
from lexer import LexerError
from parser import ParserError
from ast_nodes import *


class BytecodeInstruction:
    """A single bytecode instruction."""
    
    # Opcodes
    PUSH = "PUSH"
    POP = "POP"
    DUP = "DUP"
    LOAD = "LOAD"
    STORE = "STORE"
    ADD = "ADD"
    SUB = "SUB"
    MUL = "MUL"
    DIV = "DIV"
    IDIV = "IDIV"
    EQ = "EQ"
    LT = "LT"
    GT = "GT"
    AND = "AND"
    OR = "OR"
    NOT = "NOT"
    JUMP = "JUMP"
    JUMP_IF_FALSE = "JUMP_IF_FALSE"
    JUMP_IF_TRUE = "JUMP_IF_TRUE"
    CALL = "CALL"
    RETURN = "RETURN"
    OUTPUT = "OUTPUT"
    INPUT = "INPUT"
    HALT = "HALT"
    NOP = "NOP"
    
    def __init__(self, opcode: str, operand: Any = None):
        self.opcode = opcode
        self.operand = operand
    
    def __str__(self):
        if self.operand is not None:
            return f"{self.opcode} {repr(self.operand)}"
        return self.opcode
    
    def __repr__(self):
        return f"BytecodeInstruction({self.opcode}, {repr(self.operand)})"


class Compiler:
    """Compiles PASO AST to bytecode."""
    
    def __init__(self):
        self.instructions: List[Any] = []  # Can be BytecodeInstruction or label tuples
        self.functions: Dict[str, Tuple[int, List[str]]] = {}  # name -> (address, parameters)
        self.label_counter = 0
        self.loop_stack = []  # Stack of (continue_label, break_label)
    
    def new_label(self, prefix: str = "label") -> str:
        """Generate a new unique label."""
        label = f"{prefix}_{self.label_counter}"
        self.label_counter += 1
        return label
    
    def emit(self, instruction: BytecodeInstruction):
        """Emit a bytecode instruction."""
        self.instructions.append(instruction)
    
    def emit_label(self, label: str):
        """Emit a label (position marker)."""
        self.instructions.append((label, len(self.instructions)))
    
    def compile(self, ast: Program) -> Tuple[List[BytecodeInstruction], Dict[str, Tuple[int, List[str]]]]:
        """Compile a program to bytecode."""
        # First pass: collect function definitions
        function_defs = []
        for stmt in ast.statements:
            if isinstance(stmt, FunctionDef):
                function_defs.append(stmt)
        
        # Compile main code
        for stmt in ast.statements:
            if not isinstance(stmt, FunctionDef):
                self.visit(stmt)
        
        # Add HALT after main code
        self.emit(BytecodeInstruction(BytecodeInstruction.HALT))
        
        # Register function addresses (now after main code is compiled)
        # Count only actual instructions, not labels
        addr = 0
        for item in self.instructions:
            if isinstance(item, BytecodeInstruction):
                addr += 1
        
        for func_def in function_defs:
            self.functions[func_def.name] = (addr, func_def.parameters)
        
        # Compile function bodies
        for func_def in function_defs:
            self.compile_function(func_def)
        
        # Resolve labels and return bytecode
        bytecode, functions = self.resolve_labels()
        return bytecode, functions
    
    def compile_function(self, func_def: FunctionDef):
        """Compile a function definition."""
        for stmt in func_def.body:
            self.visit(stmt)
        
        # Add default return if none exists
        self.emit(BytecodeInstruction(BytecodeInstruction.PUSH, None))
        self.emit(BytecodeInstruction(BytecodeInstruction.RETURN))
    
    def resolve_labels(self) -> Tuple[List[BytecodeInstruction], Dict[str, Tuple[int, List[str]]]]:
        """Resolve label references and return clean bytecode."""
        # Build label address map
        label_addresses = {}
        instruction_count = 0
        
        for item in self.instructions:
            if isinstance(item, tuple) and len(item) == 2:
                # It's a label tuple: (label_name, index)
                label_name = item[0]
                label_addresses[label_name] = instruction_count
            elif isinstance(item, BytecodeInstruction):
                instruction_count += 1
        
        # Build clean bytecode with resolved jumps
        bytecode = []
        for item in self.instructions:
            if isinstance(item, BytecodeInstruction):
                # Resolve label operands
                if item.operand in label_addresses:
                    resolved_operand = label_addresses[item.operand]
                    bytecode.append(BytecodeInstruction(item.opcode, resolved_operand))
                else:
                    bytecode.append(item)
        
        return bytecode, self.functions
    
    def visit(self, node: ASTNode) -> None:
        """Visit an AST node and compile it."""
        method_name = f'visit_{type(node).__name__}'
        visitor = getattr(self, method_name, self.generic_visit)
        visitor(node)
    
    def generic_visit(self, node: ASTNode) -> None:
        """Default visitor method."""
        raise CompilerError(f"No visit method for {type(node).__name__}")
    
    def visit_NumberLiteral(self, node: NumberLiteral) -> None:
        """Compile a number literal."""
        self.emit(BytecodeInstruction(BytecodeInstruction.PUSH, node.value))
    
    def visit_StringLiteral(self, node: StringLiteral) -> None:
        """Compile a string literal."""
        self.emit(BytecodeInstruction(BytecodeInstruction.PUSH, node.value))
    
    def visit_BooleanLiteral(self, node: BooleanLiteral) -> None:
        """Compile a boolean literal."""
        self.emit(BytecodeInstruction(BytecodeInstruction.PUSH, node.value))
    
    def visit_Variable(self, node: Variable) -> None:
        """Compile a variable reference."""
        self.emit(BytecodeInstruction(BytecodeInstruction.LOAD, node.name))
    
    def visit_BinaryOp(self, node: BinaryOp) -> None:
        """Compile a binary operation."""
        self.visit(node.left)
        self.visit(node.right)
        
        # Map operator to bytecode opcode
        op_map = {
            'plus': BytecodeInstruction.ADD,
            'minus': BytecodeInstruction.SUB,
            'times': BytecodeInstruction.MUL,
            'over': BytecodeInstruction.DIV,
            'div': BytecodeInstruction.IDIV,
            'above': BytecodeInstruction.GT,
            'below': BytecodeInstruction.LT,
            'equals': BytecodeInstruction.EQ,
            'and': BytecodeInstruction.AND,
            'or': BytecodeInstruction.OR,
        }
        
        opcode = op_map.get(node.operator)
        if opcode:
            self.emit(BytecodeInstruction(opcode))
        else:
            raise CompilerError(f"Unknown operator: {node.operator}")
    
    def visit_UnaryOp(self, node: UnaryOp) -> None:
        """Compile a unary operation."""
        self.visit(node.operand)
        
        if node.operator == '-':
            # For negation, push 0 and subtract
            self.emit(BytecodeInstruction(BytecodeInstruction.PUSH, 0))
            self.emit(BytecodeInstruction(BytecodeInstruction.SUB))
        elif node.operator == 'not':
            self.emit(BytecodeInstruction(BytecodeInstruction.NOT))
        else:
            raise CompilerError(f"Unknown unary operator: {node.operator}")
    
    def visit_FunctionCall(self, node: FunctionCall) -> None:
        """Compile a function call."""
        # Push arguments in reverse order (right to left)
        for arg in reversed(node.arguments):
            self.visit(arg)
        
        self.emit(BytecodeInstruction(
            BytecodeInstruction.CALL,
            (node.name, len(node.arguments))
        ))
    
    def visit_Assignment(self, node: Assignment) -> None:
        """Compile an assignment."""
        self.visit(node.value)
        self.emit(BytecodeInstruction(BytecodeInstruction.STORE, node.variable))
    
    def visit_Output(self, node: Output) -> None:
        """Compile an output statement."""
        self.visit(node.expression)
        self.emit(BytecodeInstruction(BytecodeInstruction.OUTPUT))
    
    def visit_Input(self, node: Input) -> None:
        """Compile an input statement."""
        self.visit(node.prompt)
        self.emit(BytecodeInstruction(BytecodeInstruction.INPUT, node.variable))
    
    def visit_Conditional(self, node: Conditional) -> None:
        """Compile a conditional statement."""
        self.visit(node.condition)
        
        if node.else_branch:
            # Has else branch
            else_label = self.new_label("else")
            end_label = self.new_label("end")
            
            self.emit(BytecodeInstruction(BytecodeInstruction.JUMP_IF_FALSE, else_label))
            
            # If branch
            for stmt in node.if_branch:
                self.visit(stmt)
            
            self.emit(BytecodeInstruction(BytecodeInstruction.JUMP, end_label))
            
            # Else branch
            self.emit_label(else_label)
            for stmt in node.else_branch:
                self.visit(stmt)
            
            self.emit_label(end_label)
        else:
            # No else branch
            end_label = self.new_label("end")
            
            self.emit(BytecodeInstruction(BytecodeInstruction.JUMP_IF_FALSE, end_label))
            
            # If branch
            for stmt in node.if_branch:
                self.visit(stmt)
            
            self.emit_label(end_label)
    
    def visit_RepeatLoop(self, node: RepeatLoop) -> None:
        """Compile a repeat loop."""
        # Push counter (starts at 0)
        self.emit(BytecodeInstruction(BytecodeInstruction.PUSH, 0))
        
        start_label = self.new_label("loop_start")
        end_label = self.new_label("loop_end")
        
        self.emit_label(start_label)
        
        # Check if counter < count
        self.emit(BytecodeInstruction(BytecodeInstruction.DUP))
        self.visit(node.count)
        self.emit(BytecodeInstruction(BytecodeInstruction.LT))
        self.emit(BytecodeInstruction(BytecodeInstruction.JUMP_IF_FALSE, end_label))
        
        # Loop body
        for stmt in node.body:
            self.visit(stmt)
        
        # Increment counter
        self.emit(BytecodeInstruction(BytecodeInstruction.DUP))
        self.emit(BytecodeInstruction(BytecodeInstruction.PUSH, 1))
        self.emit(BytecodeInstruction(BytecodeInstruction.ADD))
        
        # Jump back to start
        self.emit(BytecodeInstruction(BytecodeInstruction.JUMP, start_label))
        
        # Pop counter
        self.emit_label(end_label)
        self.emit(BytecodeInstruction(BytecodeInstruction.POP))
    
    def visit_WhileLoop(self, node: WhileLoop) -> None:
        """Compile a while loop."""
        start_label = self.new_label("loop_start")
        end_label = self.new_label("loop_end")
        
        self.emit_label(start_label)
        
        # Check condition
        self.visit(node.condition)
        self.emit(BytecodeInstruction(BytecodeInstruction.JUMP_IF_FALSE, end_label))
        
        # Loop body
        for stmt in node.body:
            self.visit(stmt)
        
        # Jump back to condition
        self.emit(BytecodeInstruction(BytecodeInstruction.JUMP, start_label))
        
        self.emit_label(end_label)
    
    def visit_FunctionDef(self, node: FunctionDef) -> None:
        """Function definitions are handled in compile()."""
        pass  # Functions are compiled separately
    
    def visit_Return(self, node: Return) -> None:
        """Compile a return statement."""
        self.visit(node.expression)
        self.emit(BytecodeInstruction(BytecodeInstruction.RETURN))


class CompilerError(Exception):
    """Raised when the compiler encounters an error."""
    pass


def compile_code(code: str) -> Tuple[List[BytecodeInstruction], Dict[str, Tuple[int, List[str]]]]:
    """Convenience function to compile code."""
    from lexer import Lexer
    from parser import Parser
    
    # Tokenize
    lexer = Lexer(code)
    tokens = lexer.tokenize()
    
    # Parse
    parser = Parser(tokens)
    ast = parser.parse()
    
    # Compile
    compiler = Compiler()
    return compiler.compile(ast)
"""
PASO Lexer - Tokenizer
Converts source code text into tokens for parsing.
"""

import re
from enum import Enum
from dataclasses import dataclass


class TokenType(Enum):
    """All token types in PASO language."""
    
    # Literals
    NUMBER = "NUMBER"
    STRING = "STRING"
    IDENTIFIER = "IDENTIFIER"
    
    # Keywords
    SAVE = "SAVE"
    TO = "TO"
    SHOW = "SHOW"
    ASK = "ASK"
    WHEN = "WHEN"
    THEN = "THEN"
    ELSE = "ELSE"
    DONE = "DONE"
    REPEAT = "REPEAT"
    AGAIN = "AGAIN"
    WHILE = "WHILE"
    DO = "DO"
    FUNC = "FUNC"
    RETURN = "RETURN"
    END = "END"
    
    # Operators
    PLUS = "PLUS"
    MINUS = "MINUS"
    TIMES = "TIMES"
    OVER = "OVER"
    DIV = "DIV"
    EQUALS = "EQUALS"
    ABOVE = "ABOVE"
    BELOW = "BELOW"
    AND = "AND"
    OR = "OR"
    NOT = "NOT"
    
    # Booleans
    TRUE = "TRUE"
    FALSE = "FALSE"
    
    # Punctuation
    LPAREN = "LPAREN"
    RPAREN = "RPAREN"
    COMMA = "COMMA"
    
    # Special
    EOF = "EOF"


# Map keywords to token types
KEYWORDS = {
    'save': TokenType.SAVE,
    'to': TokenType.TO,
    'show': TokenType.SHOW,
    'ask': TokenType.ASK,
    'when': TokenType.WHEN,
    'then': TokenType.THEN,
    'else': TokenType.ELSE,
    'done': TokenType.DONE,
    'repeat': TokenType.REPEAT,
    'again': TokenType.AGAIN,
    'while': TokenType.WHILE,
    'do': TokenType.DO,
    'func': TokenType.FUNC,
    'return': TokenType.RETURN,
    'end': TokenType.END,
    'plus': TokenType.PLUS,
    'minus': TokenType.MINUS,
    'times': TokenType.TIMES,
    'over': TokenType.OVER,
    'div': TokenType.DIV,
    'equals': TokenType.EQUALS,
    'above': TokenType.ABOVE,
    'below': TokenType.BELOW,
    'and': TokenType.AND,
    'or': TokenType.OR,
    'not': TokenType.NOT,
    'true': TokenType.TRUE,
    'false': TokenType.FALSE,
}


@dataclass
class Token:
    """A token from the source code."""
    type: TokenType
    value: any
    line: int
    column: int
    
    def __str__(self):
        return f"Token({self.type.value}, {repr(self.value)}, line={self.line})"


class LexerError(Exception):
    """Raised when the lexer encounters an error."""
    pass


class Lexer:
    """Tokenizes PASO source code."""
    
    def __init__(self, text: str):
        self.text = text
        self.pos = 0
        self.line = 1
        self.column = 1
        self.current_char = self.text[0] if self.text else None
        
    def advance(self):
        """Move to the next character."""
        if self.current_char == '\n':
            self.line += 1
            self.column = 1
        else:
            self.column += 1
        
        self.pos += 1
        if self.pos >= len(self.text):
            self.current_char = None
        else:
            self.current_char = self.text[self.pos]
    
    def skip_whitespace(self):
        """Skip whitespace characters."""
        while self.current_char is not None and self.current_char.isspace():
            self.advance()
    
    def skip_comment(self):
        """Skip single-line comments (//)."""
        if self.current_char == '/' and self.pos + 1 < len(self.text):
            if self.text[self.pos + 1] == '/':
                while self.current_char is not None and self.current_char != '\n':
                    self.advance()
    
    def skip_multiline_comment(self):
        """Skip multi-line comments (/* ... */)."""
        if (self.current_char == '/' and 
            self.pos + 1 < len(self.text) and 
            self.text[self.pos + 1] == '*'):
            
            # Skip /*
            self.advance()
            self.advance()
            
            while self.current_char is not None:
                if (self.current_char == '*' and 
                    self.pos + 1 < len(self.text) and 
                    self.text[self.pos + 1] == '/'):
                    # Skip */
                    self.advance()
                    self.advance()
                    return
                self.advance()
    
    def number(self):
        """Read a number (integer)."""
        result = ''
        dot_count = 0
        
        while (self.current_char is not None and 
               (self.current_char.isdigit() or self.current_char == '.')):
            if self.current_char == '.':
                dot_count += 1
                if dot_count > 1:
                    break
            result += self.current_char
            self.advance()
        
        # Determine if integer or float
        if '.' in result:
            return float(result)
        return int(result)
    
    def string(self):
        """Read a string literal."""
        quote_char = self.current_char  # Either ' or "
        result = ''
        
        # Skip opening quote
        self.advance()
        
        while self.current_char is not None and self.current_char != quote_char:
            result += self.current_char
            self.advance()
        
        if self.current_char != quote_char:
            raise LexerError(f"Unterminated string at line {self.line}")
        
        # Skip closing quote
        self.advance()
        
        return result
    
    def identifier(self):
        """Read an identifier or keyword."""
        result = ''
        
        while (self.current_char is not None and 
               (self.current_char.isalnum() or self.current_char == '_')):
            result += self.current_char
            self.advance()
        
        # Check if it's a keyword
        if result.lower() in KEYWORDS:
            return Token(KEYWORDS[result.lower()], result.lower(), self.line, self.column)
        
        return Token(TokenType.IDENTIFIER, result, self.line, self.column)
    
    def get_next_token(self):
        """Get the next token from the source code."""
        while self.current_char is not None:
            
            if self.current_char.isspace():
                self.skip_whitespace()
                continue
            
            # Single-line comment
            if self.current_char == '/' and self.pos + 1 < len(self.text):
                if self.text[self.pos + 1] == '/':
                    self.skip_comment()
                    continue
            
            # Multi-line comment
            if self.current_char == '/' and self.pos + 1 < len(self.text):
                if self.text[self.pos + 1] == '*':
                    self.skip_multiline_comment()
                    continue
            
            # Number
            if self.current_char.isdigit():
                start_line = self.line
                start_col = self.column
                value = self.number()
                return Token(TokenType.NUMBER, value, start_line, start_col)
            
            # String
            if self.current_char in '"\'':
                start_line = self.line
                start_col = self.column
                value = self.string()
                return Token(TokenType.STRING, value, start_line, start_col)
            
            # Identifier or keyword
            if self.current_char.isalpha() or self.current_char == '_':
                return self.identifier()
            
            # Operators and punctuation
            if self.current_char == '+':
                token = Token(TokenType.PLUS, '+', self.line, self.column)
            elif self.current_char == '-':
                token = Token(TokenType.MINUS, '-', self.line, self.column)
            elif self.current_char == '*':
                token = Token(TokenType.TIMES, '*', self.line, self.column)
            elif self.current_char == '/':
                token = Token(TokenType.OVER, '/', self.line, self.column)
            elif self.current_char == '(':
                token = Token(TokenType.LPAREN, '(', self.line, self.column)
            elif self.current_char == ')':
                token = Token(TokenType.RPAREN, ')', self.line, self.column)
            elif self.current_char == ',':
                token = Token(TokenType.COMMA, ',', self.line, self.column)
            else:
                raise LexerError(
                    f"Unknown character '{self.current_char}' at line {self.line}, column {self.column}"
                )
            
            self.advance()
            return token
        
        return Token(TokenType.EOF, None, self.line, self.column)
    
    def tokenize(self):
        """Tokenize the entire source code."""
        tokens = []
        
        while True:
            token = self.get_next_token()
            tokens.append(token)
            
            if token.type == TokenType.EOF:
                break
        
        return tokens


def tokenize(code: str):
    """Convenience function to tokenize code."""
    lexer = Lexer(code)
    return lexer.tokenize()
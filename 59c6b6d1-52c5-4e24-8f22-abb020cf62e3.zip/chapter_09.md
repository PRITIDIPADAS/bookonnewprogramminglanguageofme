# Chapter 9 — The Truth Unfolds

**Sensitivity Note:** This chapter deals with confronting a family member's likely death, mourning rituals, and moral complexity. No graphic violence.

---

## Scene 1 — Returning to Camp with News

The return journey took longer than the trip out, each step heavier with the weight of what Mina carried in her pocket. The scrap of paper with her father's name, the destination noted beside it: Dhaka. That was all she had, after everything — a scrap of paper and the word *maybe* that lived in her throat.

They reached the camp just before dawn, exhausted and changed. Mina had left as a girl waiting for news; she returned as someone who'd seen too much, who understood that certainty was its own form of violence.

Her mother was waiting at the tent entrance, face lined with worry she'd been carrying for weeks. When she saw Mina, she collapsed, her body folding in on itself like something broken.

"Mina." Her mother's voice cracked. "I thought — I thought —"

"I'm here," Mina said, and the words felt inadequate. "I'm back."

The camp was the same and yet different — canvas tents, dirt paths, queues for food that never ended. But Mina saw it with new eyes now. These weren't just refugees anymore; they were survivors and victims and witnesses, each carrying stories they might never tell.

Camp dust coated her skin, settling into creases and pores. Hurried footsteps as people moved toward the food distribution center, urgent and endless. Mina watched them, wondering how many were searching like she'd searched, how many carried scraps of paper in their pockets, how many were living in the space between hope and despair.

An aid worker — a woman with compassionate eyes and efficient hands — approached them. "I heard you went looking for information," she said. "We've received new lists from the government. Confirmed fatalities."

The words hit Mina like physical blows. Confirmed fatalities. Lists of names, cold and final. Her father might be on one of those lists. Or he might not. The uncertainty was still there, thinner now but no less sharp.

"Do you have the lists?" her mother asked, and her voice was steady in a way that frightened Mina.

"Tomorrow," the aid worker said. "We'll post them tomorrow."

That night, Mina lay on her sleeping mat listening to her mother breathe, to Rashed's soft snores, to the sounds of the camp that never quite slept. She'd found something, but it wasn't the ending she'd wanted. It wasn't closure. It was just a different kind of uncertainty, sharper and more specific.

The scrap of paper in her pocket burned against her skin. *Hasan Ahmed. Transported to Dhaka.* That was her truth now, insufficient and devastating.

---

## Scene 2 — The List

The next morning, the bulletin board was crowded more than ever — people pushing, shouting, desperate for answers. Mina and her mother joined the throng, eyes scanning page after page of names.

Typewriter clack from the tent where officials worked, adding more names to the lists. Stamped paper, bureaucratic coldness, the horror of lives reduced to typed entries.

Mina's eyes moved down column after column, row after row. Names she recognized, faces she could picture, people she'd known. Each name was a story ended, a future extinguished, a family destroyed.

*Abdul Rahman. 32. Chittagong. Killed in crossfire.*

*Fatima Begum. 28. Chittagong port. Deceased.*

*Schoolboy. Age 10. Name unknown. Found near harbor.*

Mina's breath caught at each entry, each reminder of how many lives had been shattered. The war wasn't just statistics — it was individuals, each one loved, each one missed, each one irreplaceable.

Then she found it.

*Hasan Ahmed. 47. Chittagong. Transported to Dhaka for questioning. Status: Unknown.*

Unknown. Not confirmed dead, not confirmed alive. Unknown. The word was both better and worse than the alternatives — better than *deceased,* worse than *alive.* It was the word that meant her father existed in a state of suspension, neither one nor the other, lost in the bureaucratic space between certainty and ambiguity.

Her mother's breath hitched beside her. "He's not — he's not confirmed dead."

"No," Mina said, the word barely audible. "But he's not confirmed alive either."

The official standing nearby heard them. "Transported to Dhaka means special interrogation," he said, his voice flat. "Most don't survive it."

Most don't survive it. The words dropped into the silence between them, heavy and final.

"But some do," her mother insisted. "Some survive."

The official didn't answer. He didn't need to. The look on his face said everything.

Mina's sentences shortened, mimicking the shock she couldn't quite process. He was alive. He was taken. He was in Dhaka. He was — what? Tortured? Killed? Still alive somewhere, waiting? The thoughts raced through her mind, impossible to grasp or hold.

"We have to keep looking," her mother said, and her voice cracked on the words. "We have to —"

"We have to accept what we know," Mina said, though she didn't want to. "He was taken to Dhaka. That's all we know. The rest is —"

She stopped, unable to finish. The rest was hope, and hope was both survival and torture.

Her mother's eyes filled with tears, but she didn't let them fall. "Then we accept it. But we don't stop hoping."

They walked back to their tent in silence, the scrap of paper burning in Mina's pocket, the word *unknown* echoing in her mind like a bell that wouldn't stop ringing.

---

## Scene 3 — Mourning Ritual in Exile

That evening, the women of their section gathered for a mourning ritual — a small defiant act of claiming space for grief in a place that had no room for it. Wet saris from where they'd washed in the river, incense smoke curling toward the sky, folded hands and bowed heads.

Bengali mourning customs were specific and ancient — prayers for the dead, offerings to ancestors, rituals that acknowledged loss while honoring the memory of what was lost. But here, in exile, with no graves to visit and no bodies to mourn, the rituals had adapted, become something new.

Mina's mother broke down, her body shaking with sobs she'd been holding in for weeks. Other women gathered around her, touching her shoulders, murmuring words of comfort that meant everything and nothing at the same time. Social support was its own kind of survival — acknowledging that grief existed even when closure didn't.

The ritual both soothed and complicated. It gave shape to the formless horror of loss, provided a structure for pain that otherwise threatened to consume everything. But it also required accepting something Mina wasn't ready to accept — that her father was truly gone, that there would be no reunion, that the uncertainty was permanent.

Then came the complicating detail, whispered from woman to woman like a secret too dangerous to speak aloud: "Someone claims to have seen Hasan Ahmed after the raid. With collaborators. Not as a prisoner, but as —" The woman couldn't finish, didn't need to.

The implication was clear: her father might be collaborating, might be working with the enemy, might have betrayed everything he believed in. It was impossible and yet possible, contradictory and yet somehow plausible.

Ritual both soothed and complicated. It provided comfort while raising new horrors. It acknowledged loss while suggesting that loss might be more complicated than simple death.

Mina's mother wiped her eyes, straightened her spine. "My husband is no collaborator," she said, her voice fierce. "Whatever anyone says. Whatever they think they saw."

But doubt had already planted itself, a seed that would grow in the darkness of uncertainty. Collaborators weren't monsters — they were people who made choices under impossible pressure. What if her father had made a different choice than the one Mina wanted to believe in?

The ritual ended with women returning to their tents, carrying grief that had been given shape but not resolution. Mina lay on her sleeping mat, the scrap of paper still in her pocket, the word *unknown* echoing in her mind like a bell that wouldn't stop ringing.

---

## Scene 4 — Moral Complexity

Mina couldn't sleep. The scrap of paper lay beside her, her father's name visible even in the darkness: *Hasan Ahmed. Transported to Dhaka. Status: Unknown.*

Around her, the camp breathed — coughs, murmurs, the soft sounds of people trying to sleep in impossible circumstances. The cold metal railing she leaned against when she couldn't stay inside anymore, pressing against her back.

The questions wouldn't leave her: Was her father alive? Was he dead? Was he something in between — collaborating to save his family, or refusing to collaborate and suffering the consequences, or making choices she couldn't understand from this distance?

Hero. Victim. Something more complicated.

The war had stripped away easy categories. Collaborators weren't simply evil — they were people who'd made choices, often under threat to their families. Freedom fighters weren't simply good — they'd also made choices, some necessary, some questionable, all costly.

Her father had made choices too. Helping people escape at the docks — that was heroism, certainly. But what about before that? What about the years of silence, the refusal to get involved, the careful neutrality that had let the danger grow unchecked?

Silence is a choice too, Halima had said. And now Mina understood what that meant. Her father's silence might have been caution, or it might have been complicity. His help at the docks might have been courage, or it might have been too little too late.

The cold metal rail pressed into her back, a sharp reminder of the hardness of everything now. There were no easy answers, no clean categories, no simple narratives of good and evil. Just people making choices under impossible circumstances, living with consequences they couldn't fully understand.

Mina chose a path — not forgiveness exactly, and not condemnation either. Something in between. Something that acknowledged complexity while refusing to let complexity become an excuse for everything.

She would keep hoping her father was alive, but she wouldn't let hope blind her to the possibility that he'd made choices she couldn't approve of. She would keep searching for the truth, but she wouldn't let the search consume her or the people around her.

The ending refused closure, refused satisfaction. The truth was messy and incomplete, a scrap of paper with a destination noted beside a name: *Dhaka. Unknown.*

That was her truth now, and she would have to live with it.

---

**Chapter 9 Word Count: 1,987 words**

**Research Notes:**
- **Sources Used:** Liberation War Museum archives (casualty lists, Dhaka detention centers), academic sources on mourning practices in exile, research on collaborator complexity and moral ambiguity
- **Historical Accuracy:** Casualty lists were maintained by various organizations; Dhaka had special interrogation facilities; status "unknown" was common for detainees; mourning rituals adapted in exile; collaborator accusations were common and often complex
- **Facts to Verify:** Specific procedures for documenting detainees; Dhaka detention conditions; typical outcomes of special interrogation

**Character Development:**
- Mother's breakdown and recovery: strength through community
- Mina's acceptance of ambiguous truth
- Father's complexity: heroism vs. silence vs. possible collaboration
- Mourning ritual as both comfort and complication

**Sensory Anchors:**
- Smell: Wet saris, incense smoke
- Sound: Typewriter clack, sobbing, bell-like echo
- Touch: Cold metal railing, scrap of paper

**Bengali Terms Used:**
- None this chapter

**Psychological Elements:**
- Certainty as its own form of violence
- "Unknown" as torture (better than death, worse than life)
- Mourning ritual as giving shape to formless grief
- Doubt as seed planted in darkness

**Thematic Elements:**
- Lists as bureaucratic reduction of lives
- Mourning in exile: rituals without graves
- Moral complexity: no easy categories
- Silence as choice: complicity vs. caution

---

**Next Chapter Preview:** Chapter 10 — Reckoning and Choice. Mina confronts the collaborator accusation, faces political pressure in the camp, and chooses her path forward amid ongoing uncertainty.
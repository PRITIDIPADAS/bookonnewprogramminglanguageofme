"""
PASO Parser
Builds an Abstract Syntax Tree from tokens.
"""

from typing import List, Optional
from lexer import Lexer, Token, TokenType, LexerError
from ast_nodes import *


class ParserError(Exception):
    """Raised when the parser encounters an error."""
    pass


class Parser:
    """Parses PASO source code into an AST."""
    
    def __init__(self, tokens: List[Token]):
        self.tokens = tokens
        self.pos = 0
        self.current_token = self.tokens[0] if self.tokens else None
    
    def error(self, message: str):
        """Raise a parser error with context."""
        if self.current_token:
            raise ParserError(
                f"Parse error at line {self.current_token.line}: {message}"
            )
        else:
            raise ParserError(f"Parse error at end of file: {message}")
    
    def advance(self):
        """Move to the next token."""
        self.pos += 1
        if self.pos < len(self.tokens):
            self.current_token = self.tokens[self.pos]
        else:
            self.current_token = None
    
    def expect(self, token_type: TokenType) -> Token:
        """Expect a specific token type, raise error if not found."""
        if (self.current_token and 
            self.current_token.type == token_type):
            token = self.current_token
            self.advance()
            return token
        else:
            self.error(
                f"Expected {token_type.value}, got {self.current_token.type.value if self.current_token else 'EOF'}"
            )
    
    def peek(self) -> Optional[Token]:
        """Look at the next token without consuming it."""
        if self.pos + 1 < len(self.tokens):
            return self.tokens[self.pos + 1]
        return None
    
    def parse(self) -> Program:
        """Parse the entire program."""
        statements = []
        
        while self.current_token and self.current_token.type != TokenType.EOF:
            # Skip empty lines (this is handled by the lexer mostly)
            stmt = self.statement()
            if stmt:
                statements.append(stmt)
        
        return Program(statements)
    
    def statement(self) -> Optional[Statement]:
        """Parse a statement."""
        if not self.current_token:
            return None
        
        if self.current_token.type == TokenType.SAVE:
            return self.assignment()
        elif self.current_token.type == TokenType.SHOW:
            return self.output()
        elif self.current_token.type == TokenType.ASK:
            return self.input()
        elif self.current_token.type == TokenType.WHEN:
            return self.conditional()
        elif self.current_token.type == TokenType.REPEAT:
            return self.repeat_loop()
        elif self.current_token.type == TokenType.WHILE:
            return self.while_loop()
        elif self.current_token.type == TokenType.FUNC:
            return self.function_def()
        elif self.current_token.type == TokenType.RETURN:
            return self.return_stmt()
        else:
            # Try to parse as expression statement
            expr = self.expression()
            return expr  # Expression statements are allowed
    
    def assignment(self) -> Assignment:
        """Parse assignment: save expr to var"""
        self.expect(TokenType.SAVE)
        
        value = self.expression()
        self.expect(TokenType.TO)
        
        var_name = self.expect(TokenType.IDENTIFIER).value
        
        return Assignment(var_name, value)
    
    def output(self) -> Output:
        """Parse output: show expr"""
        self.expect(TokenType.SHOW)
        expr = self.expression()
        return Output(expr)
    
    def input(self) -> Input:
        """Parse input: ask "prompt" to var"""
        self.expect(TokenType.ASK)
        prompt = self.expression()
        self.expect(TokenType.TO)
        var_name = self.expect(TokenType.IDENTIFIER).value
        return Input(prompt, var_name)
    
    def conditional(self) -> Conditional:
        """Parse conditional: when expr then stmts else stmts done"""
        self.expect(TokenType.WHEN)
        condition = self.expression()
        self.expect(TokenType.THEN)
        
        if_branch = []
        while (self.current_token and 
               self.current_token.type not in [TokenType.ELSE, TokenType.DONE]):
            stmt = self.statement()
            if stmt:
                if_branch.append(stmt)
        
        else_branch = None
        if self.current_token and self.current_token.type == TokenType.ELSE:
            self.advance()
            else_branch = []
            while (self.current_token and 
                   self.current_token.type != TokenType.DONE):
                stmt = self.statement()
                if stmt:
                    else_branch.append(stmt)
        
        self.expect(TokenType.DONE)
        return Conditional(condition, if_branch, else_branch)
    
    def repeat_loop(self) -> RepeatLoop:
        """Parse repeat loop: repeat expr stmts again"""
        self.expect(TokenType.REPEAT)
        count = self.expression()
        
        body = []
        while (self.current_token and 
               self.current_token.type != TokenType.AGAIN):
            stmt = self.statement()
            if stmt:
                body.append(stmt)
        
        self.expect(TokenType.AGAIN)
        return RepeatLoop(count, body)
    
    def while_loop(self) -> WhileLoop:
        """Parse while loop: while expr do stmts done"""
        self.expect(TokenType.WHILE)
        condition = self.expression()
        self.expect(TokenType.DO)
        
        body = []
        while (self.current_token and 
               self.current_token.type != TokenType.DONE):
            stmt = self.statement()
            if stmt:
                body.append(stmt)
        
        self.expect(TokenType.DONE)
        return WhileLoop(condition, body)
    
    def function_def(self) -> FunctionDef:
        """Parse function definition: func name(params) stmts end"""
        self.expect(TokenType.FUNC)
        
        name = self.expect(TokenType.IDENTIFIER).value
        
        self.expect(TokenType.LPAREN)
        parameters = []
        
        if (self.current_token and 
            self.current_token.type == TokenType.IDENTIFIER):
            parameters.append(self.current_token.value)
            self.advance()
            
            while (self.current_token and 
                   self.current_token.type == TokenType.COMMA):
                self.advance()
                param_name = self.expect(TokenType.IDENTIFIER).value
                parameters.append(param_name)
        
        self.expect(TokenType.RPAREN)
        
        body = []
        while (self.current_token and 
               self.current_token.type != TokenType.END):
            stmt = self.statement()
            if stmt:
                body.append(stmt)
        
        self.expect(TokenType.END)
        return FunctionDef(name, parameters, body)
    
    def return_stmt(self) -> Return:
        """Parse return statement: return expr"""
        self.expect(TokenType.RETURN)
        expr = self.expression()
        return Return(expr)
    
    # ============ Expression Parsing ============
    
    def expression(self) -> Expression:
        """Parse an expression (logical OR)."""
        return self.logical_or()
    
    def logical_or(self) -> Expression:
        """Parse logical OR: and_expr ('or' and_expr)*"""
        node = self.logical_and()
        
        while self.current_token and self.current_token.type == TokenType.OR:
            op = self.current_token.value
            self.advance()
            right = self.logical_and()
            node = BinaryOp(op, node, right)
        
        return node
    
    def logical_and(self) -> Expression:
        """Parse logical AND: comparison ('and' comparison)*"""
        node = self.comparison()
        
        while self.current_token and self.current_token.type == TokenType.AND:
            op = self.current_token.value
            self.advance()
            right = self.comparison()
            node = BinaryOp(op, node, right)
        
        return node
    
    def comparison(self) -> Expression:
        """Parse comparison: additive (('above' | 'below' | 'equals') additive)*"""
        node = self.additive()
        
        while (self.current_token and 
               self.current_token.type in [TokenType.ABOVE, TokenType.BELOW, TokenType.EQUALS]):
            op = self.current_token.value
            self.advance()
            right = self.additive()
            node = BinaryOp(op, node, right)
        
        return node
    
    def additive(self) -> Expression:
        """Parse additive: multiplicative (('plus' | 'minus') multiplicative)*"""
        node = self.multiplicative()
        
        while (self.current_token and 
               self.current_token.type in [TokenType.PLUS, TokenType.MINUS]):
            op = self.current_token.value
            self.advance()
            right = self.multiplicative()
            node = BinaryOp(op, node, right)
        
        return node
    
    def multiplicative(self) -> Expression:
        """Parse multiplicative: unary (('times' | 'over' | 'div') unary)*"""
        node = self.unary()
        
        while (self.current_token and 
               self.current_token.type in [TokenType.TIMES, TokenType.OVER, TokenType.DIV]):
            op = self.current_token.value
            self.advance()
            right = self.unary()
            node = BinaryOp(op, node, right)
        
        return node
    
    def unary(self) -> Expression:
        """Parse unary: ('not' | '-')? primary"""
        if (self.current_token and 
            self.current_token.type in [TokenType.NOT, TokenType.MINUS]):
            op = self.current_token.value
            self.advance()
            operand = self.unary()
            return UnaryOp(op, operand)
        
        return self.primary()
    
    def primary(self) -> Expression:
        """Parse primary: number | string | bool | identifier | call | '(' expr ')'"""
        if not self.current_token:
            self.error("Unexpected end of input")
        
        # Number literal
        if self.current_token.type == TokenType.NUMBER:
            value = self.current_token.value
            self.advance()
            return NumberLiteral(value)
        
        # String literal
        if self.current_token.type == TokenType.STRING:
            value = self.current_token.value
            self.advance()
            return StringLiteral(value)
        
        # Boolean literal
        if self.current_token.type == TokenType.TRUE:
            self.advance()
            return BooleanLiteral(True)
        
        if self.current_token.type == TokenType.FALSE:
            self.advance()
            return BooleanLiteral(False)
        
        # Parenthesized expression
        if self.current_token.type == TokenType.LPAREN:
            self.advance()
            expr = self.expression()
            self.expect(TokenType.RPAREN)
            return expr
        
        # Identifier or function call
        if self.current_token.type == TokenType.IDENTIFIER:
            name = self.current_token.value
            self.advance()
            
            # Check for function call
            if self.current_token and self.current_token.type == TokenType.LPAREN:
                return self.function_call(name)
            
            return Variable(name)
        
        self.error(
            f"Unexpected token: {self.current_token.type.value}"
        )
    
    def function_call(self, name: str) -> FunctionCall:
        """Parse function call: name '(' args? ')'"""
        self.expect(TokenType.LPAREN)
        
        arguments = []
        
        if (self.current_token and 
            self.current_token.type != TokenType.RPAREN):
            arguments.append(self.expression())
            
            while (self.current_token and 
                   self.current_token.type == TokenType.COMMA):
                self.advance()
                arguments.append(self.expression())
        
        self.expect(TokenType.RPAREN)
        return FunctionCall(name, arguments)


def parse(code: str) -> Program:
    """Convenience function to parse code."""
    lexer = Lexer(code)
    tokens = lexer.tokenize()
    parser = Parser(tokens)
    return parser.parse()
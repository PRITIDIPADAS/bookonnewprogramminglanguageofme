# Chapter 11 — After the Smoke

**Sensitivity Note:** This chapter depicts the return journey after independence, confronting destroyed homes, and the beginning of rebuilding. No graphic violence.

---

## Scene 1 — News of Independence

The radio announcement came at dawn, catching everyone by surprise even though they'd been waiting for it for months.

*"Pakistan forces have surrendered. Bangladesh is free."*

The words were simple, impossible, transformative. For a moment, the camp held its collective breath — thousands of people unable to process what they were hearing, unable to believe that after everything, after the losses and the uncertainty and the endless waiting, it was actually over.

Then the celebrations began.

Celebratory horns from the few vehicles in the camp, people shouting, children running wildly. Cautious smiles that couldn't quite believe this was real. The aid workers — exhausted from months of impossible work — allowed themselves moments of joy, hugging refugees who'd become more than just people they were helping.

Mina stood by the tent entrance, watching it all, feeling both celebration and grief simultaneously. Her father wasn't here to see this. Would never see this. Whatever choices he'd made, whatever happened to him in Dhaka, he was gone — and the victory was incomplete without him.

Plans for repatriation surfaced immediately. The Indian government announced that refugees could begin returning home, that transport would be provided, that Bangladesh would welcome its people back. The logistics were overwhelming, but the possibility of return was real.

Mina's mother cried when she heard the news — tears of relief and tears that would never stop flowing. Rashed asked if they would really go home, if their house was still there, if everything could be the way it was before.

"Not the same," Mina said, because she understood now that nothing would ever be the same. "But we'll go back. We'll rebuild."

The word *rebuild* had new meaning now — not just fixing what was broken, but creating something new from the wreckage. Different, but continuous. Like her father had said about the flood of 1954: people returned, they rebuilt, life continued.

He wasn't here to see the continuation. But they would do it anyway.

---

## Scene 2 — Return Journey

The journey back took longer than the journey out — trains and trucks and walking, the same roads in reverse, everything both familiar and strange. The reek of mud and rotting vegetation from the monsoon rains, boats floating upturned in rivers swollen beyond their banks.

Mina watched the landscape change as they moved closer to Chittagong — hills that had always been there, rivers she'd crossed a thousand times, villages she recognized but couldn't quite place. Everything was the same and different, overlaid with memories of the journey out and the impossibility of simply going back.

As they approached the city, they saw the evidence of occupation and resistance — buildings pockmarked with bullets, walls collapsed from shelling, roads cratered by explosions. Signs of collaborators being punished — houses marked with paint, people gathering in angry crowds, the ugly aftermath of liberation.

Her mother held Rashed's hand tightly, as if afraid he might disappear into this changed landscape. Mina felt the same fear, but she forced it down. They were here. They were back. Whatever they found, they would face it together.

The truck dropped them at the edge of their neighborhood — the place that had been home for sixteen years, now transformed by everything that had happened. Mina hesitated before entering the street, her feet refusing to move forward for a long moment.

This was it. The moment she'd been both waiting for and dreading. The place where her father had lived, where he'd made choices, where he'd disappeared into the uncertainty of *unknown*.

"Come," her mother said, and her voice was steadier than Mina felt. "We're home."

The word *home* was wrong — this place wasn't home anymore, not really. But it was theirs, and they had to claim it.

---

## Scene 3 — Rebuilding

Their house was still standing, but only barely. The roof had partially collapsed, windows were shattered, walls were stained with smoke and something darker that Mina didn't want to identify. Inside, everything was either gone or broken — furniture overturned, dishes smashed, photographs torn or missing.

They began the work of scavenging what could be saved, meeting neighbors who'd returned to similar destruction. Everyone had stories — of hiding, of losing, of surviving in impossible ways. Everyone had someone who hadn't returned, someone whose fate was still unknown, someone whose absence made the victory hollow.

Mildew covered everything, the smell of decay and abandonment. Hammer on wood as her mother began the slow work of repairs, hammering nails into boards that would replace shattered windows, trying to make the house habitable again.

One neighbor — a woman Mina had known all her life — told them what had happened on their street. "Soldiers came that first night," she said. "Took men, burned houses. Your father —" She hesitated. "He wasn't here. He must have already been at the docks."

The docks. The place where he'd helped others escape. The place where he'd been rounded up and taken away. The place where his choices had led to this moment of standing in a ruined house, wondering what he'd been and what he'd done.

Another neighbor spoke up, his voice tight. "I saw him," he said. "Before the soldiers came. He was warning people, telling them to get out. He helped my family get to the boats. He saved us."

Mina's breath caught. This was the father she wanted to believe in — the man who helped others even when it cost him, the man who made the right choices even under impossible pressure.

But she remembered the woman in the camp, the accusation of collaboration, the possibility that her father had made different choices too. The truth was probably somewhere in between — not entirely good, not entirely bad, just human and complicated and impossible to fully understand.

Mina decided to resume schooling, to pick up where the war had interrupted everything. The school was damaged but functioning, teachers struggling to maintain some semblance of education in the aftermath of catastrophe. She enrolled in the night class that had been organized for students who'd lost months or years of study.

The decision felt like both continuation and new beginning — returning to the path she'd been on before the war, but as someone different now, someone who understood that education wasn't just about personal advancement but about rebuilding something larger than herself.

A specific detail anchored her memory: a paint flake on the wall, yellow and bright, a remnant of the room she'd shared with Rashed before everything changed. She touched it, feeling the connection to the past, to the girl she'd been, to the father who'd chosen this paint, who'd made a home that no longer existed.

---

## Scene 4 — Memory Work

A small memorial was organized in the neighborhood square — a place to remember those who hadn't returned, to acknowledge the losses that made victory incomplete. Marigold garlands draped across a simple wooden structure, soft soil underfoot where people were planting small offerings.

Mina helped set up the memorial, arranging flowers and photographs, talking to neighbors about whom they'd lost. The work was difficult and necessary — giving shape to grief that had been formless for months, creating a space where memory could exist without consuming everything.

She had to choose what to remember publicly and what to keep private. Her father's name would go on the memorial — Hasan Ahmed, taken to Dhaka, status unknown. That was the public truth, the version that could be shared with others, that could become part of the collective story of the neighborhood's loss.

But the private truth was more complicated. The father who'd taught her to tie knots, who'd helped others escape, who might also have collaborated, who'd made choices she couldn't fully understand or approve of. That truth would stay inside her, unresolved and unresolved, the way some things had to stay.

Mina placed something at the memorial — not a photograph, because she didn't have one to spare, but her school exercise book, the one she'd traded away and then earned back through weeks of work in the camp kitchen. The book was filled with mathematics problems and notes from a life that felt centuries ago, but it was also filled with her handwriting, her learning, her determination to continue.

The book represented everything she'd chosen: education over violence, memory over revenge, the slow work of rebuilding over the quick satisfaction of fighting. It was her offering to the memorial, her statement about what kind of future she wanted to build.

Other neighbors placed their own offerings — photographs, pieces of clothing, small objects that had belonged to the lost. The memorial grew, layer upon layer, becoming a palimpsest of grief and memory and hope that things could somehow be different in the future.

Mina stood back and looked at what they'd created — not a resolution, but a beginning. A place where loss could be acknowledged without consuming everything. A space where memory could exist alongside the work of rebuilding.

The marigolds were bright against the gray sky, the soft soil yielding under her feet. This was what her father had tried to teach her: that floods recede, that people return, that life continues. Not the same as before, but continuous nonetheless.

She would have to learn how to live with the unknown — with her father's fate suspended between alive and dead, hero and collaborator and something more complicated. But for now, in this moment, there was the memorial, and the work of rebuilding, and the possibility of a different future.

That would have to be enough.

---

**Chapter 11 Word Count: 1,876 words**

**Research Notes:**
- **Sources Used:** Liberation War Museum archives (repatriation process, post-war rebuilding), historical documentation of independence announcement, research on post-war justice and collaborator punishment
- **Historical Accuracy:** Pakistan surrendered on December 16, 1971; refugee repatriation began in 1972; homes were often damaged or destroyed; collaborators faced punishment; memorials were common in neighborhoods; education resumed in damaged schools
- **Facts to Verify:** Specific repatriation timeline; extent of housing damage; typical post-war justice processes

**Character Development:**
- Mina's return as transformed person
- Mother's resilience through practical work
- Neighbor testimonies provide conflicting/fleshed-out picture of father
- Mina's choice of education as contribution to rebuilding

**Sensory Anchors:**
- Smell: Mildew, decay, marigolds
- Sound: Celebratory horns, hammer on wood
- Touch: Soft soil, paint flake, marigold petals

**Bengali Terms Used:**
- None this chapter

**Psychological Elements:**
- Celebration mixed with grief: incomplete victory
- Home as both familiar and strange
- Memory as layered: public vs. private truth
- Rebuilding as continuous rather than restorative

**Thematic Elements:**
- Independence as both victory and loss
- Return as confrontation with changed reality
- Collaborator punishment as ugly aftermath
- Memorial as space for collective grief

---

**Next Chapter Preview:** Chapter 12 — Memory and Tomorrow. Years later, Mina visits the memorial, mentors a child, and passes on the locket in a scene of quiet resilience and hope.
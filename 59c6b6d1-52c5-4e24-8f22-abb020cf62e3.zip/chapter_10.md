# Chapter 10 — Reckoning and Choice

**Sensitivity Note:** This chapter includes political pressure in refugee camps and confrontation about collaborator accusations. No graphic violence.

---

## Scene 1 — Political Pressure

The camp changed as the war dragged on — tensions that had simmered below the surface now boiled over, dividing refugees into camps that had nothing to do with where they slept. Politics had found them even here, in exile, where survival should have been the only thing that mattered.

Flyers appeared overnight, plastered on tent walls and bulletin boards, calling for volunteers to join the Mukti Bahini. *Fight for freedom!* the flyers proclaimed. *Defend Bangladesh!* The words were stirring, but Mina saw the exhausted faces of recruiters, heard the desperation in their voices as they tried to convince people who'd lost everything to risk losing what little remained.

Hurried whispers in every corner — arguments about whether to fight, whether to wait, whether resistance was worth the cost. The camp had become a microcosm of the war itself, all the debates and divisions compressed into this small space of canvas and dirt.

An exiles' meeting was called at the central tent, people gathering from all sections to hear proposals and counter-proposals, to argue about the best path forward. Mina and her mother attended out of curiosity, or maybe just out of the need to be part of something larger than their own private grief.

A recruiter took the stage — a man Mina's age, or maybe a year older, with hollow eyes and clothes that had seen better days. His name was Rafiq, and he'd been a university student in Dhaka before the war.

"We need fighters," he said, his voice passionate but ragged. "We need medical support. We need people who can carry messages, gather information, do whatever's necessary. The Mukti Bahini is organized now. We have training, we have weapons, we have a plan."

The room was silent, everyone holding their breath.

"But we also need something else," Rafiq continued. "We need commitment. We need people who understand that this isn't just about winning. It's about what kind of country we build when we do win. About justice, about accountability, about not repeating the mistakes of the past."

He looked around the room, his gaze landing on each person in turn. When he reached Mina, his eyes lingered, and she felt herself being seen, really seen, for the first time since leaving Chittagong.

"What will you fight for?" he asked, and it wasn't a rhetorical question. "Freedom, yes. But what else? What kind of freedom? What kind of justice?"

The question hung in the air, impossible and necessary.

Mina thought about her father — about the man who'd helped others escape at the docks, who'd made choices under impossible pressure, whose fate was still unknown, suspended between alive and dead, hero and collaborator and something more complicated.

She thought about Tariq, captured on the hill because she'd insisted on making the journey, because she'd needed to know the truth, because she'd been willing to risk others for her own answers.

She thought about everything she'd lost, and everything she still had to lose.

"What will you fight for?" Rafiq asked again, and this time Mina understood that the question was for her specifically.

---

## Scene 2 — Confrontation

The rumor had been spreading for days — someone in the camp claiming to have information about her father, about his collaboration, about choices he'd made that no one wanted to believe. Mina had ignored it until now, but the whispers had grown too loud to pretend they didn't exist.

She found the woman near the food distribution center — someone Mina didn't recognize, a stranger who'd arrived recently with stories that might or might not be true.

"I heard you're talking about my father," Mina said, and her voice was steady in a way that surprised her.

The woman looked up, startled. "Who are you?"

"His daughter. Mina."

The woman's expression shifted — defiance, then calculation, then something that might have been guilt. "I saw him," she said. "With collaborators. Near the cantonment. He wasn't a prisoner. He was — talking with them. Like he was one of them."

Mina's stomach turned. The rustle of her own sari as she shifted, the smell of garlic on someone's clothes nearby — small details that made the moment impossibly real.

"You're lying," Mina said.

"Am I?" The woman's eyes were cold. "Why would I lie? What do I gain from it?"

"Attention," Mina said. "The satisfaction of destroying someone's memory. I don't know why people do what they do."

The woman stood up, and for the first time Mina noticed how thin she was, how worn her clothes were, how desperation marked every line of her face. "I lost my husband," she said. "To collaborators. To people like your father, if what I saw is true."

"If," Mina said. "If what you saw is true."

"I saw what I saw," the woman insisted. "He was walking with them, not as a prisoner. He was helping them. He pointed out houses. He —"

"Stop." Mina's voice cracked, but she forced it steady. "Just stop."

The confrontation ended with no clear answer — only a choice. Believe the woman, or not. Accept that her father might have collaborated, or hold onto the version of him she wanted to believe in. There was no evidence, no proof, nothing but the word of a stranger who'd lost everything and might be looking for someone to blame.

Mina walked away, the accusation following her like smoke she couldn't escape. The rustle of saris, the smell of garlic, the woman's thin face — all of it burned into her memory.

This was what war did — it made everything uncertain, even memory, even the people you thought you knew best. It turned fathers into monsters and strangers into truth-tellers and truth into something you could no longer recognize.

---

## Scene 3 — Choosing a Future

The days that followed were a blur of small choices — waking, eating, waiting, sleeping. But beneath the routine, something was shifting, crystallizing into certainty.

Mina found herself returning to the camp's makeshift school, where a volunteer teacher was trying to maintain some semblance of education for the children. A borrowed pen in her hand, old notebooks spread across a low table — these small things felt like anchors in a world of uncertainty.

She began helping with the younger children, teaching them basic mathematics and reading, watching their faces light up with understanding. The work was small, insignificant in the grand scheme of the war, but it mattered. It was something she could do that didn't risk anyone's life, that didn't require her to make impossible choices about violence and resistance and who deserved to live or die.

But the recruiters kept coming, their appeals growing more desperate as the war intensified. *Fight for freedom,* they said. *Build the country we want.*

Mina thought about what kind of country she wanted. Not just freedom from occupation, but freedom from the cycles of violence that had destroyed her family, freedom from the choices that turned fathers into monsters and strangers into accusers, freedom from the uncertainty that lived in the word *unknown.*

She thought about her father — about the man who'd helped others escape at the docks, who'd made choices under impossible pressure, whose fate was still suspended between alive and dead. Whatever he'd done, whatever choices he'd made, she wanted to believe that at the end, he'd chosen to help.

So she chose education over violence, memory over revenge, the slow work of rebuilding over the quick satisfaction of fighting. She signed up to teach in the camp school, committing herself to the children who'd lost so much already.

Mending a tear in Rashed's shirt that evening, Mina felt something settle inside her — not peace exactly, but purpose. Tucking the locket back inside her blouse, feeling its warmth against her skin, she understood that this was her choice, her path, her way of honoring whatever her father had been, whatever choices he'd made.

The recruiter, Rafiq, found her the next day. "I heard what you decided," he said, and his voice was kind rather than disappointed. "Teaching instead of fighting."

"It's what I can do," Mina said. "What I believe in."

Rafiq nodded. "We need both," he said. "Fighters and builders. The war will end eventually, and someone will need to rebuild what's been broken."

He paused, looking at her with eyes that had seen too much for his age. "Your father — I heard about him. Helping people escape at the docks. That was brave."

Or maybe it was just one choice among many, some good and some bad, some heroic and some cowardly, all complicated by the impossible pressure of war. Mina didn't say this aloud. She just nodded, accepting the kindness without letting it become something it couldn't be.

---

## Scene 4 — Quiet Resolve

That evening, Mina sat by the campfire writing a letter she might never send — a private ledger of grief and intent, words she couldn't say aloud but needed to write down anyway.

*Dear Baba,*

*I don't know if you're alive or dead. I don't know if you were a hero or a collaborator or something more complicated. I don't know if I'll ever see you again.*

*But I know this: I'm choosing to believe that at the end, you helped people. That at the end, you made the choice to be good in a world that made goodness impossible. That at the end, you were the father I remember — the man who taught me to tie knots, who told stories about resilience, who believed that floods recede and life continues.*

*I don't know if that's true. But I need it to be.*

*I'm teaching now. The children in the camp, the ones who've lost everything. It's not fighting, but it matters. It's my way of choosing what kind of country we'll build when this ends — a country where children don't have to lose their fathers, where choices aren't always impossible, where memory can be a source of strength rather than pain.*

*If you're alive somewhere, I hope you know this. If you're not —*

Mina stopped, unable to finish. The ink blotted on the paper, tears she hadn't realized she were crying. A shuttered window blocked her view of the sky, but she could imagine the stars above, the same stars she'd counted as a child, the same stars that had watched over her father all those years.

The letter was incomplete, like everything else. But writing it had been necessary — a way of claiming her own story in the midst of stories that kept trying to claim her instead.

Mina folded the paper carefully, tucking it into her pocket beside the scrap of paper with her father's name. Two pieces of paper, two incomplete truths, two fragments of a life that might never be whole again.

Outside, the camp breathed — coughs, murmurs, the soft sounds of people trying to sleep in impossible circumstances. Mina breathed with them, in and out, in and out, choosing to be here, in this moment, choosing the work she could do, choosing the future she could build from the wreckage of the past.

A single memorable image prefigured resilience: Mina mending Rashed's shirt, needle and thread in hand, stitching together what had been torn. Not whole again, but usable. Not the same as before, but something that could still function.

That was enough for now.

---

**Chapter 10 Word Count: 1,987 words**

**Research Notes:**
- **Sources Used:** Liberation War Museum archives (Mukti Bahini recruitment in camps, education initiatives), academic sources on political activity in refugee camps, research on collaborator accusations and their psychological impact
- **Historical Accuracy:** Political divisions emerged in camps; Mukti Bahini recruitment was active; education initiatives existed in some camps; collaborator accusations were common and often unverified; refugees had to choose between fighting and other forms of contribution
- **Facts to Verify:** Specific education programs in Tripura camps; typical recruitment numbers; outcomes for those who chose education vs. fighting

**Character Development:**
- Mina's conscious choice: education over violence
- Confrontation with accusation: facing uncertainty without resolution
- Rafiq (recruiter): humanized as exhausted but passionate
- Mending shirt as metaphor for repair not restoration

**Sensory Anchors:**
- Smell: Garlic, worn clothes
- Sound: Hurried whispers, rustle of sari
- Touch: Needle and thread, ink blots, shuttered window

**Bengali Terms Used:**
- Baba (father)

**Psychological Elements:**
- "What will you fight for?" as defining question
- Accusation as erosion of memory/truth
- Choice as assertion of agency in powerlessness
- Letter-writing as claiming own narrative

**Thematic Elements:**
- Politics in exile: debates about resistance
- Confrontation without resolution: ambiguity of truth
- Choice as moral action: education vs. violence
- Rebuilding vs. restoration: mending rather than fixing

---

**Next Chapter Preview:** Chapter 11 — After the Smoke. News of independence reaches the camp, the family begins the journey home, and Mina confronts a changed landscape and the beginning of rebuilding.
# PASO - Programming Assembly Stack-Oriented Language
## A Complete Educational Programming Language

---

## PART 1: LANGUAGE PHILOSOPHY

**PASO** (Programming Assembly Stack-Oriented) is a minimal, instruction-focused language designed to teach how programming languages work from the inside out.

### Core Principles:
- **Simple**: Every operation is explicit and visible
- **Minimal**: Only essential features, no bloat
- **Instruction-focused**: Code reads like a sequence of instructions
- **Educational**: Every design choice teaches a language concept

### What PASO is NOT:
- ❌ NOT Python-like (no indentation-based blocks)
- ❌ NOT C-like (no braces, no semicolons)
- ❌ NOT Assembly (readable, human-friendly syntax)
- ❌ NOT object-oriented (no classes, no inheritance)

### What PASO IS:
- ✅ A new programming paradigm
- ✅ Explicit stack-based operations
- ✅ Teaching tool for language internals
- ✅ Bridge between high-level code and low-level execution

---

## PART 2: LANGUAGE FEATURES

PASO intentionally has a minimal feature set to keep it understandable:

### Supported Features:
1. **Numeric Values**: Integers only (for simplicity)
2. **Variables**: Named storage locations
3. **Arithmetic Operations**: `plus`, `minus`, `times`, `over` (add, subtract, multiply, divide)
4. **Comparison Operations**: `equals`, `above`, `below` (equal, greater, less)
5. **Logical Operations**: `and`, `or`, `not`
6. **Conditional Execution**: `when ... then ... done`
7. **Loops**: `repeat ... again` and `while ... do ... done`
8. **Functions**: `func ... end` with parameters and return values
9. **Output**: `show` statement
10. **Input**: `ask` statement

### Intentionally Excluded:
- ❌ Classes and objects
- ❌ Standard libraries
- ❌ Complex data types (initially)
- ❌ Exception handling (keeps it simple)
- ❌ Modules (single-file programs)

---

## PART 3: ORIGINAL SYNTAX

PASO uses a unique, English-like, instruction-oriented syntax:

### Variable Assignment
```
save 5 to x
save 10 to y
```

### Arithmetic
```
save x plus y to result
show result
```

### Conditional
```
when x above 0 then
  show "positive"
done
```

### Loop (Repeat Fixed Times)
```
save 0 to i
repeat 10
  show i
  save i plus 1 to i
again
```

### Loop (While Condition)
```
save 0 to i
while i below 10 do
  show i
  save i plus 1 to i
done
```

### Function Definition
```
func factorial(n)
  when n below 2 then
    return 1
  done
  save n times factorial(n minus 1) to result
  return result
end
```

### Function Call
```
save factorial(5) to answer
show answer
```

### Input/Output
```
ask "Enter your name" to name
show "Hello " plus name
```

### Comments
```
// This is a single-line comment

/*
  This is a
  multi-line
  comment
*/
```

---

## PART 4: EXECUTION MODES

PASO provides two execution paths to teach the difference between interpretation and compilation:

### Mode 1: Interpreter
- Reads source code as text
- Tokenizes into words/symbols
- Parses into Abstract Syntax Tree (AST)
- Executes AST nodes directly
- **Advantage**: Flexible, easy to debug
- **Disadvantage**: Slower execution

### Mode 2: Compiler + Virtual Machine
- Source → AST (same as interpreter)
- AST → Bytecode (custom instruction set)
- Bytecode → Virtual Stack Machine execution
- **Advantage**: Faster execution, portable bytecode
- **Disadvantage**: More complex, requires compilation step

---

## PART 5: INTERPRETER PIPELINE

### Step 1: Lexical Analysis (Tokenization)
Source code is broken into tokens:

```paso
save 5 to x
```

Tokens:
- `save` (KEYWORD)
- `5` (NUMBER)
- `to` (KEYWORD)
- `x` (IDENTIFIER)

### Step 2: Parsing (AST Construction)
Tokens are structured into an AST:

```
AssignmentNode(
  variable='x',
  value=NumberLiteralNode(5)
)
```

### Step 3: Execution
AST nodes are executed recursively:
- Visit assignment node
- Evaluate right-hand side (5)
- Store in variable table

---

## PART 6: COMPILER PIPELINE

### Step 1: Source → AST
Same as interpreter pipeline

### Step 2: AST → Bytecode
AST nodes are translated to bytecode instructions:

```paso
save 5 to x
```

Bytecode:
```
PUSH 5
STORE x
```

### Example: Expression Compilation
```paso
show x plus y
```

Bytecode:
```
LOAD x
LOAD y
ADD
OUTPUT
```

### Bytecode Format
Each instruction has:
- **Opcode**: Operation name (PUSH, LOAD, ADD, etc.)
- **Operand**: Optional data (number, variable name, etc.)

---

## PART 7: BYTECODE FORMAT

### Complete Instruction Set

#### Stack Operations
- `PUSH value` - Push value onto stack
- `POP` - Remove top value from stack
- `DUP` - Duplicate top value

#### Variable Operations
- `LOAD var` - Load variable value onto stack
- `STORE var` - Store top stack value to variable

#### Arithmetic Operations
- `ADD` - Pop two values, push sum
- `SUB` - Pop two values, push difference
- `MUL` - Pop two values, push product
- `DIV` - Pop two values, push quotient

#### Comparison Operations
- `EQ` - Pop two, push true if equal
- `LT` - Pop two, push true if less than
- `GT` - Pop two, push true if greater than

#### Logical Operations
- `AND` - Pop two, push logical AND
- `OR` - Pop two, push logical OR
- `NOT` - Pop one, push logical NOT

#### Control Flow
- `JUMP label` - Unconditional jump
- `JUMP_IF_FALSE label` - Jump if top is false
- `JUMP_IF_TRUE label` - Jump if top is true
- `CALL func_name, arg_count` - Call function
- `RETURN` - Return from function

#### I/O Operations
- `OUTPUT` - Pop and display value
- `INPUT var` - Read input and store to variable

#### System Operations
- `HALT` - Stop execution
- `NOP` - No operation

### Bytecode Properties
- **Platform-independent**: Runs on any system with PASO VM
- **NOT machine code**: Human-readable, not CPU instructions
- **Stack-based**: All operations use operand stack

---

## PART 8: VIRTUAL STACK MACHINE

### What is a Stack?
A stack is a LIFO (Last-In-First-Out) data structure:
- **Push**: Add item to top
- **Pop**: Remove item from top

Example:
```
PUSH 5    → Stack: [5]
PUSH 3    → Stack: [5, 3]
ADD       → Stack: [8]  (pops 3 and 5, pushes 8)
```

### Why Stack Machines?
- **Simple**: Uniform operation model
- **Portable**: No register dependencies
- **Powerful**: Can express any computation
- **Real-world**: Used by JVM, Python, Lua

### VM Components

#### 1. Operand Stack
- Stores intermediate values
- Used for all arithmetic and logic

#### 2. Instruction Pointer (IP)
- Points to current instruction
- Advances or jumps during execution

#### 3. Variable Storage
- Global variables
- Local function variables

#### 4. Function Call Stack
- Tracks active function calls
- Handles return addresses

### Example: ADD Instruction Execution

Code:
```paso
save 5 to x
save 3 to y
show x plus y
```

Bytecode:
```
PUSH 5
STORE x
PUSH 3
STORE y
LOAD x
LOAD y
ADD
OUTPUT
```

Stack evolution:
```
PUSH 5    → Stack: [5]
STORE x   → Stack: [] (x = 5)
PUSH 3    → Stack: [3]
STORE y   → Stack: [] (y = 3)
LOAD x    → Stack: [5]
LOAD y    → Stack: [5, 3]
ADD       → Stack: [8]
OUTPUT    → Stack: [] (prints 8)
```

---

## PART 9: COMPLETE SYNTAX REFERENCE

### Literals
- Numbers: `0`, `42`, `-17`, `3.14`
- Strings: `"hello"`, `"PASO language"`

### Keywords
- `save`, `to`, `show`, `ask`
- `when`, `then`, `else`, `done`
- `repeat`, `again`, `while`, `do`
- `func`, `return`, `end`
- `plus`, `minus`, `times`, `over`
- `equals`, `above`, `below`
- `and`, `or`, `not`
- `true`, `false`

### Operators (Precedence: High to Low)
1. Function call: `func(args)`
2. Parentheses: `(expr)`
3. Unary: `not expr`, `-expr`
4. Multiplicative: `times`, `over`
5. Additive: `plus`, `minus`
6. Comparative: `above`, `below`, `equals`
7. Logical: `and`, `or`

### Grammar (Simplified)
```
program        → statement*

statement      → assignment
               | output
               | input
               | conditional
               | loop
               | function_def
               | expression

assignment     → "save" expression "to" IDENTIFIER

output         → "show" expression

input          → "ask" STRING "to" IDENTIFIER

conditional    → "when" expression "then"
                   statement*
                 ("else"
                   statement*)?
                 "done"

repeat_loop    → "repeat" expression
                   statement*
                 "again"

while_loop     → "while" expression "do"
                   statement*
                 "done"

function_def   → "func" IDENTIFIER "(" parameters? ")"
                   statement*
                 "end"

expression     → logical_or

logical_or     → logical_and ("or" logical_and)*

logical_and    → comparison ("and" comparison)*

comparison     → additive (("above" | "below" | "equals") additive)*

additive       → multiplicative (("plus" | "minus") multiplicative)*

multiplicative → primary (("times" | "over") primary)*

primary        → NUMBER
               | STRING
               | "true" | "false"
               | IDENTIFIER
               | IDENTIFIER "(" arguments? ")"
               | "(" expression ")"
```

---

## PART 10: EXAMPLE PROGRAMS

### Program 1: Hello World
```paso
show "Hello, PASO!"
```

### Program 2: Simple Arithmetic
```paso
save 5 to x
save 10 to y
save x plus y to sum
show "Sum:"
show sum
save x times y to product
show "Product:"
show product
```

### Program 3: Factorial
```paso
func factorial(n)
  when n below 2 then
    return 1
  done
  save n times factorial(n minus 1) to result
  return result
end

save 6 to n
show "Factorial of"
show n
show factorial(n)
```

### Program 4: Fibonacci
```paso
func fibonacci(n)
  when n below 2 then
    return n
  done
  save fibonacci(n minus 1) to a
  save fibonacci(n minus 2) to b
  return a plus b
end

save 10 to n
show "Fibonacci sequence:"
save 0 to i
while i below n do
  show fibonacci(i)
  save i plus 1 to i
done
```

### Program 5: FizzBuzz
```paso
save 20 to limit
save 1 to i
while i below limit do
  save i equals 0 to is_zero
  save i over 3 equals i over 3 to divisible_by_3
  save i over 5 equals i over 5 to divisible_by_5
  save divisible_by_3 and divisible_by_5 to fizzbuzz
  when fizzbuzz then
    show "FizzBuzz"
  else when divisible_by_3 then
    show "Fizz"
  else when divisible_by_5 then
    show "Buzz"
  else
    show i
  done
  save i plus 1 to i
done
```

### Program 6: Greatest Common Divisor
```paso
func gcd(a, b)
  while b not equals 0 do
    save a over b to temp
    save a minus temp times b to remainder
    save b to a
    save remainder to b
  done
  return a
end

save 48 to x
save 18 to y
show "GCD of"
show x
show "and"
show y
show "is:"
show gcd(x, y)
```

---

## PART 11: IMPLEMENTATION ARCHITECTURE

### File Structure
```
paso/
├── lexer.py           # Tokenizer
├── ast_nodes.py       # AST definitions
├── parser.py          # Parser (AST builder)
├── interpreter.py     # Direct AST executor
├── compiler.py        # AST → Bytecode translator
├── vm.py              # Virtual stack machine
├── paso.py            # Main entry point
└── demos.py           # Example programs
```

### Component Responsibilities

**Lexer**:
- Split source code into tokens
- Track line numbers for errors
- Ignore comments and whitespace

**Parser**:
- Build AST from tokens
- Handle operator precedence
- Report syntax errors

**Interpreter**:
- Execute AST directly
- Manage variable scopes
- Handle function calls

**Compiler**:
- Translate AST to bytecode
- Generate labels for control flow
- Optimize simple cases

**Virtual Machine**:
- Execute bytecode instructions
- Manage stack and variables
- Handle function calls and returns

---

## PART 12: COMPARISON WITH OTHER LANGUAGES

### vs Python
| Aspect | Python | PASO |
|--------|--------|------|
| Syntax | Indentation-based | Keyword-based |
| Execution | Interpreted + Bytecode | Dual mode (Interpret or Compile) |
| Complexity | Large standard library | Minimal core |
| Learning | High-level abstractions | Explicit stack operations |

### vs C
| Aspect | C | PASO |
|--------|---|------|
| Syntax | Braces and semicolons | English keywords |
| Compilation | To machine code | To custom bytecode |
| Memory | Manual management | Automatic (VM-managed) |
| Portability | Platform-dependent | Platform-independent bytecode |

### vs Assembly
| Aspect | Assembly | PASO |
|--------|----------|------|
| Syntax | Mnemonics + registers | English-like |
| Execution | Direct on CPU | On virtual machine |
| Readability | Low | High |
| Teaching | CPU-specific | Language concepts |

### Why Stack Machines Matter
- **JVM (Java)**: Stack-based bytecode
- **CPython**: Stack-based interpreter
- **Lua**: Register-based (alternative design)
- **WebAssembly**: Stack-based virtual machine

PASO teaches the core concepts behind these real systems.

---

## PART 13: LIMITATIONS & LEARNING OUTCOMES

### What PASO Cannot Do
- ❌ No floating-point precision (integers only)
- ❌ No complex data structures (arrays, maps)
- ❌ No file I/O
- ❌ No networking
- ❌ No concurrency
- ❌ No exception handling
- ❌ No modules/packages

### Why These Limitations Exist
These are intentional design choices to:
1. Keep the implementation understandable
2. Focus on core language concepts
3. Make each feature addition meaningful
4. Allow step-by-step learning

### What This Project Teaches
✅ How programming languages are designed
✅ Difference between interpretation and compilation
✅ How tokenization and parsing work
✅ What an Abstract Syntax Tree is
✅ How bytecode is designed and executed
✅ Why stack machines are elegant
✅ How function calls are implemented
✅ The importance of language design decisions

### Path to Real Language Development
After mastering PASO, you understand:
- The foundation of all programming languages
- How to add features systematically
- Trade-offs in language design
- Why real languages are complex
- How to approach creating your own language

---

## CONCLUSION

PASO is a complete, working programming language with:
- ✅ Unique syntax and philosophy
- ✅ Full lexer, parser, and AST
- ✅ Working interpreter
- ✅ Working compiler
- ✅ Custom bytecode format
- ✅ Virtual stack machine
- ✅ Control flow (if, loops)
- ✅ Functions with parameters and returns
- ✅ Comprehensive examples

This project demonstrates that designing and implementing a programming language is achievable and teaches fundamental computer science concepts that apply to all language development.

**At the end of this project, you can honestly say:**

*"I designed a new programming language and implemented its interpreter, compiler, bytecode format, and a virtual stack machine from scratch."*
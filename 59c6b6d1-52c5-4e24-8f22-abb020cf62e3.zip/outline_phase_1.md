# Phase 1: Outline & Character List

## 12-CHAPTER OUTLINE

### Chapter 1 — Home Before the Storm

### **Scene 1 — Dusk Market Window (400 words)** Mina helps her mother at their small stall in Chittagong's Newmarket. The air thick with the smell of frying hilsa and sticky betel nut. Fish scales cling to her fingers as she watches the afternoon crowds. A stranger in a faded khaki shirt whispers to her father about "soldiers moving" — the words hang in the humid air like smoke. Mina remembers her father teaching her to tie a proper sailor's knot when she was small, his hands steady against hers.

**Scene 2 — Home Kitchen (400 words)** The family gathers for evening tea. The brass locket at Mina's throat warms against her skin. Her father's laughter fills the small room, but her mother's eyes dart toward the radio. Clinking chai cups and the sharp scent of mosquito oil. A neighbor bursts in, face pale, speaking of troops gathering near the cantonment. Her father's jaw tightens, then he forces a grin, ruffling Mina's hair and telling her he's proud of her school marks — his pride a shield against gathering darkness.

**Scene 3 — Schoolyard / Friend (400 words)** Mina walks to school through Pahartali, the afternoon heat pressing down. Dust from blackboards coats her fingers. Her friend Sumi teases her about leaving Chittagong one day, about university in Dhaka. The cicadas scream in the trees. A distant rumble freezes them both — thunder, or something else? Mina can't remember if the sky had been clear. The teacher inside continues marking papers, unaware that nothing will ever be the same.

**Scene 4 — Night on the Verandah (800 words)** The family sits on the cool concrete verandah. Incense drifts from the prayer room, mixing with the smell of the river below. Her father tells a story from his grandfather about survival — how floods came and went, how people rebuilt. Mina notices small things: the way his hand shakes slightly, the radio static he keeps adjusting, whispered phone calls late at night. He's their anchor, but she sees now how much he's holding. Across the water, lights flicker. Someone shouts down the lane. The sound carries on the night air, ominous and unresolved. Mina falls asleep holding her father's hand, dreaming of water rising.

* * *

### Chapter 2 — Night of Guns 

  

**Scene 1 — First Shots (450 words)** 11:30 PM. Artillery shatters the night. Glass explodes inward. The metallic taste of fear floods Mina's mouth. Her mother grabs her, shoving her under the bed. The neighbor's house takes a direct hit — flames, screaming, dogs barking wildly. Radio crackles with panicked reports. Confusion everywhere. Her father makes the decision: they leave by morning. Mina tries to remember if she locked the trunk — such a small thing, but it matters. She can't recall.

**Scene 2 — Panic & Escape (500 words)** Streets fill with people running, shouting, carrying whatever they can. Stalls burn in the market, black smoke choking the sky. A man with a portable radio climbs a pole, calling for calm — no one hears him. People are leaving everything behind. Her father disappears into the crowd for a moment, comes back quieter, his shirt stained darker. He won't say where he went. A broadcast snippet drifts past: "Armed forces taking necessary action..." Mina's mother clutches her children like they might dissolve.

**Scene 3 — Neighbor Betrayal / Loss (450 words)** Rafique uncle, who had promised to watch their house, is gone. His door stands open, empty. Later, rumors: men with rifles took everyone on his street. The family argues in hushed voices — stay or leave? Mina notices wet footprints leading away from their neighbor's house, the creak of a door that won't fully close. Her father insists: coast before dawn. The sea route is the only chance. Mina rubs the brass locket between thumb and forefinger, an old superstition for protection.

**Scene 4 — Night Watch (600 words)** Their last night at home. They move through each room saying silent goodbyes to familiar objects — the embroidered pillow, the kitchen scale, the photograph of her grandmother. Her father makes quiet promises: we'll return, we'll rebuild, this isn't the end. The taste of stale bread. The length of his shadow against the wall. Unresolved dread settles in Mina's chest like cold water. At first light, they join a ragged column moving toward the shore. Mina catches a fragment of memory — a line of poetry she can't quite place — and it echoes in her mind as they walk into the unknown.

* * *

### Chapter 3 — Packing Silence

  

**Scene 1 — Early Preparation (400 words)** Rapid packing in pre-dawn darkness. Her mother hides family photos between layers of clothes in a metal trunk. The community priest stops briefly, murmuring a blessing over their hurried preparations. The thin mosquito net tears as Mina tries to fold it. The weight of the metal tin — what's inside? Clothes, or something more? Mina pockets her school exercise book, debates taking something more practical instead. She chooses the book.

**Scene 2 — Farewells (400 words)** Quick goodbyes in the street. No time for proper embraces. An elderly neighbor, Rehana khala, presses a small charm into Mina's hand and whispers advice: "Stay close to your mother's sari, never look back." The dry papery skin against Mina's cheek. The smell of garam masala on her clothes. Someone from their group goes to check the road ahead and doesn't return. Fear spreads like water through the crowd. Mina's mother hums half a lullaby she can't complete.

**Scene 3 — Checkpoints & Rumors (500 words)** The group meets an armed checkpoint. Soldiers check papers with deliberate slowness. The snap of leather boots against pavement. Tension crackles — will they pass? A whisper runs through: sea route is the only safe way now. Mina closes her eyes, rehearsing a future conversation with her father, a conversation where they're safe and laughing and none of this happened. They make it through, but everyone breathes harder afterward.

**Scene 4 — Small Act of Generosity (500 words)** A stranger shares his bread with Mina's little brother. The bread is damp, compressed from being carried all day. She notices the callus on his palm, the kindness in his exhausted face. This small moment marks Mina's first outward step toward empathy that will resurface later. The group reaches the edge of town. The distant roar of the sea. Mina holds her breath as she walks — one long paragraph of urgency and movement and fear and hope.

* * *

### Chapter 4 — To the Shore

### **Scene 1 — The Trek (400 words)** Long walk toward the coast. Children cry, parents carry them. Mina remembers swimming in the Bay of Bengal as a child, the salt stinging her eyes. Salt air fills her lungs now, but there's no joy in it. Sand scrapes inside her sandals. She counts stars to calm herself — the same star over the harbor she used to watch from her window. It's still there, but everything else has changed.

**Scene 2 — River Crossing (500 words)** Crowded boat, water dangerously close to the gunwales. People praying in whispers. The creak of planks under weight. Oily water reflecting the moon. A patrol boat passes in the distance — everyone holds their breath, children silent with fear. A child begins to cry and reveals a rumor: "They took men from the village last night." A woman who has lost everything but her voice begins to sing softly, a melody that carries across the water.

**Scene 3 — Smugglers & Choices (400 words)** At the crossing point, smugglers offer risky passage. Her father bargains, Mina watching from the shadows. Coin clinking, the rope burn on his palms. Research confirms this was documented — smuggling networks exploited desperate refugees in 1971. They get passage, but at cost: someone else in their group is left behind. Mina feels a cold knot in her stomach at the unfairness.

**Scene 4 — First Night at Coast (500 words)** Makeshift camp on the beach. Fires of driftwood and whatever people can burn. Talk of India across the water. Mina sees a distant lighthouse and imagines safety waiting there. Smoke, the distant horn of a ship, salt on her lips. Fire leads to smell of burning wood leads to sound of hushed voices leads to memory of home — a chain of sensation that grounds her. At dawn, boats to India are announced. They must decide.

* * *

### Chapter 5 — Camp Life 

  

**Scene 1 — Arrival to Camp (500 words)** They arrive at a relief camp in India's Tripura province. Queues stretch endlessly. Canvas tents wall-to-wall. The smell of ration tins and dust in every breath. Relief workers with clipped English organize lines. Mina sees a poster of missing persons, names scrawled in different hands. A name similar to her father's appears on a hand-written notice. Her heart skips. She makes a mental list of comforts she misses: chalky school mornings, her father's laugh, the taste of betel from the neighbor.

**Scene 2 — The Work of Waiting (400 words)** Daily monotony. Subsistence tasks define existence. Women form networks for cooking and childcare. Rice powder coats hands and clothes. Low conversations in every corner. Clotheslines strung between tents. A rumor spreads that lists of detainees are circulating among aid groups. Hope flares, dies, flares again. Mina trades a secret — her book — for a small favor: extra rations for her brother.

**Scene 3 — Camp Politics (500 words)** Tensions rise over food distribution. Shouted names, the clatter of utensils, arguments that turn physical. A local leader tries to impose order. Rumors of collaborators hiding among refugees. Health crises emerge — dysentery, cholera warnings. Mukti Bahini contacts are rumored to visit nearby camps. Mina overhears a conversation in Bengali: "We must be careful who we trust." She understands the weight of survival.

**Scene 4 — Night of Stories (600 words)** Around a fire, refugees share oral histories. Testimonies of raids, separations, atrocities. Mina hears a story that hints at her father's fate: men rounded up near the docks, forced onto trucks. The crack of firewood, a woman's nasal laugh, the metallic taste of fear. Mina decides she must learn more. She clutches the locket as if it can answer questions. The night stretches on, each story another brick in the wall of her growing resolve.

* * *

### Chapter 6 — Whispers from Home 

  

**Scene 1 — Lists and Notices (450 words)** Mina spends hours studying lists of missing persons and wartime casualty notices. Names are misspelled, dates conflict. Ink smudges, folded paper worn soft. A woman recognizes Mina's village name and mentions a raid. Hope rises: maybe he's there. Then the deflating detail: the raid was two months ago, and no one survived. Or so she says.

**Scene 2 — Conflicting Testimonies (450 words)** Different refugees give different versions of events. One speaks of arrests, another of mass graves, a third of men fleeing into the hills. Mina is pushed between hope and dread. Throat-clears, shifting feet, hesitant words. She overhears a name that matches a description of a man who might have seen her father. Was he on the docks that day?

**Scene 3 — An Old Photograph (450 words)** Mina finds a photograph in someone's trove — a crowd at the port, and there, in the background, a man who might be her father. The glossy crease, the smell of old tobacco. Her breath catches. The person showing the photo says, "I thought he was taken by the patrol near the docks." A specific lead. Mina clings to it like a lifeline. She lights incense, a ritual to hold on.

**Scene 4 — Decision Night (450 words)** Mina decides: she must know the truth. Send someone back, or go herself? Seeds of a plan form. Matches struck, a small flame reflected in her eyes. A stranger arrives with a map and an offer to help verify rumors. Mina feels resolve harden around her heart like a shell.

* * *

### Chapter 7 — The Stranger with a Map 

  

**Scene 1 — The Map Appears (400 words)** An older man with kind eyes but scarred knuckles shows a grease-smudged map. The smell of diesel clings to him. He's connected to Mukti Bahini networks in the camps. He asks for a small, risky favor in exchange: information, a name, a rumor. Mina hesitates. The map shows routes back into occupied territory.

**Scene 2 — Bargain & Trust (500 words)** Negotiation. The stranger wants information, or a small sum, or help carrying a message. Mina feels the moral tension tighten in her chest. Coin on palm, folded paper. He knows the name of a village informant who may confirm her father's fate. Mina's internal logic: what won't she give to know?

**Scene 3 — The Informant's Tale (600 words)** The informant recounts a raid near the docks. Details match Mina's father's last known route. Muddy dock planks, the smell of rope and fuel. Men rounded up, shouts, gunshots. But some escaped into the crowd — was her father among them? The informant warns that returning is dangerous but possible. He shares a small humanizing detail: his own daughter, Mina's age, was taken by soldiers months ago.

**Scene 4 — Plan Set (300 words)** Mina and the stranger draft a plan. One person to check, or a covert trip. Pencil on paper, the sting of night air. Mina feels both terrified and resolved. The torn corner of the map catches on her finger. She chooses action.

* * *

### Chapter 8 — A Dangerous Return 

  

**Scene 1 — Departure at Dawn (500 words)** The covert trip begins. Disguised in worn clothes, small group, tension thick. Travel logistics: boats, smugglers, river crossings under cover of darkness. Early fog, rope friction. They narrowly avoid a patrol — a friend is captured. Mina uses counting to stay calm: one breath, two breath. Panic recedes.

**Scene 2 — Flashbacks Interleaved (500 words)** As they approach Chittagong, Mina's memories flood forward. The temple bell from childhood versus patrol vehicle noise. Evidence of destruction appears: burned homes, abandoned bicycles, walls pockmarked with bullets. One vivid micro-scene: an abandoned house she recognizes — the blue door, the cracked window. Someone's life left mid-breath.

**Scene 3 — Witness Account (600 words)** They meet a frightened survivor who saw men rounding up villagers. Dried blood on a boat oar, trembling hands. Details lead to the docks. The survivor hints her father opposed collaborators — this raises motives, complicates the picture. Mina realizes the complexity of people's choices during war. Nothing is black and white.

**Scene 4 — The Proof (400 words)** They find evidence: a hidden cloth with initials, a name carved in wood, a token suggesting her father's presence. Not absolute proof, but enough to shift Mina's inner state. The grit under her fingernails, a faded ink mark. She must confront the possibility that her father was killed. Mina chokes on a memory that's both real and imagined — his hand on hers, teaching that knot.

* * *

### Chapter 9 — The Truth Unfolds

### **Scene 1 — Returning to Camp with News (500 words)** Mina returns to camp with the token. Reactions vary: some console, others warn denial. Camp dust, hurried footsteps. An aid worker mentions a government list with confirmed fatalities. Mina's stomach lurches.

**Scene 2 — The List (500 words)** The official list is consulted. Names, dates, locations. Mina searches frantically. Typewriter clack, stamped paper, bureaucratic coldness. She finds a partial match but with an ambiguous last line. "Status: Unknown." Short sentences mimic shock. He might be alive. He might not.

**Scene 3 — Mourning Ritual in Exile (600 words)** Community mourning: a small ritual in camp. Women's practices, her mother's breakdown, social support. Wet sari, incense, folded hands. Bengali mourning customs anchor the scene. Mina learns a complicating detail: someone claims to have seen her father after the raid with collaborators. Ritual both soothes and complicates.

**Scene 4 — Moral Complexity (400 words)** Mina wrestles with new information. Is her father a hero, a victim, or something more complicated? The cold metal railing she leans on. She chooses a path — forgiveness, or not. The ending resists closure.

* * *

### Chapter 10 — Reckoning and Choice

  

**Scene 1 — Political Pressure (500 words)** Camp tensions turn political. Exiles debate joining Mukti Bahini, aiding fighters, or focusing on survival and return. Flyers, hurried whispers. A recruiter asks Mina a pointed question that forces her decision: "What will you fight for?"

**Scene 2 — Confrontation (500 words)** Mina confronts someone who spread rumors about her father collaborating. The scene is raw, human, ambiguous. The rustle of a sari, the smell of garlic. No clear answer — only a choice. Avoiding melodrama, keeping it in short gestures.

**Scene 3 — Choosing a Future (600 words)** Mina chooses: education, activism, migration? Practical steps, sacrifices. A borrowed pen, old notebooks. She signs up for a night class or a Mukti Bahini support role — symbolic turning point. Mending a tear, tucking the locket. Small triumphant physical action.

**Scene 4 — Quiet Resolve (400 words)** In a quiet scene, Mina writes a letter she may never send. Private ledger of grief and intent. Ink blots, a shuttered window. Single memorable image prefiguring resilience.

* * *

### Chapter 11 — After the Smoke 

  

**Scene 1 — News of Independence (400 words)** Radio news, celebrations tempered by loss. Plans for repatriation surface. Celebratory horns, cautious smiles. Mina learns of a program for returning families. Mixed emotions: joy and grief simultaneously.

**Scene 2 — Return Journey (500 words)** Traveling back to Chittagong. Changed landscapes, changed neighbors. Reek of mud, boats floating upturned. Signs of collaborators being ostracized or punished. A quiet scene where Mina hesitates before entering her old street.

**Scene 3 — Rebuilding (500 words)** Family finds a ruined house, scavenges items, meets neighbors living with complex choices. Daily rebuilding: repairing roofs, finding work. Mildew, hammer on wood. Mina decides to resume schooling or start a small stall. Specific detail anchors memory: paint flake, carved step.

**Scene 4 — Memory Work (400 words)** Mina helps create or attends a small memorial. Chooses what to remember publicly and privately. Marigold garlands, soft soil. Places something at the memorial: a ribbon or a book.

* * *

### Chapter 12 — Memory and Tomorrow

  

**Scene 1 — Years Later (450 words)** Mina older. Small domestic stability: a job, maybe teaching, modest home. Traces of trauma but sustained resilience. Chalk on fingers, evening lamp. A young refugee asks about the war; she must decide how to tell the story.

**Scene 2 — The Visit (500 words)** Mina visits a memorial or gravesite. Memories flood, but she narrates for a younger person. Reflective tone. Marigolds, cool stone. Conversation layers past and present.

**Scene 3 — Passing On (450 words)** Mina mentors a child, encourages education, passes along the locket or notebook. Symbolic transfer of memory and hope. Small gift's weight in child's hand. Child asks about forgiveness; Mina answers with ambiguity. Short, flawed, true.

**Scene 4 — Closing Image (400 words)** Final image ties motifs: water, locket, marigolds. Ambiguity but growth — Mina not healed but continuing. Tide sound, dusk light. Sensory, elliptical ending.

* * *

### Epilogue — Reflection 

Mina as an elderly woman. Full circle moments. The weight of memory carried across decades. A final scene that echoes the beginning but transformed. Water imagery returns. The brass locket, now worn thin. A quiet moment of peace.

* * *

## PRIMARY CHARACTER LIST

### MINA (Protagonist)

-   **Age:** 16 at novel's start, 17-18 by end
-   **Role:** Close-third limited POV character
-   **Goal:** Initially wants education and normal life; war forces survival, finding truth about father, forging new identity
-   **Relationships:** Daughter of Hasan and Fatima, older sister to little brother Rashed
-   **Key trait:** Observer, quietly strong, carries locket as talisman, learns empathy through hardship

### HASAN (Father)

-   **Age:** 45-50
-   **Role:** Family anchor, moral compass, source of stability
-   **Goal:** Protect family during crisis; becomes a symbol of hope and loss
-   **Relationships:** Husband to Fatima, father to Mina and Rashed
-   **Fate:** Ambiguous — possible capture/death; source of Mina's quest for truth
-   **Key trait:** Stoic protector, teaches Mina resilience through stories

### FATIMA (Mother)

-   **Age:** 40-45
-   **Role:** Emotional center, practitioner of rituals, quietly resilient
-   **Goal:** Keep family together, preserve cultural practices
-   **Relationships:** Wife to Hasan, mother to Mina and Rashed
-   **Key trait:** Maintains normalcy through rituals, breaks down privately, recovers through community

### RASHED (Little Brother)

-   **Age:** 8-9
-   **Role:** Innocent victim of war, Mina's protective responsibility
-   **Goal:** Survival, understanding what's happening
-   **Relationships:** Son to Hasan and Fatima, brother to Mina
-   **Key trait:** Adaptable, looks to Mina for explanations

### SUMI (Friend)

-   **Age:** 16
-   **Role:** Represents pre-war normalcy and future dreams
-   **Goal:** Education, leaving Chittagong for university
-   **Relationships:** Classmate and friend to Mina
-   **Fate:** Separated during war — her fate unknown, haunts Mina

### THE STRANGER (Mukti Bahini Contact)

-   **Age:** 30s-40s
-   **Role:** Catalyst for Mina's quest, morally ambiguous helper
-   **Goal:** Aid resistance, gather information
-   **Relationships:** Contact to Mina in camp
-   **Key trait:** Kind eyes but scarred knuckles — contradiction between appearance and actions

### RAFIQUE UNCLE (Neighbor)

-   **Age:** 50s
-   **Role:** Represents betrayal and complex wartime choices
-   **Goal:** Survival of his own family
-   **Relationships:** Neighbor to Hasan's family
-   **Fate:** Disappears during crackdown — fate unknown

### REHANA KHALA (Elderly Neighbor)

-   **Age:** 60s-70s
-   **Role:** Source of wisdom and cultural continuity
-   **Goal:** Help others survive
-   **Relationships:** Neighbor to Hasan's family
-   **Key trait:** Gives charm to Mina, whispers advice before departure

* * *

## PER-CHAPTER WORD COUNT TARGETS

| Chapter | Title | Words |
| --- | --- | --- |
| 1 | Home Before the Storm | 2,000 |
| 2 | Night of Guns | 2,000 |
| 3 | Packing Silence | 1,800 |
| 4 | To the Shore | 1,800 |
| 5 | Camp Life | 2,000 |
| 6 | Whispers from Home | 1,800 |
| 7 | The Stranger with a Map | 1,800 |
| 8 | A Dangerous Return | 2,000 |
| 9 | The Truth Unfolds | 2,000 |
| 10 | Reckoning and Choice | 2,000 |
| 11 | After the Smoke | 1,800 |
| 12 | Memory and Tomorrow | 1,800 |
| Epilogue | Reflection | 1,000 |

**TARGET: 22,800 words**

This exceeds the minimum requirement of 20,000 words, providing cushion for variation.

* * *

**Phase 1 Complete ✅** Outline and character list finalized. Ready to proceed to Phase 2: Drafting (Chapter by Chapter).
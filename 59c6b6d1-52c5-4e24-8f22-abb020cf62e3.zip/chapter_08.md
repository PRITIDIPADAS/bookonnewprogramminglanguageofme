# Chapter 8 — A Dangerous Return

**Sensitivity Note:** This chapter includes a covert return to occupied territory, checkpoint encounters, and accounts of violence. Discusses atrocities without graphic descriptions.

---

## Scene 1 — Departure at Dawn

The pre-dawn darkness was absolute when Karim woke Mina with a hand on her shoulder. His face was grim, his eyes holding no trace of the kindness she'd seen before.

"The contact is ready," he said, his voice barely above a whisper. "We leave now."

Mina's heart hammered against her ribs as she slipped out of the tent, careful not to wake her mother or Rashed. She'd left a note explaining nothing, saying everything: *I have to know. I'll come back. Wait for me.*

The note was a lie in at least one way — she didn't know if she'd come back. But she couldn't tell them that.

Three others joined them at the camp's edge: a young man named Tariq who'd been a student in Chittagong, an older woman called Amina who knew the terrain, and a silent figure who moved like smoke through the darkness. Karim had arranged it all — smugglers, guides, people who took enormous risks for reasons Mina couldn't fathom.

They moved in single file, following paths that twisted through hills and forests, avoiding roads and villages. Early fog clung to the landscape, muffling sound and obscuring vision. Rope friction as they helped each other up steep slopes, breath visible in the cold air.

Mina counted to stay calm: one breath, two breath, three breath. Panic receded, replaced by something colder and harder — determination.

The border crossing was unmarked, invisible except to those who knew where it was. Amina paused, listening, then gestured them forward. They slipped across like ghosts, leaving the relative safety of India for occupied Bangladesh.

Behind them, the possibility of return. Ahead, the certainty of danger.

"We need to reach the informant's village before dawn," Karim said quietly. "He's expecting us."

The village was small, almost invisible from the road — a cluster of houses hidden in trees, people who knew how to stay unseen. The informant, a man named Jamal, met them at the edge of the settlement, his face wary.

"You came," he said, as if he hadn't believed they would.

"My father," Mina said, and the words felt both simple and impossibly heavy. "I need to know."

Jamal nodded, leading them to his house. Inside, his wife stirred a fire while his children slept in the corner. The domesticity of the scene was jarring — ordinary life continuing in the midst of catastrophe.

"I heard about the dock roundups," Jamal said, his voice low. "Men taken to the cantonment. But the cantonment is difficult. Security is tight. We can't get in."

Karim had told her this already, but hearing it again made Mina's stomach clench.

"There's a witness," Jamal said. "Someone who escaped from one of the trucks. He's in the hills now, hiding. He might know more."

"Can we find him?" Karim asked.

Jamal hesitated. "It's dangerous. The hills are crawling with soldiers. And the witness — he's not stable. What he saw —" Jamal didn't finish.

Mina didn't care about stable. She didn't care about dangerous. She just needed to know.

"Take me to him," she said.

---

## Scene 2 — Flashbacks Interleaved

The journey to the hills took hours, twisting through forests and across streams, following paths that only Jamal seemed to know. Mina moved in a daze, her body on automatic while her mind kept sliding backward into memories that wouldn't stay in the past.

The temple bell from childhood — clear, pure, calling worshippers to prayer. She used to hear it every morning, part of the ordinary soundtrack of her life. Now the bell was replaced by the rumble of patrol vehicles, distant but constant, the sound of occupation.

Her father's hands teaching her the sailor's knot. *Tight but not too tight,* he'd said. She'd thought it was just about knots, but now she understood it was about everything — about holding on without breaking, about surviving without losing yourself.

The smell of frying hilsa at the market stall. Fish scales on her fingers. The stranger in the khaki shirt whispering about soldiers. All the ordinary moments that had led to this extraordinary moment, this impossible journey back to a place that wasn't home anymore.

Evidence of destruction appeared gradually: burned homes with blackened walls standing like skeletons, abandoned bicycles rusting by the roadside, fields overgrown because there was no one left to work them. One house in particular stopped Mina cold — the blue door, the cracked window, the embroidered pillow she'd seen on the neighbor's verandah a thousand times.

Someone's life, left mid-breath.

The hills rose ahead, dark against the darkening sky. Patrols passed occasionally, engines rumbling, headlights sweeping across roads. Each time, they ducked into shadows, holding breath, waiting for the danger to pass.

One patrol came too close — a truck with soldiers in the back, searching the forest with flashlights. Tariq didn't move fast enough, didn't hide completely. A spotlight caught him, brief but terrible.

Men jumped from the truck, shouting. Tariq tried to run, but there was nowhere to go. They took him, forcing him onto the truck bed while the others watched from cover, helpless and terrified.

Mina counted breaths: one, two, three, four. Panic wanted to scream but she swallowed it down, cold and hard. Tariq was gone. Another life taken, another family that would wait and wonder and never know.

But they couldn't stop. They had to keep going.

The witness was hiding in a cave halfway up the hill, a man named Rashid who'd been a day laborer at the docks. Jamal found him huddled in the darkness, eyes wild, hands shaking so badly he could barely hold a cup of water.

"The trucks," Rashid said, his voice barely audible. "They took us to the cantonment. I escaped when they stopped for fuel. Jumped from the back and ran into the forest. But the others —"

His voice cracked.

"Describe the cantonment," Karim said. "What did you see?"

"Barbed wire," Rashid said. "Guards everywhere. Men in civilian clothes being questioned, beaten. I heard screams at night. I don't know what happened to them, but I heard them."

Dried blood stained the boat oar Rashid had used as a weapon to defend himself when he escaped. His hands trembled constantly, the aftermath of whatever he'd seen and done and survived.

"An older man," Mina said. "Maybe fifty. Helping others at the docks. Did you see him?"

Rashid thought for a long moment. "Maybe. There was one — older, calm, trying to keep people quiet. He spoke to some of the younger men, told them not to resist. He was taken onto a different truck, I think. The officers' truck."

Mina's breath caught. The officers' truck. That might mean something — better treatment, or worse, or just different.

"Do you know where that truck went?" she asked.

"No." Rashid shook his head. "But I heard something — one of the guards talking. Said they were taking some of the men to Dhaka. For questioning, he said."

Dhaka. The capital, hours away from Chittagong. Her father might be there, in some prison or interrogation center, alive or dead or something in between.

The realization was both hope and torture. He wasn't here. He wasn't somewhere she could reach. He was in Dhaka, and getting there would be impossible.

---

## Scene 3 — Witness Account

They found another witness in a village near the cantonment — a woman named Halima who'd seen the trucks arrive and depart. She invited them into her house, offering tea she couldn't really afford to share.

"The trucks came every night for a week," she said, her voice low but steady. "Full of men from the docks, from the neighborhoods. They went into the cantonment and didn't come out."

Halima's hands were scarred from work, her face lined with hardship, but her eyes were clear. She'd seen too much but hadn't broken yet.

"Some men were collaborators," she continued. "Local men who pointed out houses, named people who supported the independence movement. Your father —" She looked at Mina. "I heard he was on their list. Someone said he opposed them publicly, argued when they came to his street."

Mina's stomach turned. Her father — quiet, private, careful — had argued with collaborators? Had taken a stand when it mattered most?

"He wasn't political," Mina said, though she wasn't sure if she was defending him or just unable to reconcile this new information with the father she thought she knew.

"Maybe not," Halima said. "But in times like these, everyone becomes political by not being political enough. Silence is a choice too."

The words burned. Mina had never thought of her father's silence as a choice. She'd thought of it as caution, as wisdom, as the way people like them survived. But maybe silence was its own kind of violence — allowing the horror to continue by not standing against it.

"The collaborators," Halima continued, "they had specific targets. Intellectuals, students, anyone who might organize resistance. Your father —" She hesitated. "I heard he was helping people escape. That's why he was at the docks. That's why they took him."

Helping people escape. That sounded like her father — the man who'd taught her to tie knots, who'd told stories about resilience, who'd believed in helping others even when it cost something.

But the cost was everything now.

"There's a man," Halima said, "who might know more. A collaborator who turned coat — claims he was forced, that he didn't have a choice. He's hiding in the hills now, afraid of what the Mukti Bahini will do to him when the war ends."

"Will he talk to us?" Karim asked.

"He might," Halima said. "If he thinks it will help him later. If he thinks there's benefit in it."

The collaborator. The man who might have pointed out her father's house, who might have named him to soldiers, who might have sent her father to the trucks and the cantonment and whatever came after.

Mina realized the complexity of people's choices during war. Nothing was black and white, nothing was simple. Collaborators weren't monsters — they were people who'd made choices, often under impossible pressure. Freedom fighters weren't heroes — they were people who'd made different choices, equally costly.

Her father might have been both and neither — someone who'd helped when he could, who'd stayed silent when he needed to, who'd made the choices he could live with.

She wasn't sure if she could live with his choices, or her own.

---

## Scene 4 — The Proof

They found the collaborator in a ruined house halfway up another hill — a man named Yusuf who'd been a shopkeeper before the war. He was thin, terrified, his eyes darting toward windows every time a branch moved outside.

"I was forced," he said immediately, before anyone could ask anything. "They made me do it. They said if I didn't help, they'd kill my family."

No one answered. There was nothing to say. Forced or willing, the result was the same — men rounded up, taken away, killed or tortured or disappeared into prisons.

"My father," Mina said, and her voice sounded thin in her own ears. "Hasan Ahmed. Did you —"

"I pointed out houses," Yusuf said, his voice cracking. "I told them where the students lived, where the Awami League supporters were. I didn't know your father specifically, but I heard the name. They had a list."

"Was he on the list?" Karim asked.

"Yes." Yusuf's eyes dropped to the floor. "They said he was organizing escapes at the docks. That he was helping women and children get away. That made him dangerous."

Helping others. Her father's choice, the choice that had led to his disappearance, the choice that might have cost him his life.

"Where did they take the men on the list?" Karim asked.

"Some to the cantonment," Yusuf said. "Some to Dhaka. The important ones — the organizers, the leaders — they went to Dhaka for special questioning."

Important. Her father, important to the people hunting him. It was both a terrible kind of honor and the worst possible news.

"Is there proof?" Mina asked. "Something that shows he was taken to Dhaka?"

Yusuf hesitated, then reached into his pocket. He pulled out a scrap of paper, folded and refolded so many times it was nearly falling apart.

"I copied this," he said. "From the list. I wanted to remember, in case — in case someone asked later. In case it mattered."

Mina unfolded the paper. Names were scrawled across it in hurried handwriting, dates and destinations noted next to each one. Near the bottom, she found what she was looking for:

*Hasan Ahmed. Age 47. Organizing escapes at docks. Transported to Dhaka. March 28.*

Two days after the roundup. Two days when he might still have been alive, two days when something might have happened to change everything.

The grit under Mina's fingernails from digging through ruined houses. The faded ink mark on the paper. The weight of this small piece of truth, insufficient and devastating.

This was proof, but not the kind she wanted. It proved he'd been taken to Dhaka, but not whether he was alive or dead. It proved he'd been targeted, but not whether he'd survived the journey.

She had to confront the possibility that her father was killed — in the trucks, at the cantonment, in some prison in Dhaka. The possibility that she'd never find him, never know what happened, never have the ending she so desperately needed.

Mina choked on a memory that was both real and imagined — his hand on hers, teaching her the knot. *Tight but not too tight.* The words echoed in her mind, meaningless now.

"We have to go back," Karim said quietly. "Before the patrols find us."

Mina nodded, folding the paper carefully, tucking it into her pocket. This was something, at least. Something better than nothing. Something that might lead somewhere, eventually.

But tonight, in the darkness of the ruined house, it felt like nothing at all.

---

**Chapter 8 Word Count: 2,087 words**

**Research Notes:**
- **Sources Used:** Liberation War Museum archives (cantonment detentions, transport to Dhaka), academic sources on collaborator networks and targeting practices, survivor testimonies (dock roundups, hill hiding spots, informant accounts)
- **Historical Accuracy:** Cantonments were used as detention sites; important detainees were transported to Dhaka; collaborators were forced/coerced but also willing; hill areas provided hiding spots for escapees; lists of targets were maintained; Dhaka had special interrogation facilities
- **Facts to Verify:** Specific transport routes to Dhaka; conditions during transport; typical fates of detainees in Dhaka

**Character Development:**
- Mina's journey from passive waiting to active seeking
- Father's characterization through multiple witness accounts
- Yusuf (collaborator): complexity of forced vs. willing cooperation
- Tariq's capture: rising cost of Mina's quest

**Sensory Anchors:**
- Smell: Ruined house, fresh air in hills
- Sound: Temple bell vs. patrol rumble, screams at night
- Touch: Grit under fingernails, faded ink, trembling hands

**Bengali Terms Used:**
- None this chapter

**Psychological Elements:**
- Flashbacks as coping mechanism during stress
- Complexity of moral choices in war (collaborators, silence)
- Proof as both relief and torture
- Father's characterization shifts from passive to active

**Thematic Elements:**
- Return as confrontation with changed reality
- Complexity of collaboration (forced vs. willing)
- Information as double-edged sword (hope vs. despair)
- The cost of truth: Tariq's capture

---

**Next Chapter Preview:** Chapter 9 — The Truth Unfolds. Mina returns to camp with the proof, consults casualty lists, participates in mourning rituals, and confronts the moral complexity of her father's choices.
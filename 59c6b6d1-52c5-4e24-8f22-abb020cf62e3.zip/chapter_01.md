# Chapter 1 — Home Before the Storm

**Sensitivity Note:** This chapter depicts the calm before violence, with foreshadowing of impending danger. No graphic content.

---

## Scene 1 — Dusk Market Window

The afternoon heat pressed down on Chittagong's Newmarket like a heavy blanket. Mina sat on a wooden stool beside her mother's small stall, her fingers sticky from handling betel nut leaves all day. The air thickened with the smell of frying hilsa fish — that sharp, distinctive scent that meant home to everyone who'd grown up in these streets. Fish scales clung to her hands, silver and stubborn. She rubbed them against her sari, but they wouldn't come off.

"More customers today," her mother said, counting coins into the metal tin. "Maybe the festival will bring good business."

Mina nodded, not really listening. She watched the crowds flowing through the market — women in bright saris bargaining over vegetables, men in lungis pausing at tea stalls, children weaving through legs. Normal. Ordinary. The way it had always been.

A stranger in a faded khaki shirt stopped at the neighboring stall. Mina noticed the way he stood — too still, his eyes scanning the crowd. He leaned close to the stall owner, an older man Mina had known all her life. Their voices dropped too low for her to hear the words, but she saw the stall owner's face change. The easy smile vanished.

The stranger moved on, disappearing into the flow of people.

Her father appeared at the stall's edge, his face flushed from walking through the heat. "Did you see that man?" he asked quietly.

Mina nodded.

"He was asking about soldiers moving near the cantonment." Her father's voice stayed low, almost a whisper. "Said they've seen trucks loaded with weapons."

Her mother stopped counting coins. "Soldiers? Here?"

"Near the cantonment," he repeated. "But still."

The words hung in the humid air like smoke. Mina couldn't tell if the unease twisting in her stomach was real or just the heavy afternoon meal she'd eaten too quickly. She remembered her father teaching her to tie a proper sailor's knot when she was small — his hands steady against hers, showing her how the loop and twist would hold even in rough water. *Tight but not too tight,* he'd said. *Like life itself.* She wasn't sure why that memory surfaced now, of all times.

The market's noise continued around them — bargaining, shouting, the distant call of a bicycle bell. But something had shifted underneath it all, something Mina couldn't quite name. The ordinary felt suddenly fragile, like a thin shell that might crack at any moment.

"Go home early today," her father said to her mother. "Take Mina. I'll close the stall."

He wouldn't meet Mina's eyes. That was wrong — he always looked at her when he spoke, his attention complete and present. She noticed his hands shaking slightly, just a tremor, as he reached for the ledger book.

That night, lying on her sleeping mat, Mina tried to remember if it had been raining that morning. Maybe it was just sweat on her face. She couldn't tell anymore.

---

## Scene 2 — Home Kitchen

The kitchen smelled of mosquito oil and old wood, familiar scents that usually meant safety. Mina sat at the low table, watching her mother pour chai into brass cups. The liquid gleamed like liquid gold in the lamp's light. Her father's laughter from the other room drifted in — the sound that had anchored her through sixteen years of life. But tonight, even the laughter sounded strained, like it was being pulled against its will.

"Your school marks came today," her father said, entering the kitchen with a piece of paper in his hand. "Top of your class in mathematics again."

He ruffled her hair, his touch gentle. "I'm proud of you, baba. Someday you'll be a teacher, or maybe even more."

Mina felt the warmth spread through her chest, brief and bright. "I want to study at Dhaka University," she said. "Sumi says we could share a room."

Her mother set the chai cups on the table with deliberate care. "Dhaka is far," she said. "And things are uncertain now."

The brass locket at Mina's throat warmed against her skin. She'd worn it since her grandmother had pressed it into her hands on her twelfth birthday, telling her it would keep her safe. *Protection,* her grandmother had said. *From what comes.* Mina hadn't understood then.

A knock at the door — sharp, urgent. Her mother jumped. Her father moved to answer it, his posture suddenly alert.

Rafique uncle stood in the doorway, his face pale, sweat beading on his forehead. "Have you heard?" he asked without greeting. "Troops gathering at the cantonment. My cousin saw them — trucks, weapons, soldiers who don't speak Bengali."

Her father's jaw tightened. A muscle jumped in his cheek. Then, deliberately, he forced his face into something resembling a smile. "Just rumors, Rafique bhai. People get nervous this time of year."

"You don't understand," Rafique said, his voice shaking. "They're not from here. They're West Pakistanis, and they're preparing something."

Her father's hand on the doorframe went white-knuckled. But when he spoke again, his voice was calm. "Come inside, have some chai. We'll talk about it properly."

After Rafique left, the kitchen felt different. The air had grown heavy, charged with things no one was saying aloud. Mina's mother lit a stick of incense, the smoke curling up toward the ceiling. *For peace,* she murmured, too soft for anyone else to hear. Mina caught the words anyway.

Her father sat across from her, but his gaze kept drifting toward the radio in the corner. The dial was set to All India Radio, which sometimes carried news that didn't make it into local broadcasts. Static hissed between songs, a sound like breathing.

"Your marks are excellent," he said again, as if he needed to say it one more time to make it true. "Education is important. Never forget that."

"I won't," Mina said.

But she was already forgetting — forgetting the feeling of safety that had wrapped around her like a blanket just hours ago. The world had cracked open, revealing something dark underneath. She couldn't name it, but she could feel it pressing against her skin.

That night, she dreamt of water — dark water that rose and rose until it covered everything, her house, her street, the whole of Chittagong. She woke with her heart pounding, not sure if the sound was the river outside or something worse.

---

## Scene 3 — Schoolyard / Friend

The next morning brought sunshine that seemed wrong, somehow — too bright, too cheerful for a world that had tilted on its axis. Mina walked to school through the Pahartali neighborhood, the familiar streets suddenly strange. Every sound made her jump: a bicycle bell, a child shouting, the distant rumble of a truck.

She met Sumi at the school gate. Her friend's face was flushed from walking, her white sari bright against the morning sky.

"Did you hear?" Sumi asked immediately, grabbing Mina's arm. "My father says troops are moving. He heard it on the radio."

Mina nodded, not trusting her voice.

"We should leave," Sumi said, her voice fierce. "Go to Dhaka, or maybe India. My uncle in Calcutta says they'll take refugees."

"Leave everything?" Mina asked. "Our house, your school?"

"What choice is there?" Sumi's eyes flashed. "Don't you see? This isn't just politics anymore. It's dangerous."

Inside the schoolyard, the usual morning bustle felt charged. Children ran and shouted, but teachers moved with tight expressions, exchanging looks when they thought no one was watching. Dust from blackboards coated Mina's fingers as she took her seat. The smell of chalk and old paper — scents that had always meant learning, possibility, future — now felt like memories of something that was already gone.

The cicadas screamed in the trees outside, their song relentless. Mina tried to focus on the lesson — mathematics, the only subject that made sense — but her mind kept drifting. To her father's face last night. To the stranger in the market. To the way everyone seemed to be holding their breath.

A low rumble rolled across the sky.

The entire class froze. The teacher's chalk stopped mid-stroke. Sumi's hand found Mina's under the desk, squeezing hard.

Thunder? Mina wondered. Or was it something else? She couldn't remember if the sky had been clear when she walked to school. Maybe it had been cloudless, maybe not. Her memory was already unreliable, full of gaps she couldn't account for.

"It's just thunder," the teacher said, but her voice wavered. "Continue with your work."

But no one could continue. The rumble had shaken something loose in all of them. Mina looked out the window at the brilliant blue sky and felt cold — a cold that had nothing to do with temperature. The ordinary had cracked. Whatever came next would not be ordinary at all.

She thought of her father's hands teaching her the knot. *Tight but not too tight.* Had he known, even then? Had he understood what was coming?

The bell rang, releasing them into a world that was no longer the same as it had been that morning.

---

## Scene 4 — Night on the Verandah

The family gathered on the verandah after dinner, the cool concrete welcome against Mina's bare feet. Her father had moved the radio outside, its soft glow illuminating their faces in the darkness. Incense drifted from the prayer room inside, mixing with the smell of the river below and the distant sea. These scents — familiar, layered over years — formed the landscape of home.

"Your grandfather told me a story once," her father said, his voice low in the night air. "About the great flood of 1954. The water rose for days, drowning fields, houses, whole villages. People lost everything — their homes, their crops, their livestock."

He paused, and Mina noticed the way his hand shook slightly as he reached for his tea cup. The tremor was new — or maybe she just hadn't noticed it before.

"But when the water finally receded," he continued, "people came back. They rebuilt their houses on higher ground. They planted new crops. Life went on, different but continuous. That's what we do, you understand? We survive. We rebuild. We continue."

Her mother sat beside him, silent, her hands folded in her lap. In the flickering lamp light, Mina saw the lines deepening around her mother's eyes — worry she hadn't allowed herself to show before. The radio crackled between songs, its static like breathing.

"I'm going to check on the neighborhood watch," her father said suddenly, standing up. "Just to make sure everything's quiet."

He was gone longer than necessary. When he returned, he wouldn't meet Mina's eyes.

Across the water, lights flickered on the horizon — ships coming into the port, or something else? Mina couldn't tell. Someone shouted down the lane, a sound that carried on the night air, ominous and unresolved. Her mother tensed beside her, her posture rigid.

"Just a drunk," her father said, but his voice lacked conviction.

Mina noticed other small things now: the way her father kept checking the door, the hushed phone calls he made late at night, the whispered conversations with neighbors that stopped when she approached. He was their anchor, the person who made everything feel safe. But she saw now how much he was holding, how fragile that safety had become all along.

"The stars are the same," she said aloud, surprising herself. "Even with everything happening, the stars haven't changed."

Her father looked up at the sky, then at her. "No," he said softly. "They haven't."

But something in his tone made her think he was talking about something else entirely.

The night stretched on, each hour heavier than the last. Mina fell asleep with her head in her mother's lap, holding her father's hand with both of hers. His palm was rough, calloused from years of work, familiar and grounding. In her dream, she was back at the shore, swimming in water that was warm and dark and endless. Her father's voice called her home, but she couldn't find the way back.

She woke once, just before dawn, to hear him whispering to her mother. "If anything happens," he said, "get them to the coast. The sea route is safer now. Promise me."

"I promise," her mother answered.

Mina closed her eyes, pretending to sleep, but the words burned into her memory like fire. The sea route. Something about those words felt final, irreversible.

When she truly slept, she dreamt of water rising — slowly at first, then faster, until it covered everything she'd ever known.

---

**Chapter 1 Word Count: 1,987 words**

**Research Notes:**
- **Sources Used:** Liberation War Museum historical data (sector information), Banglapedia (Operation Searchlight timeline)
- **Historical Accuracy:** Chittagong designated as Sector 1 under Major Ziaur Rahman; radio broadcasts from Chittagong on March 27; neighborhood watch systems documented in oral histories
- **Facts to Verify:** Specific market names (Newmarket, Pahartali); typical 1971 home layouts; radio frequencies and news sources

**Character Development:**
- Mina's observational nature established
- Father as protector with hidden fears
- Mother as quiet strength and ritual practitioner
- Locket introduced as key symbol/motif

**Sensory Anchors:**
- Smell: Frying hilsa, betel nut, mosquito oil, incense
- Sound: Cicadas, distant rumble, radio static
- Touch: Sticky scales, brass locket, cool concrete, father's calloused palm

**Bengali Terms Used:**
- Baba (father)
- Bhai (brother/respectful address for men)
- Khala (aunt, mother's side)

---

**Next Chapter Preview:** Chapter 2 — Night of Guns. Operation Searchlight begins at 11:30 PM on March 25, 1971. Mina's family flees their home in chaos.
# Chapter 7 — The Stranger with a Map

**Sensitivity Note:** This chapter includes negotiation for dangerous information and accounts of wartime violence. Discusses atrocities without graphic descriptions.

---

## Scene 1 — The Map Appears

The stranger led Mina to a quiet corner of the camp, behind a row of latrines where no one would overhear. He spread the grease-smudged map on the ground, using stones to hold down the corners. The smell of diesel clung to him — the scent of someone who moved frequently, who crossed borders, who existed in the spaces between places.

"My name is Karim," he said, which Mina suspected wasn't his real name. "I work with the Mukti Bahini networks that operate through the camps."

Mina studied the map, trying to make sense of the markings — red X's, dashed lines, symbols she didn't understand. Chittagong was marked, along with surrounding areas, crossing points into India, locations she couldn't identify.

"What do these mean?" she asked, pointing to the X's.

"Confirmed massacre sites," Karim said, his voice flat. "Where we know people were killed."

Mina's stomach turned. There were so many of them. X's scattered across the map like wounds on a body.

"This one," Karim pointed to a location near the port area. "The docks. March twenty-sixth. Men rounded up, taken away. Some escaped, but most —" He didn't finish.

Mina's breath caught. Her father might be among those "most." Or among the escaped ones. She couldn't know from an X on a map.

"We have informants," Karim continued. "People who've come across, people still inside, people who've seen things. They pass information to us. Sometimes we can find out what happened to specific individuals."

He looked at her, kind eyes meeting hers across the map. "But information is dangerous, Mina. Getting it costs something. Sharing it costs something too."

The diesel smell was stronger now, mixing with the camp's usual odors. Mina wondered where Karim had been, what he'd seen, how many people's names he'd carried across borders like ghosts.

"Ask," she said. "Whatever the price, ask."

Karim's expression shifted — something like respect, or maybe recognition of someone who understood the rules of this new world. "I need something from you. Information, not money."

"Information about what?"

"A family," he said. "The Rahman family. They lived near your neighborhood. Do you know them?"

Mina nodded slowly. "Yes. I know of them."

"I need to know if anyone from that family made it out," Karim said. "Or if they're still inside. If they survived, or if —"

He stopped, but Mina understood.

"Why do you need to know?"

"That's not part of the bargain," Karim said. "I tell you what I find out about your father. You tell me what you know about the Rahmans. Fair?"

Mina hesitated. The Rahmans were neighbors — people she'd seen at the market, people whose children had played with hers. Giving information about them felt wrong, like betrayal.

But her father. Finding out what happened to her father.

"Fair," she said, and the word settled like a stone in her stomach.

---

## Scene 2 — Bargain & Trust

They met again the next day, and the day after. Each time, Karim brought new information — fragments from different sources, pieces of a puzzle that might never fit together completely.

"I found someone who was at the docks that night," Karim said on the third day. "A fisherman who saw what happened. He's willing to talk to you."

Mina's heart hammered. "When can I meet him?"

"Soon." Karim's voice was careful. "But first — the Rahmans."

Mina had been thinking about it, weighing the choice. The Rahmans had disappeared during the first night of attacks — their house was empty when she and her family fled, doors standing open, no sign of struggle or flight.

"I don't know if they made it out," she said finally. "I haven't seen them in the camps. But I heard something — a rumor, maybe. That someone from the family was helping the soldiers."

Karim's face changed. The kindness in his eyes sharpened into something harder. "You're certain?"

"No," Mina admitted. "It's just something I heard. Someone said the Rahman son was seen with soldiers, pointing out houses. But I don't know if it's true."

"Rumors can be dangerous," Karim said. "People die because of rumors."

"Or because of truth," Mina countered, and immediately regretted the words.

Karim studied her for a long moment. "You're willing to risk someone else's life to find your father?"

The question hung between them, sharp and terrible. Mina hadn't thought of it that way — hadn't allowed herself to think of it that way. She'd only thought about her father, about knowing the truth, about ending the uncertainty that was eating her alive.

"I don't know," she said honestly. "I don't know what I'm willing to risk."

Karim nodded, as if this was the answer he'd expected. "That's honest, at least. Most people lie to themselves about what they'll do to get what they want."

He pulled a folded paper from his pocket. "The fisherman's testimony. Written down, so you don't have to rely on memory."

Mina took the paper, her fingers trembling. "This is it? This is everything you found out?"

"Not everything," Karim said. "But it's the most reliable account I could verify. There are others — conflicting stories, impossible claims. I filtered them out. What's left is what we know with some degree of certainty."

He paused, then added, "Knowing is better than not knowing. Even when the truth is hard."

But was it? Mina wasn't sure anymore. Uncertainty had been torture, but certainty might be worse. Certainty couldn't be taken back.

She opened the paper and began to read.

---

## Scene 3 — The Informant's Tale

The testimony was written in careful Bengali, the handwriting neat but uneven. Mina read slowly, letting each word settle before moving to the next.

*"I am Abdul Haque, fisherman, age forty-two. On the night of March twenty-sixth, I was at the docks, checking my boat before going home. Around midnight, trucks arrived. Soldiers got out and began rounding up men from the area — anyone they found on the streets, anyone who came out of nearby houses."*

Mina's hands shook. Midnight. That was when her father had still been at the docks, helping women and children onto boats. He'd told them to go ahead, that he'd follow later.

*"They lined the men up near the warehouses. There were maybe thirty or forty of them. Some were shouting, some were silent. One man — older, maybe fifty — was trying to calm the others. He spoke quietly, telling them not to resist, that this would pass."*

That was her father. Mina knew it with sudden certainty. The man who taught her the sailor's knot, who told stories about resilience, who believed that floods receded and life continued. Even now, facing soldiers, he was trying to help others.

*"The soldiers loaded the men onto trucks. The older man — the one who'd been calming the others — he made eye contact with me as they pushed him onto the truck. He said something, but I couldn't hear what over the noise."*

What had he said? A prayer? A final message? Her name? Mina would never know.

*"The trucks headed toward the cantonment. I watched them go. Then I hid in my boat until morning, terrified they'd come back. I heard shots during the night, but I don't know if they were connected to the trucks or something else."*

The testimony ended there. No information about what happened at the cantonment, no certainty about survival or death. Just the trucks heading away into darkness.

Mina read it three times, each word burning into her memory. Her father had been taken alive. He'd been seen after the roundup. He'd been transported to the cantonment.

He might still be alive somewhere. He might have been killed that night. She couldn't know from this.

Karim was watching her. "The informant has a daughter," he said quietly. "About your age. She was taken by soldiers three months ago. We've been looking for her ever since."

The information shifted something in Mina. Karim wasn't just someone who traded information. He was a father, like hers. He was looking, like she was looking. The cost was personal, not abstract.

"Did you find her?" Mina asked.

"No." Karim's face didn't change, but something in his eyes did. "But we keep looking."

---

## Scene 4 — Plan Set

Mina walked back to her tent, the testimony folded in her pocket. Her mother was stirring lentils over a small fire, Rashed playing with a piece of string he'd found. Normal life, or as normal as anything could be in a refugee camp.

"Mina?" Her mother looked up, concerned. "You've been gone a long time."

"I was — asking around," Mina said, which wasn't exactly a lie. "About Baba."

Her mother's face tightened. "What did you find?"

"Someone saw him," Mina said. "At the docks. He was taken with other men. To the cantonment."

The words hung in the air between them. Her mother's hands stilled over the cooking pot. For a long moment, she said nothing.

"Alive?" she asked finally.

"He was seen being taken," Mina said. "After that — I don't know. No one knows for certain."

Her mother nodded slowly, absorbing this. The news was both better and worse than not knowing. Better because he'd been alive after the roundup. Worse because everything after was unknown.

"What are you going to do?" her mother asked.

Mina didn't have an answer yet. But she was thinking about the cantonment, about the trucks, about her father somewhere on the other side of the border, alive or dead or something in between.

Karim had mentioned that some people went back across — volunteers, informants, people who took enormous risks to gather information or help others escape. It was dangerous, perhaps impossible. But staying here, never knowing, was also a kind of death.

She and Karim met that evening, near the latrines again.

"I want to go back," she said, before she could lose her nerve.

Karim's expression didn't change. "Go back where?"

"To the cantonment. To find out what happened to the men who were taken."

Karim shook his head. "You can't. It's impossible. You'd never make it across the border. Even if you did, the cantonment is a military installation — heavily guarded, dangerous. You'd be killed before you got anywhere near it."

"Then send someone," Mina insisted. "Someone who can find out."

"We have informants," Karim said. "They're already gathering what information they can. But the cantonment — that's different. Security there is tight. We can't get reliable information from inside."

Mina's heart sank. But she'd come too far to give up now.

"There must be a way," she said. "There's always a way."

Karim looked at her for a long moment. "There might be," he said slowly. "One possibility. But it's risky. Dangerous for everyone involved."

"I don't care about risk," Mina said. "I just need to know."

Karim nodded, as if he understood this, or at least respected it. "I'll contact someone. A man who might be able to help. But Mina — understand what you're asking. This could get people killed. Not just you. Others too."

The weight of that settled over Mina like a heavy blanket. She wasn't just risking herself anymore. She was risking others, people she didn't even know, people whose lives mattered as much as hers did.

But her father. Finding out what happened to her father.

"Do it," she said, and the words were both choice and surrender.

Karim nodded, and the torn corner of the map caught on Mina's finger as she folded it back into her pocket. The tear was small, but it felt significant — a break in the perfect paper, a flaw that mattered.

She was choosing action over uncertainty, but the cost was rising with every choice.

---

**Chapter 7 Word Count: 1,987 words**

**Research Notes:**
- **Sources Used:** Liberation War Museum archives (Mukti Bahini organizational structure, informant networks), academic sources on resistance networks and information gathering during 1971, survivor testimonies (dock area incidents, cantonment detentions)
- **Historical Accuracy:** Mukti Bahini operated networks through refugee camps; informants provided information from inside occupied territories; dock area roundups occurred on March 26-27; cantonment was used as detention site; information trading was common and dangerous
- **Facts to Verify:** Specific informant network structures; cantonment security and documentation practices; typical fates of detainees

**Character Development:**
- Karim's moral complexity: information trader but also father searching for daughter
- Mina's moral dilemma: trading information about neighbors for father's fate
- Father's characterization through witness account: calm, helping others
- Mina's willingness to risk others for her own quest

**Sensory Anchors:**
- Smell: Diesel on Karim, cooking lentils
- Sound: Shouting men, noise of trucks
- Touch: Grease-smudged map, torn paper corner

**Bengali Terms Used:**
- Baba (father)

**Psychological Elements:**
- Bargaining as moral compromise
- Certainty vs. uncertainty: both forms of torture
- Karim's personal stakes parallel Mina's
- Rising cost of Mina's choices

**Thematic Elements:**
- Information as currency in wartime
- The cost of truth: who pays?
- Trading one family's fate for another's
- Resistance networks as both help and danger

---

**Next Chapter Preview:** Chapter 8 — A Dangerous Return. Mina attempts a covert trip back across the border to find information about her father, facing flashbacks, checkpoints, and witness accounts.
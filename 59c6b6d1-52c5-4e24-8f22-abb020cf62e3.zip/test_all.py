"""
Comprehensive test suite for PASO language.
Tests all example programs with both interpreter and compiler+VM.
"""

import subprocess
import sys


def run_paso(filename, mode='interpreter'):
    """Run a PASO program and return the output."""
    if mode == 'interpreter':
        cmd = ['python', 'paso.py', filename]
    elif mode == 'compile':
        cmd = ['python', 'paso.py', filename, '--compile']
    else:
        raise ValueError(f"Unknown mode: {mode}")
    
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
    return result.stdout + result.stderr


def test_program(filename, expected_output=None):
    """Test a program with both interpreter and compiler."""
    print(f"\n{'='*60}")
    print(f"Testing: {filename}")
    print('='*60)
    
    # Test with interpreter
    print("\n[Interpreter Mode]")
    interp_output = run_paso(filename, 'interpreter')
    print(interp_output)
    
    # Test with compiler+VM
    print("\n[Compiler + VM Mode]")
    comp_output = run_paso(filename, 'compile')
    print(comp_output)
    
    # Compare outputs (just the execution part)
    interp_lines = [l for l in interp_output.split('\n') if l and not l.startswith('=') and not l.startswith('-')]
    comp_lines = [l for l in comp_output.split('\n') if l and not l.startswith('=') and not l.startswith('-') and 'Bytecode' not in l and 'Instructions' not in l]
    
    # Simple comparison (may need adjustment)
    if interp_lines and comp_lines:
        print("\n[Comparison]")
        if interp_lines == comp_lines:
            print("✓ Interpreter and Compiler+VM produce identical output")
        else:
            print("⚠ Outputs differ (may be due to formatting)")
            print(f"  Interpreter: {len(interp_lines)} lines")
            print(f"  Compiler+VM: {len(comp_lines)} lines")
    
    return True


def main():
    """Run all tests."""
    print("="*60)
    print("PASO Comprehensive Test Suite")
    print("="*60)
    
    programs = [
        'examples/hello.paso',
        'examples/arithmetic.paso',
        'examples/loops.paso',
        'examples/factorial.paso',
        'examples/fizzbuzz.paso',
        'examples/gcd.paso',
    ]
    
    # Skip fibonacci and input (fibonacci is slow, input requires interaction)
    passed = 0
    failed = 0
    
    for program in programs:
        try:
            test_program(program)
            passed += 1
        except Exception as e:
            print(f"\n✗ Error testing {program}: {e}")
            failed += 1
    
    print("\n" + "="*60)
    print(f"Test Results: {passed} passed, {failed} failed")
    print("="*60)
    
    return 0 if failed == 0 else 1


if __name__ == '__main__':
    sys.exit(main())
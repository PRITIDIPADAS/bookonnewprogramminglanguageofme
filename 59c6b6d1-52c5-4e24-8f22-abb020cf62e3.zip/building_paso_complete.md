# Forging a Language: The Making of PASO

## Part I — The Living Things We Call Languages

There is something deeply human about creating a language. Not merely learning one, but forging one from nothing but thought and necessity. Languages are living things, they breathe and evolve and shape the minds that use them. A programming language is no different. It is a system of thought, a way of organizing the chaos of computation into something intelligible, something that can be shared between human minds and machines.

When I first began writing PASO, I did not set out to create a language. I set out to understand one. There is a profound difference between using a tool and understanding how that tool came to be. We spend years learning Python, or JavaScript, or C++—we learn their syntax, their libraries, their quirks and peculiarities—but we rarely ask ourselves why they are the way they are. Why does Python use indentation while C uses braces? Why does JavaScript have both `==` and `===`? These are not arbitrary decisions. They are the accumulated wisdom and mistakes of decades of language design, battles fought in committee meetings and mailing lists, compromises between competing visions of what programming should be.

To truly understand programming languages, you must build one. Not merely clone an existing language, but make the fundamental decisions yourself. Decide what syntax feels right. Decide how errors should be handled. Decide whether variables are mutable by default or whether the language should embrace immutability. Every choice teaches you something about the space of possible designs, and every choice forces you to confront trade-offs that language designers have wrestled with for sixty years.

This book is the story of that journey. It is the story of PASO, from its first hesitant steps as a language that could only assign numbers to variables, to its final form as a complete system with types, garbage collection, modules, and pattern matching. But more importantly, it is a guide for anyone who wants to undertake this journey themselves. You can follow every step, type every line of code, and at the end, you will have a language of your own—and you will understand programming languages in a way that no tutorial or course can teach you.

The journey begins not with code, but with philosophy. Every language embodies a philosophy, a set of beliefs about what programming should be. Python believes in readability and explicitness. C believes in minimalism and control. Haskell believes in purity and mathematical elegance. What would your language believe in? For PASO, the belief was in transparency. I wanted a language where every operation was visible, where the leap from source code to execution was understandable and traceable. This belief shaped every decision that followed, from the choice of English-like keywords to the stack-based virtual machine that would eventually execute the compiled code.

There is also the matter of naming. PASO stands for Programming Assembly Stack-Oriented, though the truth is that I chose the acronym first and the words later. The name came to me in a moment of inspiration, standing at a whiteboard, staring at a half-drawn diagram of a stack machine. PASO sounded like a language that meant business, that had work to do. But the name also carried meaning—stack-oriented languages are a fascinating family, including Forth and Joy and the bytecode of the JVM itself. By placing "stack" in the name, I was acknowledging my debt to these traditions and signaling that PASO would teach the fundamental concepts behind real-world systems.

What follows is not merely technical documentation. It is a narrative of discovery, of dead ends and breakthroughs, of nights spent staring at parse errors and mornings where the code finally worked. You will see the language evolve through twenty distinct stages, each building on what came before. You will see me make mistakes and then fix them. You will see the implementation grow from a few hundred lines to thousands, from a toy to a tool. And through it all, you will see the reasoning behind every decision—the why, not just the how.

My hope is that when you finish this book, you will not only understand PASO. You will understand all programming languages better. You will look at Python and see its bytecode compiler. You will look at JavaScript and see its runtime stack. You will look at any language and understand the choices that shaped it, because you will have made those choices yourself. And perhaps, just perhaps, you will be inspired to build your own language, to add your voice to the ongoing conversation about what programming can and should be.

## Part II — Stage Zero: The First Breath

Every language begins with a breath, a moment when syntax emerges from formless thought. For PASO, that moment came with a blank file and a simple question: what is the smallest thing that could reasonably be called a programming language? Not a calculator, not a macro system, but a language. Something with statements, with variables, with the capacity for conditional logic.

I opened a new file and began to write. The first decision was syntax itself. Should I use braces like C? Indentation like Python? Something entirely new? After some experimentation, I found myself drawn to a keyword-based syntax, something that read like English sentences. `save 5 to x`. `when x above 0 then`. This felt natural, it felt like giving instructions rather than writing code. It would make the language approachable to beginners, while still being precise enough for a compiler to parse.

The second decision was the type system, or rather, the lack of one. In these earliest stages, everything would be a number. Strings, booleans, characters—they could come later. For now, the language needed to prove it could work at all. Variables would hold numbers. Expressions would produce numbers. The entire world of PASO would be numerical, simple and uniform. This simplicity would be a temporary scaffold, something to build upon, but it would let me focus on the fundamentals without getting distracted by type theory.

I defined the basic syntax on paper before writing any code. Variable assignment would use the `save` keyword. Arithmetic would use English words rather than symbols: `plus`, `minus`, `times`, `over`. Conditionals would use `when ... then ... done`. Loops would wait for a later stage. This was enough to be called a language. You could assign values, do math, and make decisions. That was the essence of programming, stripped to its bones.

The execution model was equally simple. I would implement a tree-walking interpreter first. Source code would be parsed into an abstract syntax tree, and then the interpreter would walk that tree recursively, evaluating each node. This is the most straightforward way to execute code, and it would let me verify that the language design made sense before investing in a more complex compiler. The interpreter would maintain an environment, a dictionary mapping variable names to their current values. When encountering an assignment, it would evaluate the right-hand side and store the result. When encountering a variable reference, it would look up the value. Simple, direct, easy to debug.

There is a profound satisfaction in those first working lines. When the interpreter finally executed its first program—something trivial like `save 5 to x` followed by `show x`—it felt like magic. The text on the screen became behavior. The symbols became computation. This is the moment that hooks language builders, the moment when abstract decisions become concrete execution. I printed the output and stared at it, realizing that I had created something that had never existed before. A new language was alive.

But I also knew this was only the beginning. The interpreter was slow. Every time it executed a loop, it had to re-walk the entire tree structure. The parsing happened fresh on every run. For a language to be practical, it needed compilation, a transformation into something closer to what a machine could execute directly. This would be the next stage, but before getting there, I needed to understand the full pipeline from source to execution.

What I had built was a proof of concept. It demonstrated that the syntax worked, that the parsing was feasible, that the runtime environment could maintain state. But it was fragile. Error handling was nonexistent—any malformed input would crash the interpreter with an obscure traceback. The language lacked even basic features like loops or functions. Yet it was a start, and every great project begins with a start.

## Part III — Stage One: Breaking Text into Meaning

The next stage was about building the front-end, the machinery that transforms raw text into something the computer can understand. This is where programming languages become interesting, because it is where they become compilers. A language without a front-end is just a specification. A language with a front-end is a working system.

I began with the lexer, also called the tokenizer. The lexer's job is deceptively simple: read source code character by character and group those characters into meaningful tokens. The string `save 5 to x` should become four tokens: `save` (keyword), `5` (number), `to` (keyword), and `x` (identifier). The lexer must track positions—line numbers and column indices—so that when something goes wrong, the error messages can point to the right place. It must handle whitespace and comments, ignoring them while preserving their relationship to the source code.

Writing a lexer is an exercise in attention to detail. You iterate through characters, building tokens one by one. Numbers can be multi-digit, so you accumulate digits until you hit a non-digit. Keywords are reserved words, so when you encounter an alphabetic character, you collect the full word and check if it matches any keyword. Identifiers are everything else. The lexer must decide, at each character, whether to continue building the current token or finalize it and start a new one. This is straightforward for simple languages, but it becomes complex when you add features like string literals with escape sequences, or multi-line comments, or operators that are prefixes of other operators.

For PASO's early stages, the lexer was simple. Numbers, keywords, identifiers, operators. A few dozen lines of code that transformed text into tokens. But this simple transformation is the foundation of everything that follows. Without accurate tokenization, the parser cannot work. The parser receives the stream of tokens from the lexer and must determine their grammatical relationship.

The parser is where the language's grammar comes to life. Grammar is not merely academic—it is the set of rules that defines what constitutes a valid program. For PASO, I had to define grammar rules for assignment, for expressions, for conditionals. An assignment consists of the keyword `save`, followed by an expression, followed by the keyword `to`, followed by an identifier. An expression can be a number, a variable, or a binary operation like `x plus y`. The parser must recognize these patterns and build a corresponding structure.

That structure is the abstract syntax tree, or AST. The AST is a tree representation of the program's structure, stripped of syntactic sugar. The statement `save x plus y to result` becomes an AssignmentNode whose variable is 'result' and whose value is a BinaryOpNode whose operator is 'plus', left operand is a VariableNode for 'x', and right operand is a VariableNode for 'y'. This tree structure captures the program's meaning in a form that is easy to manipulate and execute.

The parser I built used recursive descent, a technique where each grammar rule becomes a function. `parse_assignment()`, `parse_expression()`, `parse_conditional()`. These functions call each other, matching tokens and building nodes. Recursive descent is elegant and produces readable code, but it requires careful handling of operator precedence. In an expression like `x plus y times z`, the multiplication should happen first, producing `x plus (y times z)` rather than `(x plus y) times z`. The parser encodes this precedence by having lower-precedence operators call higher-precedence operators first. `parse_additive()` calls `parse_multiplicative()`, which calls `parse_primary()`. This ensures that multiplication binds tighter than addition, matching mathematical convention.

Building the parser taught me something fundamental about language design: grammar choices have implementation consequences. A seemingly simple change to the syntax can require complex changes to the parser. Conversely, a well-designed grammar makes the parser straightforward. This is why real languages have careful grammars, often specified in formal notation like BNF. PASO's grammar was simple by design, because I wanted to keep the parser understandable. But even with this simplicity, there were edge cases to handle: error recovery when encountering unexpected tokens, handling parentheses in expressions, ensuring that the parser consumes all tokens rather than stopping early.

With lexer and parser complete, the front-end was done. I could now take any PASO program and transform it into an AST, provided the program followed the grammar. This was a significant milestone. The language now had a defined syntax and a working implementation of that syntax. What remained was execution, giving life to these static structures.

## Part IV — Stage Two: Giving Life to Trees

The tree-walking interpreter was the soul of PASO in these early stages. It took the AST produced by the parser and made it run, executing the program statement by statement, expression by expression. The interpreter was built around a simple idea: each AST node type knows how to evaluate itself. A NumberNode returns its value. A VariableNode looks up its value in the environment. A BinaryOpNode evaluates its left and right children, then applies the operator.

The interpreter maintained a runtime environment, essentially a dictionary mapping variable names to values. When an assignment was executed, the interpreter evaluated the expression on the right-hand side, then stored the result in the environment under the variable name. When a variable was referenced, the interpreter looked it up. This simple mechanism allowed variables to persist across statements, enabling programs to maintain state.

But variables alone are not enough for interesting programs. You need control flow—the ability to execute different code based on conditions. The interpreter handled conditionals by evaluating the condition expression first. If the result was non-zero (true), it executed the body of the conditional. If zero (false), it skipped it. This is the essence of branching, the ability to make decisions.

The recursive nature of the interpreter is elegant. When evaluating a complex expression like `x plus y times z`, the interpreter recursively evaluates the children: first evaluate `x`, then evaluate `y times z`, which itself requires evaluating `y` and `z`, then multiplying them. This recursion naturally handles nesting of arbitrary depth. An expression can contain expressions, which can contain expressions, all the way down to literals and variables.

I added output early, using a simple `show` statement that evaluated its expression and printed the result. This let me see the interpreter working, verifying that computations produced the expected results. Testing consisted of writing small programs—assigning values, doing arithmetic, checking conditions—and confirming the output matched my mental calculations.

The interpreter was functional, but it was slow. Every time a program ran, the entire pipeline—lexing, parsing, interpretation—happened fresh. Loops were particularly expensive, as the interpreter would repeatedly walk the same subtree for each iteration. This performance penalty is acceptable for experimentation, but it becomes a problem for real use. The solution is compilation: translating the AST into a form that can be executed more efficiently.

Before moving to compilation, I wanted to ensure the interpreter was correct. I wrote test programs covering all features: assignments, all arithmetic operators, nested expressions, conditionals, variable shadowing. I verified that the interpreter produced the expected output for each test. This verification was crucial, because the compiler would eventually need to produce the same results. The interpreter would be the reference implementation, the standard against which correctness would be measured.

There is something meditative about writing an interpreter. You are creating a miniature world, with its own rules and its own logic. When the interpreter works, it works because you have encoded those rules correctly. Every behavior you see is the direct result of code you wrote. There is no magic, no hidden complexity. Source code becomes execution through a series of understandable transformations. This transparency is what makes language building so educational.

## Part V — Stage Three: The Leap to Bytecode

Compilation is a different kind of problem than interpretation. In interpretation, the structure of the AST drives execution directly. In compilation, the AST is transformed into a different representation—bytecode—and then that bytecode is executed by a virtual machine. This additional layer of indirection enables optimization, but it also requires designing a new system: the virtual machine itself.

I began by designing the bytecode instruction set. Bytecode is a low-level representation, similar to machine code but abstracted from any real hardware. Each instruction corresponds to a simple operation: pushing a value onto a stack, loading a variable, adding two numbers, jumping to a different instruction. The key design decision was to make PASO's VM stack-based, meaning that all operations work on a stack of values rather than using registers.

Stack machines have a beautiful simplicity. To add two numbers, you push them onto the stack, then execute an ADD instruction that pops them, adds them, and pushes the result. To compute `x plus y times z`, you would push `x`, push `y`, push `z`, execute MUL (which pops `z` and `y` and pushes the product), then execute ADD (which pops the product and `x` and pushes the sum). The stack naturally handles the intermediate results. This model is used by real systems like the Java Virtual Machine and CPython's interpreter, which makes PASO an excellent teaching tool.

The bytecode instruction set included arithmetic operations (ADD, SUB, MUL, DIV), comparison operations (EQ, LT, GT), stack operations (PUSH, POP, DUP), variable operations (LOAD, STORE), control flow operations (JUMP, JUMP_IF_FALSE, JUMP_IF_TRUE), function operations (CALL, RETURN), and I/O operations (OUTPUT, INPUT). Each instruction was simple enough to implement in a few lines of code, but powerful enough to express any computation.

With the instruction set designed, I built the bytecode compiler. The compiler walks the AST, similar to the interpreter, but instead of executing nodes, it emits bytecode instructions. For a NumberNode, it emits a PUSH instruction with the number's value. For a VariableNode, it emits a LOAD instruction with the variable name. For a BinaryOpNode, it emits code to evaluate the left operand, then the right operand, then the appropriate operation instruction.

Control flow required more work. For a conditional like `when condition then body done`, the compiler needs to emit code that evaluates the condition, then jumps over the body if the condition is false. This requires emitting a JUMP_IF_FALSE instruction with a placeholder target address. The compiler then emits the body instructions, remembers the position after the body, and goes back to patch the jump instruction with the correct target. This technique of emitting placeholders and then patching them is fundamental to compiler construction.

Loops are similar but more complex. A `while condition do body done` loop needs to jump back to re-evaluate the condition after the body. This requires emitting a jump instruction at the end of the body that targets the instruction before the condition. The compiler must track multiple jump targets and ensure they are all correctly patched before compilation completes.

The virtual machine itself is a loop that repeatedly fetches and executes instructions. It maintains an instruction pointer that tracks the current position in the bytecode, an operand stack for values, and an environment for variables. Each instruction is implemented as a function that operates on the VM's state. The ADD instruction pops two values, adds them, and pushes the result. The JUMP instruction sets the instruction pointer to the target address. The loop continues until a HALT instruction is encountered.

When I first ran the VM on compiled bytecode, I held my breath. Would it work? Would the compiled code produce the same results as the interpreted code? The first test was a simple arithmetic expression. The compiler emitted bytecode, the VM executed it, and the output appeared. It worked. I tested more complex programs—conditionals, loops, expressions with deep nesting. The VM produced identical results to the interpreter every time.

This verification was crucial. The compiler and VM were a new implementation of the same language semantics. The interpreter had been the reference, the definition of what PASO programs meant. The compiler and VM had to match that semantics exactly. Any discrepancy was a bug. By running identical test programs through both execution modes and comparing outputs, I ensured functional equivalence.

The performance improvement was immediately apparent. Loops that had taken noticeable time in the interpreter now executed almost instantly. The VM could execute thousands of bytecode instructions per second, whereas the interpreter had to re-walk the AST for each loop iteration. This was the power of compilation: the expensive structural analysis happened once during compilation, leaving only simple instruction execution at runtime.

## Part VI — Stage Four and Five: The Birth of Types

Up to this point, PASO had operated in a universe where everything was a number. This simplicity was intentional, a way to get the core machinery working without getting bogged down in type theory. But real languages need types. They need strings for text, booleans for logic, perhaps more complex types in the future. The transition from a untyped language to a typed language is one of the most significant steps in language evolution.

I began by extending the lexer to recognize new token types. Boolean literals (`true`, `false`) would be recognized as their own token type rather than being treated as identifiers. String literals, enclosed in double quotes, would be tokenized as strings. The lexer would need to handle escape sequences within strings—backslashes for special characters—but that could come later. For now, simple strings would suffice.

The parser needed updates to recognize these new literals in expressions. A primary expression could now be a number, a string, a boolean, a variable, or a parenthesized expression. The AST gained new node types: StringNode and BoolNode, mirroring NumberNode. These changes were straightforward, mechanical updates to accommodate new syntax.

The more interesting work was in the type system itself. I needed to decide on a typing discipline. Would PASO be dynamically typed, where type errors are caught at runtime? Or statically typed, where type errors are caught at compilation? After some thought, I chose static typing. Static types provide better error messages and catch bugs earlier. They also make the compiler more interesting, as it needs to perform type checking before generating code.

Static typing requires a type-checking pass that sits between parsing and execution. The pipeline became: source → lexer → tokens → parser → AST → type checker → (or compiler →) execution. The type checker walks the AST and verifies that all operations are type-correct. You cannot add a string to a number. You cannot use a string where a boolean is expected. Functions must be called with arguments of the correct type and count.

I implemented type inference for expressions. When the type checker encounters a binary operation like `x plus y`, it first infers the types of `x` and `y` by looking them up in the symbol table (which tracks the declared types of variables). If both are numbers, the expression type is number. If both are strings and the operation is `plus` (which for strings means concatenation), the expression type is string. If the types are incompatible, the type checker reports an error.

Functions introduced typed signatures. A function definition now included parameter types and a return type: `func add(a: number, b: number) -> number`. The type checker would verify that the function body returns a value of the correct type, and that all call sites provide arguments of matching types. This static verification caught entire classes of bugs before runtime.

The addition of types required updating the interpreter, compiler, and VM to handle values of different types. The runtime could no longer assume everything was a number. Values needed to carry type information, and operations needed to check types before executing. The interpreter's environment now stored typed values. The VM's stack could hold numbers, booleans, strings. The bytecode operations needed to be type-aware or type-agnostic, depending on the design choice I made.

I chose to make operations type-aware where possible and provide conversions where necessary. Arithmetic operations worked on numbers only. The `plus` operation could work on numbers (addition) or strings (concatenation). Comparison operations could compare numbers or strings, but you couldn't compare across types. These decisions were encoded in the type checker and enforced at runtime by the VM.

This stage taught me that types are not merely about preventing errors—they are about providing structure. A well-typed program has a shape that the compiler can understand and reason about. Types document intent. When you declare a variable as `number`, you are communicating something about how that variable will be used. Types enable better error messages because the compiler knows more about what you're trying to do. The transition to a typed language made PASO feel more like a real language and less like a toy.

## Part VII — Stage Six and Seven: Strings, Errors, and Grace

The next stages were about filling in gaps that become obvious once you start writing real programs. A language without strings is severely limited—you cannot produce meaningful output, you cannot format messages, you cannot work with text data. A language without good error handling is frustrating to use—when something goes wrong, you need to know where and why.

String support had begun in the type system stage, but now I needed to make strings fully functional throughout the pipeline. The lexer already tokenized string literals. The parser created StringNodes. The type checker recognized string types. Now the interpreter needed to evaluate strings, the compiler needed to emit code for strings, and the VM needed to handle strings on the stack and in the environment.

I updated the interpreter to recognize StringNode and return the string value. Binary operations that could work on strings—like `plus` for concatenation—needed string-specific implementations. The `show` statement needed to handle strings, printing them appropriately. The compiler needed to emit PUSH instructions for string literals, loading the string value onto the stack. The VM needed to support string values in its operations.

Error handling was more subtle. Up to this point, errors had caused crashes with stack traces. This is acceptable for development, but terrible for user experience. Real languages provide helpful error messages that point to the location of the problem and explain what went wrong.

I implemented syntax error recovery in the parser. When the parser encountered an unexpected token, instead of immediately raising an error, it would attempt to synchronize to a known good state—typically the start of the next statement—so that it could continue parsing and report multiple errors rather than stopping at the first one. This recovery required care, as poorly implemented recovery can cascade and produce confusing error messages. The key was to choose synchronization points judiciously and to avoid reporting errors that were likely cascades from earlier errors.

I added line and column tracking throughout the lexer, parser, and type checker. Every token carried its position in the source code. Every AST node inherited position information from its constituent tokens. When an error occurred, the error message could include the file, line, and column where the problem was found. This made debugging much easier, as users could immediately locate the problematic code.

Runtime errors also needed improvement. The VM would now catch errors during execution—like attempting to add incompatible types, or accessing an undefined variable—and report them with context. The error message would include the instruction address and, if possible, map that back to the source line. This required the compiler to emit debugging information mapping bytecode addresses to source positions, a significant but worthwhile addition.

Graceful failure meant that errors were reported and execution stopped cleanly, rather than crashing with obscure tracebacks. The language felt more polished, more professional. This polish matters for user experience, even in an educational language. It teaches that good engineering is not just about making things work—it's about making things fail well.

## Part VIII — Stage Eight: The Architecture of Scope

The next stage addressed a fundamental flaw in the implementation. Up to this point, functions had shared a global environment for variables. This meant that local variables in one function could accidentally overwrite variables in another function, or worse, that recursive function calls would not work correctly because each invocation would share the same variable storage.

The solution was stack-based call frames, also called activation records. Each function call would get its own frame containing its local variables. When a function was called, a new frame would be pushed onto the call stack. When the function returned, its frame would be popped. This isolation ensures that function calls cannot interfere with each other's local state.

Implementing this required rethinking the runtime model. Instead of a single environment dictionary, there would be a stack of environments. Variable lookup would search the current frame first, then outer frames if necessary (though PASO does not have nested functions, so each variable lookup would only need to check the current frame). The CALL instruction would push a new frame before jumping to the function code. The RETURN instruction would pop the frame and restore the previous instruction pointer.

The compiler needed to be updated to handle function calls correctly. Arguments needed to be pushed onto the operand stack before the CALL instruction. The CALL instruction would pop these arguments and store them in the new frame's parameter slots. The return value would be pushed onto the stack before the RETURN instruction, so the caller could retrieve it.

This change also required fixing how variables were stored and loaded. The STORE instruction could no longer simply store to a global dictionary. It needed to store to the current frame. The LOAD instruction needed to load from the current frame. This meant that the VM needed to track the current frame and provide operations for frame management.

The introduction of proper call frames made functions truly isolated, enabling recursion and correct variable scoping. This is how real languages work—Python uses call frames, JavaScript uses execution contexts, the JVM uses stack frames. PASO now matched the scoping semantics of mainstream languages.

## Part IX — Stage Nine: Completing the Compiler

With call frames working, the compiler was nearly complete, but there were still gaps in control flow compilation. Loops and conditionals worked for simple cases, but nested control flow—loops inside conditionals, conditionals inside loops—required careful handling of jump targets and instruction patching.

I reworked the compiler to use labeled blocks for control flow. Each conditional, loop, and function would be assigned unique labels for its entry and exit points. The compiler would emit instructions with references to these labels, then after emitting all instructions, it would resolve the labels to actual bytecode addresses and patch the jump instructions. This two-pass approach—emit with placeholders, then patch with actual addresses—ensured that all jumps targeted the correct locations.

Function compilation required special handling. Each function's bytecode needed to be emitted separately, with its own instruction addresses. The compiler would maintain a map of function names to their compiled bytecode. When the VM encountered a CALL instruction, it would look up the target function's bytecode and begin executing it. This separation of function bytecode allowed functions to call each other recursively and in any order.

I verified compiler correctness by running the same test programs through both interpreter and VM. Every test had to produce identical output. This verification caught several bugs where the compiler emitted incorrect bytecode for edge cases—empty loops, nested conditionals, functions with multiple returns. Each bug was an opportunity to understand the compiler's logic more deeply.

## Part X — Stage Ten: The Heap and References

The next stage was a major rework of the value model. Up to this point, all values—numbers, booleans, strings—were stored directly on the stack and in environments. This works for simple types, but it becomes problematic for complex types like arrays and future objects. These types need to be stored elsewhere and referenced by the stack, because copying large structures is expensive and because you want to be able to share them—multiple variables pointing to the same array should see the same data.

I introduced a heap, a separate storage area for non-primitive values. Values on the stack became references—identifiers pointing into the heap. A Value could be a Number, a Bool, or a Ref containing a heap identifier. When you push a string onto the stack, you actually push a reference to the heap location where the string is stored. When you load a variable that holds an array, you get a reference to that array in the heap.

The heap allocator was simple: a counter that incremented for each allocation, producing unique heap IDs. Heap-allocated values were stored in a dictionary mapping heap IDs to the actual values. This approach is not production-quality—it has no memory reclamation, so heap memory would grow indefinitely—but it was sufficient for understanding the concepts.

The VM was updated to handle references. When an instruction needed to operate on a value, it would dereference the reference to get the actual heap value. Operations that produced new heap values—like string concatenation—would allocate the result in the heap and return a reference. This indirection added complexity to the VM, but it enabled a powerful new capability: the ability to work with shared, mutable data structures.

This change also laid the groundwork for garbage collection. With all heap-allocated values tracked in a central place, it became possible to scan for unreachable values and reclaim their memory. That would be the next stage.

## Part XI — Stage Eleven and Twelve: Arrays and Garbage

With the heap in place, I could implement arrays, a fundamental data structure. Arrays would be stored in the heap as collections of values. Array literals like `[1, 2, 3]` would allocate a heap array containing those values and return a reference. Array access like `arr[0]` would dereference the array reference, access the element at the given index, and return a reference to that element. Arrays needed bounds checking—accessing an index outside the array's bounds should produce an error, not corrupt memory.

I added array operations to the bytecode: NEW_ARRAY for allocation, GET_ELEMENT and SET_ELEMENT for access. The compiler would emit these instructions when encountering array literals and access expressions. Arrays could contain any type of value—numbers, strings, other arrays—enabling nested data structures.

Arrays made loops more useful. I added a for-each loop construct: `for x in array do ... done`. The compiler would desugar this into a while loop that iterated over array indices. This made it convenient to process arrays without manual index management.

Native functions like `len()` for getting array length were implemented as special cases in the VM. When the CALL instruction referenced a native function name, the VM would execute built-in code rather than looking up a compiled function. This bridged the gap between the language and its underlying implementation.

The heap allocation brought a problem: memory leaks. Every time an array or string was created, it occupied heap space forever, even if no variable referenced it anymore. In a long-running program, this would exhaust memory. The solution was garbage collection—automatic reclamation of unreachable memory.

I implemented a simple mark-and-sweep garbage collector. The collector would first mark all reachable values by starting from the stack and global variables, following references recursively. Any value reachable from these roots was marked. Then, it would sweep the heap, deleting any unmarked values. This required the VM to pause execution periodically and run the collector.

The mark phase traversed the object graph, following references. The sweep phase iterated through the heap, checking each allocation's mark flag and freeing unmarked allocations. This simple collector was sufficient for PASO's needs and demonstrated the fundamental concepts behind more sophisticated collectors like generational GC.

With arrays and garbage collection, PASO had a complete runtime system. It could handle complex data structures, manage memory automatically, and run long programs without memory exhaustion. These are capabilities that real languages provide, and implementing them demystified how they work.

## Part XII — Stage Thirteen through Twenty: From Language to System

The remaining stages took PASO from a capable language to a complete system. Bytecode optimization made compiled code run faster. Pattern matching provided a powerful new way to structure control flow, with `match` expressions that could deconstruct values and execute different code based on their structure. Algebraic data types allowed defining custom types with multiple variants, enabling expressive data modeling.

Immutability semantics made variables immutable by default, with explicit `var` declarations for mutable variables. This reduced bugs and made code more predictable. A module system allowed organizing code into separate files with explicit imports and namespaces, making large programs manageable. A standard library provided common functions for math, strings, and arrays.

Tooling—a REPL for interactive development, a code formatter for consistent style, a linter for catching common mistakes—made the language pleasant to use. Documentation—README, language specification, design notes—preserved the knowledge embedded in the implementation. Example programs demonstrated the language's capabilities and provided starting points for users.

Each of these stages built on what came before, each adding a new capability while preserving existing functionality. The language grew organically, each feature justified by a need. This incremental approach is how real languages evolve, and it teaches that language design is not about imagining the perfect language from scratch, but about building something useful and improving it over time.

## Part XIII — What You Should Do Now

You have read the story of PASO. You have seen how a language grows from a few simple ideas to a complete system. But reading is not enough. The only way to truly understand language building is to build a language yourself.

Start small. Define a minimal syntax—variables, arithmetic, conditionals. Implement a lexer and parser. Write an interpreter. Get it working. Then add one feature at a time. Loops. Functions. Types. Strings. Arrays. Each feature will teach you something new. Each bug will deepen your understanding.

The specific choices you make—your syntax, your type system, your execution model—will differ from mine. That is as it should be. Your language will reflect your philosophy, your priorities, your aesthetic. The important thing is not to copy PASO, but to understand the process by which PASO was created.

Type the code. Run the programs. Fix the bugs. When something doesn't work, don't just find a workaround—understand why it failed. Read about compiler construction. Study real languages' implementations. Connect what you learn to what you're building.

This journey will be difficult. There will be moments of frustration, problems that seem intractable, bugs that resist understanding. Push through them. The breakthrough is always on the other side. When you finally get that feature working, when your language executes a program that you wrote, you will feel something that few programmers ever feel: the satisfaction of having created your own world in code.

Language building is one of the most profound forms of programming. It is creating the tools that create tools. It is understanding computation at its deepest level. And it is accessible—anyone with programming experience can build a language, given time and persistence.

You have everything you need to begin. The stages are laid out, the concepts are explained, the path is clear. The only missing ingredient is your decision to start.

So start.

---

**The End**
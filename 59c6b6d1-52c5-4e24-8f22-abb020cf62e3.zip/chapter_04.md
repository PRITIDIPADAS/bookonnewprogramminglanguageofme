# Chapter 4 — To the Shore

**Sensitivity Note:** This chapter depicts refugee displacement including crowded boat crossings and encounters with smugglers. Focuses on psychological stress and survival decisions rather than graphic violence.

---

## Scene 1 — The Trek

The road to the coast stretched ahead like a scar across the land. Mina walked with head bent, feet blistering in sandals not meant for distance. Children cried around them, some too exhausted to walk, carried on parents' backs or in arms grown tired from hours of holding.

She remembered swimming in the Bay of Bengal as a child — the salt stinging her eyes, the waves lifting her up, the feeling that the water would hold her. That memory belonged to another life now, another Mina who didn't know what fear tasted like, who believed the world was basically good.

Salt air filled her lungs, but there was no joy in it anymore. Just necessity. The sea meant passage, possibility, escape.

Sand scraped inside her sandals, gritty and relentless. Mina stopped to pour it out, noticing how many others did the same — small repetitive gestures that were all they could control in a world gone mad.

She counted stars to calm herself — the same star over the harbor she used to watch from her bedroom window, imagining futures she would have. It was still there, exactly where it had always been, and somehow that constancy both comforted and horrified her. The stars didn't care what happened on the ground below. They kept their indifferent watch.

"They say Teknaf is safer," someone ahead said. "More boats leave from there."

"Cox's Bazar is closer," another voice answered.

Mina's father didn't join the conversation. His face was set in lines she'd never seen before — exhaustion sharpened by something else. He'd aged ten years since yesterday.

"We'll see when we get there," he said finally. "Whatever has boats."

Whatever has boats. The words hung in the air, pathetic and necessary.

Around them, the column of refugees stretched as far as they could see — hundreds, maybe thousands, all walking toward the water. Mina wondered how many would actually make it across. How many would die before reaching the shore, or drown in the crossing, or be turned back by Indian guards who had their own limits on compassion.

She didn't say these thoughts aloud. Some questions were too dangerous even to think.

---

## Scene 2 — River Crossing

The river crossing was bottlenecked chaos. Boats overloaded beyond any reasonable limit — people packed so tightly that no one could move, children passed overhead from hand to hand because there was nowhere to put them down.

The creak of planks under impossible weight. Oily water reflecting the moon like something dead.

Everyone was praying, but no one spoke the prayers aloud. Just the press of lips together, closed eyes, the slight angle of heads bowed against fear.

Mina's family waited their turn for hours. When they finally reached the dock, the boat already looked too full, but the boatman kept taking people — money changing hands, desperate negotiations, the understanding that too many would die either way.

"Get on," her father said, and there was no room for argument.

Mina squeezed onto the bench between her mother and a woman she'd never seen before. The woman's sari was torn, her face streaked with dirt and tears. She clutched a bundle to her chest as if it contained everything left in the world.

A patrol boat passed in the distance — engines rumbling, lights sweeping across the water. Everyone on their boat froze. Children went silent with that special silence only children could achieve when they understood that sound meant danger. Mothers pressed hands over mouths.

The patrol boat moved on. The breath that Mina hadn't realized she was holding escaped in a rush.

Then a child began to cry — not from fear, but from exhaustion, from hunger, from being too small to understand that crying could get them all killed. The child's mother tried to hush him, but nothing worked.

"The men from my village," the woman beside Mina said suddenly, her voice low and strange. "They came last night. Took them all. Just the men. The women and children, we ran."

Her words dropped into the silence like stones.

"My husband," the child's mother said, her voice cracking. "He stayed to buy us time."

No one answered. What was there to say?

The boat rocked in the current, water lapping dangerously close to the gunwales. Mina closed her eyes and tried to remember safety — but her mind couldn't find it. All it found were images of flames, of faces she recognized screaming, of her father's back as he disappeared into the crowd.

Then the woman beside her began to sing.

It wasn't a song Mina knew, but the melody was beautiful — sad and strong, carrying across the water in the darkness. Other voices joined in gradually, one by one, until the whole boat was humming together, a chorus of refugees in the darkness.

For the first time since the explosions, Mina felt something like hope. Not certainty, not safety — but the possibility that they might survive this, that they might reach the other side, that the world might still contain moments of grace.

The song ended as they approached the far shore.

The woman squeezed Mina's hand. "We'll make it," she said, and Mina almost believed her.

---

## Scene 3 — Smugglers & Choices

The crossing point was chaos — people everywhere, shouting, bargaining, desperate for passage. Official boats were nonexistent. Everything had become a transaction, every life measured against what someone could pay.

Smugglers moved through the crowd like predators, offering risky passage for money or favors. Mina watched from behind her father's shoulder as the negotiations happened — coin clinking, rope burn on palms, the cold calculation of human worth.

"Two thousand rupees for the whole family," one smuggler said. "But only three of you. The extra person — no room."

Her father's face hardened. "All four of us, or none."

"We can talk about a discount," the smuggler said, "but the boat's full. Someone has to stay behind."

Mina saw families being separated in every direction — mothers choosing which children to take, husbands sending wives ahead while they waited, strangers agreeing to take in children whose parents had been lost. The calculus of survival was brutal and necessary.

Research had confirmed this later — smuggling networks exploited desperate refugees in 1971, charging impossible prices, making impossible choices. People sold everything they owned for the chance to cross water that might save them or drown them.

Her father found a different boatman — an older man with weathered skin and eyes that had seen too much. They bargained for minutes while Mina's heart hammered against her ribs. Every passing moment was a moment closer to soldiers, to death, to whatever was coming from inland.

"I can take all of you," the boatman finally said. "But it's crowded. And the price is higher than they're asking."

Her father didn't hesitate. He pulled money from the metal trunk — savings he'd been hiding, emergency funds no one had known about. The stack of notes was thick but finite.

They got passage, but at cost: a family behind them in line couldn't pay the increased price. The father begged, the mother cried, the children stared with eyes too large in thin faces.

"Our turn," the boatman said, not unkindly but final.

Mina felt a cold knot in her stomach at the unfairness. Why them and not this other family? What made their lives worth saving and these lives expendable? There was no answer, only the terrible necessity of boarding the boat while others were left behind.

As they pushed away from shore, Mina watched the family recede — the father's hopeless face, the mother's bent shoulders, the children who might die tonight because her family had enough money to live.

The choice would haunt her forever.

---

## Scene 4 — First Night at Coast

Makeshift camp covered the beach — fires of driftwood and whatever people could burn, shelters constructed from branches and blankets, families huddled together against the night. The smell of smoke everywhere, the distant horn of a ship, salt drying on Mina's lips.

They'd made it across, but this wasn't India yet. This was in-between, limbo, waiting for boats that would take them the rest of the way.

"India is across the water," someone said, pointing. "You can see it on a clear day."

But it wasn't a clear night. The horizon was dark, and Mina couldn't tell what was water and what was sky, or whether safety actually existed on the other side.

They built a small fire with driftwood gathered from the shoreline. The wood was wet and sputtered, creating more smoke than flame. Mina's mother took out a small pot — one of the few things she'd managed to grab in the chaos — and began heating water for tea.

Not real tea, of course. Just hot water with the faint memory of flavor. But it was warm, and it was something familiar in a world that had lost all familiarity.

Talk swirled around them — rumors of what was happening in Chittagong, stories of other crossings, arguments about whether India would actually take them all. Every conversation was both comfort and torture, offering hope that might be false and horror that was certainly true.

Mina saw a distant lighthouse, its beam sweeping across the darkness, and imagined safety waiting there. She imagined boats that weren't overcrowded, camps with food and medicine, a place where she could sleep without wondering if she'd wake up to artillery.

The fantasy lasted only seconds before reality crashed back in.

Fire led to smell of burning wood led to sound of hushed voices led to memory of home — a chain of sensation that grounded her even as it broke her heart. The smell of incense from her mother's prayer room. The sound of her father's laugh. The taste of her grandmother's cooking.

All gone now, or changed beyond recognition.

At dawn, boats to India were announced.

People scrambled toward the shore — a mass of desperate humanity pushing toward possibility. Mina's father stood up, dusting sand from his clothes.

"This is it," he said, and his voice carried both relief and terror.

Mina looked at the water stretching endless before them. The next crossing would be longer, more dangerous, more final. If they drowned this time, there would be no turning back.

But staying here wasn't an option either. Everything behind them was fire and death. Everything ahead was unknown.

She took her mother's hand and followed her father toward the boats, toward water that might save them or drown them, toward a future she couldn't yet imagine.

---

**Chapter 4 Word Count: 1,812 words**

**Research Notes:**
- **Sources Used:** Liberation War Museum refugee archives (crossing points, smuggling networks), academic sources on 1971 refugee movements (boat crossings, exploitation by smugglers), survivor testimonies (river crossings, separation of families)
- **Historical Accuracy:** Smuggling networks did exploit desperate refugees along coastal routes; boat overloading was common and led to drownings; family separations occurred during bargaining for passage; Cox's Bazar/Teknaf were primary crossing points
- **Facts to Verify:** Specific crossing distances to India; typical boat capacities; documented drownings during refugee crossings

**Character Development:**
- Mina's moral awakening through witnessing family separation
- Father's hidden savings reveals careful preparation
- Boatman with weathered face: humanizing of people facilitating escapes
- Woman singing boat: shows human capacity for beauty in crisis

**Sensory Anchors:**
- Smell: Salt air, smoke, wet driftwood
- Sound: Creaking planks, distant ship horn, woman's singing
- Touch: Gritty sand, rope burn, woman's hand squeeze

**Bengali Terms Used:**
- None this chapter

**Psychological Elements:**
- Counting stars as coping mechanism
- Survivor's guilt over family left behind
- Memory chain (fire → smell → sound → memory) as grounding
- Lighthouse as symbol of illusory safety

**Thematic Elements:**
- The calculus of survival: who lives, who dies, based on money/connections
- Boat crossing as threshold between past and future
- Water motif: from childhood joy to necessity to danger

---

**Next Chapter Preview:** Chapter 5 — Camp Life. The family arrives at an Indian refugee camp in Tripura, encountering overcrowding, food scarcity, and the beginning of long-term displacement.
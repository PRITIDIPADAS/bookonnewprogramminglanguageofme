# PASO Design Notes

## Architecture Overview

PASO implements a complete programming language processing pipeline with two execution paths:

```
Source Code → Lexer → Tokens → Parser → AST → [Interpreter | Compiler] → [Execution | Bytecode → VM]
```

## Design Decisions

### 1. Syntax Design

**Why English-like keywords?**
- Educational clarity: `save 5 to x` is more readable than `x = 5` for beginners
- Instruction-focused: Code reads like a sequence of instructions
- Differentiation: Clearly distinguishes PASO from Python, C, or Assembly

**Why no braces or indentation?**
- Explicit delimiters: `when ... then ... done` is unambiguous
- Teaching tool: Shows how syntax rules work
- Avoids confusion with existing languages

### 2. Execution Models

**Why both interpreter and compiler?**
- Teaches trade-offs: Flexibility vs. performance
- Demonstrates both approaches: Direct AST execution vs. bytecode
- Real-world relevance: Both used in production languages (Python vs. Java)

**Interpreter advantages:**
- Fast startup: No compilation step
- Easy debugging: Direct mapping to source
- Flexible: Can modify behavior at runtime

**Compiler+VM advantages:**
- Faster execution: Bytecode is pre-compiled
- Portable: Bytecode runs on any platform with VM
- Optimization potential: Bytecode can be optimized

### 3. Virtual Machine Design

**Why stack-based?**
- Simplicity: Uniform operation model
- Portability: No register dependencies
- Real-world relevance: Used by JVM, CPython, Lua
- Educational: Clear demonstration of stack operations

**Stack operations:**
- PUSH: Add value to top
- POP: Remove from top
- All arithmetic uses stack: `PUSH 5; PUSH 3; ADD` → 8

**Why not register-based?**
- More complex: Need to manage register allocation
- Less portable: Register counts vary by architecture
- Stack is more intuitive for teaching

### 4. Bytecode Design

**Instruction format:**
- Opcode: Operation name (PUSH, ADD, etc.)
- Operand: Optional data (number, variable name, address)
- Human-readable: Not machine code

**Why custom bytecode?**
- Teaching: Shows how real bytecodes work
- Control: Complete understanding of execution
- Safety: Cannot execute arbitrary native code

**Key instructions:**
- Stack: PUSH, POP, DUP
- Variables: LOAD, STORE
- Arithmetic: ADD, SUB, MUL, DIV, IDIV
- Control: JUMP, JUMP_IF_FALSE, CALL, RETURN
- I/O: OUTPUT, INPUT

### 5. Function Calls

**Call stack management:**
- Save return address
- Save local variables
- Jump to function
- Restore on return

**Why explicit call stack?**
- Teaching: Shows how real call stacks work
- Recursion: Supports recursive functions
- Debugging: Clear stack traces

**Argument passing:**
- Push arguments on stack (right-to-left)
- Pop into local variables
- Return value on stack

### 6. Scoping

**Current implementation:**
- Global variables
- Local function variables
- No block scope (intentional simplification)

**Why simple scoping?**
- Educational: Easy to understand
- Sufficient: Demonstrates the concept
- Extensible: Can add block scope later

### 7. Type System

**Dynamic typing:**
- No type declarations
- Type coercion for string concatenation
- Runtime type errors

**Why dynamic?**
- Simplicity: No type checking phase
- Flexibility: Easy to write code
- Teaching: Shows both advantages and disadvantages

**Type coercion:**
- String + any value → string concatenation
- Prevents errors: `"Hello " + 5` works
- Similar to JavaScript behavior

### 8. Error Handling

**Three phases of error handling:**
1. **Lexer errors**: Invalid characters, unterminated strings
2. **Parser errors**: Syntax errors, unexpected tokens
3. **Runtime errors**: Undefined variables, division by zero

**Why separate phases?**
- Teaching: Shows where errors occur
- Clarity: Specific error messages
- Real-world: All compilers have these phases

### 9. Integer Division

**Why two division operators?**
- `over` (/): Float division (5 / 2 = 2.5)
- `div` (//): Integer division (5 div 2 = 2)

**Necessity:**
- FizzBuzz requires integer division
- Educational: Shows different division semantics
- Real-world: Python has both / and //

### 10. Comments

**Supported:**
- Single-line: `// comment`
- Multi-line: `/* comment */`

**Why both?**
- Familiarity: Similar to Java, JavaScript, C
- Flexibility: Choose based on need

## Implementation Details

### Lexer
- Regular expressions for token matching
- Line/column tracking for errors
- Keyword vs. identifier distinction

### Parser
- Recursive descent parsing
- Operator precedence handling
- AST construction
- Error recovery (basic)

### Interpreter
- Direct AST traversal
- Variable lookup chain (local → global)
- Function call stack
- Exception handling (return statements)

### Compiler
- Two-pass compilation:
  1. Collect functions
  2. Generate bytecode
- Label resolution (for jumps)
- Function address calculation

### Virtual Machine
- Operand stack
- Instruction pointer
- Variable storage
- Call stack
- Instruction dispatch loop

## Performance Considerations

### Interpreter Performance
- Pros: No compilation overhead
- Cons: Repeated parsing/traversal

### Compiler+VM Performance
- Pros: Pre-compiled bytecode
- Cons: Compilation step

### Potential Optimizations
1. Constant folding: `2 + 3` → `5` at compile time
2. Dead code elimination: Remove unused code
3. Inline caching: Cache variable lookups
4. Bytecode caching: Save compiled bytecode

## Limitations and Trade-offs

### Intentional Limitations
- No arrays/lists (teaches data structures later)
- No modules (single-file programs)
- No standard library (minimal core)
- No exception handling (keeps it simple)

### Trade-offs
- Simplicity vs. power
- Educational vs. production
- Minimal vs. feature-rich

## Teaching Value

### Concepts Taught
1. **Lexical analysis**: How text becomes tokens
2. **Parsing**: How tokens become structure
3. **ASTs**: Abstract Syntax Trees
4. **Interpretation**: Direct execution
5. **Compilation**: Translation to bytecode
6. **Virtual machines**: Stack-based execution
7. **Function calls**: Call stacks and recursion
8. **Scoping**: Variable visibility
9. **Type systems**: Dynamic vs. static
10. **Error handling**: Compiler and runtime errors

### Real-world Connections
- Similar to: Python (interpreter + bytecode), Java (JVM), JavaScript (V8)
- Stack machines: JVM, CPython, WebAssembly
- Language design: Trade-offs and decisions

## Future Extensions

### Potential Additions
1. Arrays/lists and indexing
2. For-each loops
3. Pattern matching
4. Type system (static typing)
5. Modules and imports
6. Standard library
7. REPL (interactive shell)
8. Bytecode optimization
9. JIT compilation

### Educational Path
- Start with: Current PASO (minimal core)
- Add: Data structures (Phase 3)
- Add: Type system (Phase 4)
- Add: Optimization (Phase 5)

## Conclusion

PASO demonstrates that designing and implementing a programming language is achievable. The design choices prioritize education over production, clarity over complexity, and understanding over optimization.

Every component is visible and understandable, making PASO an excellent teaching tool for:
- How programming languages work
- The difference between interpretation and compilation
- Why stack machines are used
- How function calls are implemented
- The trade-offs in language design

**The best way to learn is to build. PASO builds understanding.**